var gulp = require('gulp');
var Server = require('karma').Server;
var tar = require('gulp-tar');
var gzip = require('gulp-gzip');
var rename = require('gulp-rename');
var del = require('del');

//Temporary hack for running tasks sequentially. This will be fixed in gulp 4.0
//So this has to revisted in the future
var runSequence = require('run-sequence');

var paths = {
    associate:{
        root:"associate/src/main/",
        scripts: [  "associate/src/main/scripts/*.js", 
                    "associate/src/main/scripts/**/*.js", 
                    "associate/src/main/scripts/**/**/*.js", 
                    "associate/src/main/scripts/**/**/**/*.js"],
        styles: ['./app/**/*.css', './app/**/*.scss'],
        index: './app/index.html',
        test: "/associate/src/test/",
        partials: ['app/**/*.html', '!app/index.html'],
    },
    customer:{
        root:"customer/src/main/",
        scripts: [  "customer/src/main/js/*.js", 
                        "customer/src/main/js/**/*.js"],
        styles: ['./app/**/*.css', './app/**/*.scss'],
        index: './app/index.html',
        test: "customer/src/test/",
        partials: ['app/**/*.html', '!app/index.html'],
    },    
    distDev: './dist.dev',
    distProd: './dist.prod',
    distScriptsProd: './dist.prod/scripts'
};

gulp.task('clean', function () {
    return del.sync('target/*');
});

gulp.task('associate-test', function(done){
    new Server({
        configFile: __dirname + paths.associate.test +'karma.conf.js',
        singleRun: true
    }, done).start();
})

gulp.task('associate-build', function(callback){
    runSequence('associate-test', callback);
})

// gulp.task('customer-test', function(done){
//  new Server({
//         configFile: __dirname + paths.customer.test +'karma.conf.js',
//         singleRun: true
//     }, done).start();
// })

// gulp.task('customer-build', function(callback){
//  runSequence('customer-test', callback);
// })

gulp.task('gzip', function(){
     gulp.src([ './**',
                '!./node_modules',
                '!./target',
                '!./node_modules/**',
                '!./target/**',
                '!./*.*',
                '!./associate/src/test',
                '!./associate/src/test/**',
                '!./associate/pom.xml',
                '!./customer/src/test',
                '!./customer/src/test/**',
                '!./customer/pom.xml'])
        .pipe(rename(function (path) {
            path.dirname = path.dirname.replace(/\\/g,"/");
            if (path.dirname.startsWith("associate")) {
                path.dirname = path.dirname.replace("associate/src/main","associate");
            } else if (path.dirname.startsWith("customer")){
                path.dirname = path.dirname.replace("customer/src/main","customer");
            }
        }))
        .pipe(tar('wecare-web.tar'))
        .pipe(gzip())
        .pipe(gulp.dest('target'))
})

gulp.task('build' , function(callback){
    runSequence('clean', 'associate-build', 'gzip', callback);
})
gulp.task('default',['build'])
