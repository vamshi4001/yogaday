angular.module('weCarePlusApp').filter('isEmptyObj', function() {
    return function(object) {
        return angular.equals({}, object);
    };
});
