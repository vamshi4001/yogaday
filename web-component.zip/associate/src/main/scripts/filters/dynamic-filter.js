angular.module('weCarePlusApp').filter('dynamicFilter', function($interpolate) {
    return function() {
        var result = $interpolate('{{value | ' + arguments[1] + '}}');
        return result({
            value: arguments[0]
        });
    };
});
