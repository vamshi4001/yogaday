angular.module('weCarePlusApp').filter('fixDecimal', function($filter) {
    return function(input, places) {
    	places = places ? places : 2;
        input = input ? input : "0.00";
        if (!input)
            return input;
        input = parseFloat(input);
        return input.toFixed(places);
    };
});
