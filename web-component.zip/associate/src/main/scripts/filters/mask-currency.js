angular.module('weCarePlusApp').filter('maskCurrency', function($filter) {
    return function(input, places) {
        places = places ? places : 2;
        input = input ? input : "";
        if (!input)
            return input;
        input = parseFloat(input) / 100;
        return input.toFixed(places);
    };
});
