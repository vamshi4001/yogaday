angular.module('weCarePlusApp').filter('dateFormat', function($filter) {
    return function(input, format) {
        if (input == null) {
            return "";
        }
        if (format) {
            var _date = $filter('date')(new Date(input), format);
        } else {
            var _date = $filter('date')(new Date(input), 'MM/dd/yyyy');
        }
        return _date.toUpperCase();
    };
});
