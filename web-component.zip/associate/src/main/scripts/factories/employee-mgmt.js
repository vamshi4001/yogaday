'use strict';

angular.module('weCarePlusApp')
    .factory('EmployeeMgmtFactory', function() {
        var userInfo = [];
        return {
            setUserInfo: function(data) {
                userInfo = data;
            },
            getUserInfo: function() {
                return userInfo;
            }
        }
    });
