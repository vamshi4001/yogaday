'use strict';

angular.module('weCarePlusApp')
    .factory('OrderFactory', function(Request, TransactionInfo, CONFIG, $timeout) {
        var txnObject = {};
        var txnDataMap = {
            txnIdData: 'transactionData',
            txnDetails: 'transactionDetails',
            eccData: 'eccData',
            msgData: 'msgData',
            otcData: 'otcData',
            rxOrderData: 'pprData'
        };
        var totalBarcode;
        var obj = {};
        var totalBarcodeTimeout;
        var eccNumber = "";
        var eccData;
        var fastpass = false;
        var fastpassData = {};
        var fastpassVersion = "01";
        var mobileConnectivity = "0";
        var minuteClinicDepositsOrder = [];

        obj.setMinuteClinicDepositsOrder = function(data) {
            minuteClinicDepositsOrder = data;
        };

        obj.getMinuteClinicDepositsOrder = function() {
            return minuteClinicDepositsOrder;
        };

        obj.getFastpassData = function() {
            return fastpassData;
        };
        obj.setFastpassData = function(data) {
            fastpassData = data;
        };
        obj.setFastpass = function(data) {
            fastpass = data;
        };
        obj.getFastpass = function() {
            return fastpass;
        };
        obj.setFastpassVersion = function(data) {
            fastpassVersion = data;
        };
        obj.getFastpassVersion = function() {
            return fastpassVersion;
        };
        obj.setMobileConnectivity = function(data) {
            mobileConnectivity = data;
        };
        obj.getMobileConnectivity = function() {
            return mobileConnectivity;
        };
        obj.setTxnIdData = function(data) {
            txnObject[txnDataMap.txnIdData] = data;
        };
        obj.getTxnIdData = function() {
            return txnObject[txnDataMap.txnIdData];
        };

        obj.isEccInOrder = function() {
            return (typeof txnObject[txnDataMap.eccData] !== 'undefined' && Object.keys(txnObject[txnDataMap.eccData]).length > 0);
        };
        obj.setEccDataToTxn = function(data, eccNo) {
            txnObject[txnDataMap.eccData] = data;
            eccNumber = eccNo;
        };
        obj.setMessageDataToTxn = function(data) {
            txnObject[txnDataMap.msgData] = data;
        };
        obj.setOtcDataToTxn = function(data) {
            txnObject[txnDataMap.otcData] = data;
        };

        obj.addOtcItemToTxn = function(otcItem) {
            txnObject[txnDataMap.otcData].push(otcItem);
        };

        obj.setRxOrderDataToTxn = function(data) {
            txnObject[txnDataMap.rxOrderData] = data;
        };

        obj.getTxnObject = function() {
            return txnObject;
        };
        obj.getEccDataFromTxn = function() {
            if (!txnObject[txnDataMap.eccData]) {
                txnObject[txnDataMap.eccData] = {};
            }
            return txnObject[txnDataMap.eccData];
        };
        obj.getMessageDataFromTxn = function() {
            if (!txnObject[txnDataMap.msgData]) {
                txnObject[txnDataMap.msgData] = {};
            }
            return txnObject[txnDataMap.msgData];
        };
        obj.getOtcDataFromTxn = function() {
            if (!txnObject[txnDataMap.otcData]) {
                txnObject[txnDataMap.otcData] = [];
            }
            return txnObject[txnDataMap.otcData];
        };
        obj.getRxOrderDataFromTxn = function() {
            if (!txnObject[txnDataMap.rxOrderData]) {
                txnObject[txnDataMap.rxOrderData] = [];
            }
            return txnObject[txnDataMap.rxOrderData];
        };
        obj.initTxnObject = function() {
            //Will be initiated to new transaction
            txnObject = {};
            //Invoke all factories and clear the data
        };
        obj.getEccInfoByCardNo = function(eccNo) {
            var q = 'card_nbr=' + eccNo;
            var eccLookupPromise = Request.invoke({
                url: appConfig.store.services.API.extraCareLookUp + '?' + q,
                method: 'GET'
            });
            return eccLookupPromise;
        };
        //TODO: need to revalidate the logic, used to find is Controled RX prescription items present
        obj.getControlledItemsListFromSRDMessage = function() {
            var isControledRxinScript = false;
            angular.forEach(obj.getRxOrderDataFromTxn(), function(patientNumber) {
                angular.forEach(patientNumber.patientMessageInfo.srdMsg, function(srdMessageId) {
                    if (srdMessageId.ProgType == "controled") {
                        isControledRxinScript = true;
                    }
                });
            });

            return isControledRxinScript;
        };

        obj.getTotalAmoutOfRxItems = function() {
            var totalRxItems = 0;
            var rxOrderData = obj.getRxOrderDataFromTxn();
            angular.forEach(rxOrderData, function(patient) {
                angular.forEach(patient.patientFillInfoList, function(patientScript) {
                    if (patientScript.fillDisposition.disposition == 1 && patientScript.fillDisposition.dispositionKey == 'SLD') {
                        totalRxItems = totalRxItems + patientScript.patPayAmt;
                    }
                });
            });

            return totalRxItems;
        };

        obj.getRxItemsInOrder = function() {
            var rxItems = [];

            angular.forEach(obj.getRxOrderDataFromTxn(), function(patient) {
                angular.forEach(patient.patientFillInfoList, function(patientScript) {
                    if (patientScript.fillDisposition.disposition == 1 && patientScript.fillDisposition.dispositionKey == 'SLD') {
                        rxItems.push(patientScript);
                    }
                });
            });

            return rxItems;
        };

        obj.setTransactionDetails = function(data) {
            txnObject[txnDataMap.txnDetails] = data;
        };

        obj.getTransactionDetails = function() {
            return txnObject[txnDataMap.txnDetails];
        };

        obj.getTransactionIdData = function() {

            if (!obj.getTxnIdData()) {
                var getTransactionIdDataPromise = Request.invoke({
                    url: appConfig.store.services.API.transationIdService,
                    method: 'GET'
                });

                getTransactionIdDataPromise.then(function(result) {
                    TransactionInfo.setTransactionId(result.transactionId);
                    TransactionInfo.setTransactionNumber(result.transactionNumber);
                    CONFIG.txnInfo = result;
                    obj.setTxnIdData(result);
                    obj.setTotalBarcode(null);
                }, function(result) {
                    appUtils.log('Not able to get transaction id data');
                });
            } else {
                return obj.getTxnIdData();
            }
        };
        obj.startNewTxn = function() {
            var getTransactionIdDataPromise = Request.invoke({
                url: appConfig.store.services.API.transationIdService,
                method: 'GET'
            });

            getTransactionIdDataPromise.then(function(result) {
                TransactionInfo.setTransactionId(result.transactionId);
                TransactionInfo.setTransactionNumber(result.transactionNumber);
                obj.setTxnIdData(result);
            }, function(result) {
                appUtils.log('Not able to get transaction id data');
            });
        };
        obj.clearTxnObject = function(fromGoHomeAction) {
            if (txnObject[txnDataMap.otcData] && !txnObject[txnDataMap.otcData].length) {
                //If no OTC items clear all
                fromGoHomeAction = false;
            }
            fastpass = false;
            fastpassData = {};
            fastpassVersion = "01";
            mobileConnectivity = "0";
            if (!fromGoHomeAction) {
                eccData = '';
                eccNumber = "";
                minuteClinicDepositsOrder = [];
                txnObject = {};
            } else {
                txnObject[txnDataMap.rxOrderData] = [];
                txnObject[txnDataMap.msgData] = {};
                txnObject[txnDataMap.msgData] = {};
            }
        };
        obj.setTotalBarcode = function(data) {
            if (data) {
                totalBarcode = data;
                if (totalBarcodeTimeout) {
                    $timeout.cancel(totalBarcodeTimeout);
                }
                totalBarcodeTimeout = $timeout(function() {
                    totalBarcode = null;
                }, 1800000);
            } else {
                totalBarcode = null;
            }
        };
        obj.getTotalBarcodeData = function() {
            return totalBarcode.qrdata;
        };
        obj.getTotalBarcode = function() {
            return (totalBarcode || {}).image;
        };
        obj.setEccNumber = function(data) {
            eccNumber = data;
        };
        obj.getEccNumber = function() {
            return eccNumber || fastpassData.extraCareID;
        };
        obj.setEccData = function(data) {
            eccData = data;
        };
        obj.getEccData = function() {
            return eccData;
        };
        return obj;

    });
