'use strict';

angular.module('weCarePlusApp')
    .factory('PatientFactory', function(OrderFactory) {
        var patientSearchList = [];
        var selectedPatient = {};
        var selectedPatientList = {};
        var patientSearchStr = null;
        var patientListByPhone = [];
        var extraCareInfoByCardno = {};
        var actionNoteDetails = {};
        var tpcomplience = {};

        return {
            setPatientSearchList: function(data) {
                patientSearchList = data;
            },
            getPatientSearchList: function() {
                return patientSearchList;
            },
            setSelectedPatient: function(data) {
                selectedPatient = data;
            },
            getSelectedPatient: function() {
                return selectedPatient;
            },
            updatePhrEnrolled: function(patientId, enrollmentStatus) {
                if (selectedPatientList[patientId]) {
                    selectedPatientList[patientId].eccData.enrollmentStatus = enrollmentStatus || 'E';
                }
            },
            updateHipaaResolved: function(patientId) {
                if (selectedPatientList[patientId]) {
                    selectedPatientList[patientId].eccData.resolved = true;
                }
            },
            addEccCardToPatient: function(data) {
                selectedPatientList[0].eccData.xtracareCardNumber = data;
            },
            addToSelectedPatientList: function(data) {
                if (selectedPatientList[data.rxCPatientId]) {
                    data.eccData = selectedPatientList[data.rxCPatientId].eccData;
                }
                selectedPatientList[data.rxCPatientId] = data;
                OrderFactory.setTotalBarcode(null);
            },
            getSelectedPatientList: function() {
                return selectedPatientList;
            },
            clearSelectedPatientList: function() {
                actionNoteDetails = {};
                selectedPatientList = {};
                if (patientSearchStr && patientSearchStr === 'Waiters') {
                    patientSearchStr = null;
                }
            },
            setPatientSearchStr: function(data) {
                patientSearchStr = data;
            },
            getPatientSearchStr: function() {
                return patientSearchStr;
            },
            setPatientListByPhone: function(data) {
                patientListByPhone = data;
            },
            getPatientListByPhone: function() {
                return patientListByPhone;
            },
            setExtraCareInfoByCardno: function(data) {
                extraCareInfoByCardno = data;
            },
            getExtraCareInfoByCardno: function() {
                return extraCareInfoByCardno;
            },
            setEccInfoByPatientId: function(patientId, eccData) {
                if (!selectedPatientList[patientId]) {
                    selectedPatientList[patientId] = {};
                }
                selectedPatientList[patientId].eccData = eccData;
            },
            getActionNoteDetails: function() {
                return actionNoteDetails;
            },

            setActionNoteDetails: function(data) {
                actionNoteDetails[data.barcode] = data;
            },
            getTpcomplianceMessageDetail: function() {
                return tpcomplience;
            },
            setTpComplianceMessageDetails: function(data) {
                tpcomplience[data.tpMessageid] = data;
            },
            removeFromSelectedPatientList: function(patientId) {
                delete selectedPatientList[patientId];
            },
            getDobVerifyText: function() {            	
            	var config = DAILY_CONFIG.screenConfig.screenConfig;
            	if(config && config.verifyText){            		
            		return true;
            	}else{            		
            		return false;
            }
            }

        };
    });
