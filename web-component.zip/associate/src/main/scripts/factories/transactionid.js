'use strict';

angular.module('weCarePlusApp')
    .factory('TransactionInfo', function() {
        var transactionId = null;
        var transactionNumber = null;
        return {
            setTransactionId: function(txnId) {
                transactionId = txnId;
            },
            getTransactionId: function() {
                return transactionId;
            },
            setTransactionNumber: function(txnNumber) {
                transactionNumber = txnNumber;
            },
            getTransactionNumber: function() {
                return transactionNumber;
            } 
        };
 
    });
