'use strict';

angular.module('weCarePlusApp')
    .factory('BasketFactory', function(CONFIG) {
        var currentOrder = [];
        var basketData = {};
        //For Messaging
        var basketDataClone = {};
        var rxItemsInOrder = {};
        var otcItemsInOrder = [];
        var controlledItem = {};
        var driveThru = false;
        var tpCompliancePatESign = false;
        var basketPageMsgAlert = false;
        var newPhrEnrollment = false;
        var tpComplianceMsgSignedActionMAP = {
            "formSignedMap": {
                "AOB": "N",
                "ABN": "N",
                "RRP": "N"
            }
        };
        var patientPresentMap = {};
        var partialBarcodeRxInfoMap = {};
        var msgSeqMsgItemMap = {};
        var scanedBarcode = null;
        var selectedRxItemFillInfo=null;


        return {
            setPartialBarcodeRxInfoMap: function(data) {
                partialBarcodeRxInfoMap = data;
            },
            getPartialBarcodeRxInfoMap: function() {
                return partialBarcodeRxInfoMap;
            },
            setScanedBarcode: function(data) {
                scanedBarcode = data;
            },
            getScanedBarcode: function() {
                return scanedBarcode;
            },
            setMsgSeqMsgItemMap: function(data) {
                msgSeqMsgItemMap = data;
            },
            getMsgSeqMsgItemMap: function() {
                return msgSeqMsgItemMap;
            },
            //Created a new function will be using this in new message  
            getPatientProfileList: function() {
                return Object.values(basketData || {});
            },
            updatePatientPresntMap: function(patientId, data) {
                patientPresentMap[patientId] = data;
            },
            getPatientPresentMap: function() {
                return patientPresentMap;
            },
            setTpCompliancePatESign: function(data) {
                if (data && tpCompliancePatESign) {
                    tpCompliancePatESign = false;
                } else {
                    tpCompliancePatESign = data;
                }
            },
            getTpCompliancePatESign: function() {
                return tpCompliancePatESign;
            },
            updateBasketData: function(key, data) {
                if (Object.keys(basketData).length === 0) {
                    CONFIG.messages.txnStartTimestamp = appUtils.getCurrentTimestamp();
                }
                basketData[key] = data;
                basketDataClone[key] = angular.copy(data);
            },
            getBasketData: function() {
                return basketData;
            },
            getOfflineProfile: function() {
                if (basketData['0']) {
                    return basketData['0'];
                } else {
                    appUtils.log("WARN: accessing Offline profile when not initialized.");
                    this.updateBasketData('0', {});
                    return basketData['0'];
                }
            },
            getBasketDataClone: function() {
                return basketDataClone;
            },
            setRxItemsInOrder: function(data) {
                rxItemsInOrder = data;
            },
            getRxItemsInOrder: function() {
                return rxItemsInOrder;
            },
            clearRxItemsInOrder: function() {
                angular.forEach(rxItemsInOrder, function(val, key) {
                    delete rxItemsInOrder[key];
                });
                // rxItemsInOrder = {};
            },
            clearOtcItemsInOrder: function() {
                for (var i = otcItemsInOrder.length - 1; i >= 0; i--) {
                    otcItemsInOrder.pop();
                }
                // otcItemsInOrder = [];
            },
            getOtcItemsInOrder: function() {
                return otcItemsInOrder;
            },
            setOtcItemsInOrder: function(data) {
                otcItemsInOrder = data;
            },
            setControlledItem: function(item) {
                controlledItem = item;
            },
            getControlledItem: function() {
                return controlledItem;
            },
            addControlledItemToCurrentOrderList: function() {
                if (otcItemsInOrder && controlledItem) {
                    otcItemsInOrder.push(controlledItem);
                }
            },
            clearWholeOrder: function() {
                this.clearOtcItemsInOrder();
                this.clearRxItemsInOrder();
            },
            getCurrentBasketScenario: function(prevStatus, currentStatus) {
                var intVal = currentStatus ? currentStatus : 0;
                var scenarioKey = CONFIG.BASKET_SCENARIO.CONSTANT + CONFIG.BASKET_SCENARIO.DELIMETER + prevStatus + CONFIG.BASKET_SCENARIO.DELIMETER + intVal;
                var scenorioType = PSI2_PROD_PROP[scenarioKey] || PSI2_PROD_PROP['scenario.default'];
                var scenariosArray = DAILY_CONFIG.basketConfig.basketConfig.scenario;
                var scenario;
                for (var i in scenariosArray) {
                    scenario = scenariosArray[i];
                    //copy this 
                    if (scenario) {
                        if (scenario.scenarioType == scenorioType) {
                            return scenario;
                        }
                    }
                }
            },
            /*
             ** Get RxOrder Data 
             */
            getRxOrderData: function() {
                var rxOrderData = [];
                angular.forEach(basketData, function(value, key) {
                    rxOrderData.push(value);
                });
                return rxOrderData;
            },

            getRxOrderDataForTransaction: function() {
                var basketDataCopy = angular.copy(basketData);
                var rxOrderData = [];
                angular.forEach(basketDataCopy, function(value, key) {
                    var rxItems = [];
                    angular.forEach(value.patientFillInfoList, function(rxitemvalue) {
                        delete rxitemvalue.itemStatus.unScannedRxStatus;
                        rxItems.push(rxitemvalue);
                    });

                    value.patientFillList = [];

                    angular.forEach(rxItems, function(itemdata) {
                        value.patientFillList.push(itemdata);
                        console.log(itemdata);
                    });

                    rxOrderData.push(value);
                });
                return rxOrderData;
            },

            setDriveThru: function(data) {
                driveThru = data;
            },

            isDriveThru: function() {
                return driveThru;
            },
            clearBasketData: function() {
                basketData = {};
                basketDataClone = {};
                controlledItem = {};
                currentOrder = [];
                driveThru = false;
                newPhrEnrollment = false;
                otcItemsInOrder = [];
                rxItemsInOrder = {};
                otcItemsInOrder = [];
                tpCompliancePatESign = false;
                newPhrEnrollment = false;
                basketPageMsgAlert = false;
                patientPresentMap = {};
                partialBarcodeRxInfoMap = {};
                msgSeqMsgItemMap = {};
            },
            updateMsgDisp: function(patientMessage, msgListKey, options) {
                options = options ? options : {};
                if (!options.patientMessageList) {
                    options.patientMessageList = [];
                    options.patientMessageList.push(patientMessage);
                }
                angular.forEach(options.patientMessageList, function(patientMessageOuter) {
                    var pprItem = basketData[patientMessageOuter.rxPatientId];
                    if (pprItem) {
                        var patientMessageInfo = pprItem.patientMessageInfo;
                        var msgItemList = patientMessageInfo[msgListKey];
                        angular.forEach(msgItemList, function(msgItem) {
                            if (msgListKey === 'srdMsg') {
                                if (options.patientMessageList && options.patientMessageList.length && options.msgDisp) {
                                    angular.forEach(options.patientMessageList, function(patientMessageTemp) {
                                        if (msgItem.rxNum === patientMessageTemp.rxNum) {
                                            if (patientMessage.srdConfigRule.promptAtPos[0].promptName === 'PICKUP_ID') {
                                                msgItem.pickupDisplayed = true;
                                                msgItem.pickupIDType = options.msgDisp['ID_TYPE'];
                                                msgItem.pickupID = options.msgDisp['ID_VALUE'];
                                                msgItem.pickupJurisdictionCode = options.msgDisp['JURISDICTION_ID'];
                                                msgItem.pickupFName = options.msgDisp['FIRST_NAME'];
                                                msgItem.pickupLName = options.msgDisp['LAST_NAME'];
                                                msgItem.pickupStreetAddress = options.msgDisp['STREET_ADDRESS'];
                                                msgItem.pickupCity = options.msgDisp['CITY'];
                                                msgItem.pickupState = options.msgDisp['STATE'];
                                                msgItem.pickupZipCode = options.msgDisp['ZIPCODE'];
                                                if (options.msgDisp['DATE_OF_BIRTH']) {
                                                    msgItem.pickupDateOfBirth = Date.parse(options.msgDisp['DATE_OF_BIRTH']);
                                                }
                                            } else {
                                                msgItem.patientDisplayed = true;
                                                msgItem.patientIDType = options.msgDisp['ID_TYPE'];
                                                msgItem.patientID = options.msgDisp['ID_VALUE'];
                                                msgItem.patientJurisdictionCode = options.msgDisp['JURISDICTION_ID'];
                                                msgItem.patientFName = options.msgDisp['FIRST_NAME'];
                                                msgItem.patientLName = options.msgDisp['LAST_NAME'];
                                            }
                                            if (options.msgDisp['RELATIONSHIP_CODE']) {
                                                msgItem.relationshipCode = options.msgDisp['RELATIONSHIP_CODE'].split('-')[0];
                                            }
                                            if (options.msgDisp['EXPIRATION_DATE']) {
                                                msgItem.expirationDate = Date.parse(options.msgDisp['EXPIRATION_DATE']);
                                            }
                                            msgItem.mandatory = patientMessage.messageConfig.msgInd;
                                            msgItem.disposition = '1'; //Messaged dispayed dispostion
                                            msgItem.notDisplayedReason = null; //Not displayed reson null always since we definetly display
                                            msgItem.timestamp = appUtils.getCurrentTimestamp(CONFIG.timestampFormat)
                                            msgItem.markDisplayed = true;

                                        }
                                    });
                                }
                            } else if (msgListKey === 'patDemoMsg') {
                                options = options ? options : {};
                                var currentDispotion = options[msgItem.rxPatientId];
                                if (currentDispotion) {
                                    msgItem.mandatory = patientMessage.messageConfig.msgInd;
                                    msgItem.disposition = '1'; //Messaged dispayed dispostion
                                    msgItem.notDisplayedReason = null; //Not displayed reson null always since we definetly display
                                    msgItem.timestamp = appUtils.getCurrentTimestamp(CONFIG.timestampFormat)
                                    msgItem.markDisplayed = true;
                                    msgItem.outcome = 'Y';
                                    if (currentDispotion.contactPreference)
                                        msgItem.contactPreference = currentDispotion.contactPreference;
                                    if (currentDispotion.work)
                                        msgItem.workPhone = currentDispotion.work;
                                    if (currentDispotion.home)
                                        msgItem.homePhone = currentDispotion.home;
                                    if (currentDispotion.mobile)
                                        msgItem.mobilePhone = currentDispotion.mobile;
                                    msgItem.smsEnrolled = (currentDispotion.smsEnrolled && currentDispotion.smsEnrolled === 'Yes') ? 'Y' : 'A';
                                }
                                //Need to be removed actually not display reason should be set from services
                                if (options.notDisplayedReason) {
                                    msgItem.disposition = '0';
                                    msgItem.notDisplayedReason = options.notDisplayedReason;
                                    msgItem.markDisplayed = false;
                                }
                            } else if (msgListKey === 'patCounslMsg') {
                                if (msgItem.msgSeq == patientMessage.msgSeq) {
                                    msgItem.mandatory = patientMessage.messageConfig.msgInd;
                                    msgItem.disposition = '1'; //Messaged dispayed dispostion
                                    msgItem.notDisplayedReason = null; //Not displayed reson null always since we definetly display
                                    msgItem.timestamp = appUtils.getCurrentTimestamp(CONFIG.timestampFormat)
                                    msgItem.markDisplayed = true;
                                    //Only for speciality drugs
                                    if (options.dispositionMap && msgItem.rxPatientId && options.dispositionMap[msgItem.rxPatientId] && options.dispositionMap[msgItem.rxPatientId].fillInfo && options.dispositionMap[msgItem.rxPatientId].fillInfo.specialtyOrderNum) {
                                        msgItem.specialtyOrderNum = options.dispositionMap[msgItem.rxPatientId].fillInfo.specialtyOrderNum;
                                    }
                                }
                            } else if (msgListKey === 'patCentricMsg' || msgListKey == 'msgCentrMsg') {
                                if (options.progType == msgItem.progType) {
                                    msgItem.disposition = '1'; //Messaged dispayed dispostion
                                    msgItem.notDisplayedReason = null; //Not displayed reson null always since we definetly display
                                    msgItem.timestamp = appUtils.getCurrentTimestamp(CONFIG.timestampFormat)
                                    msgItem.markDisplayed = true;
                                    msgItem.mandatory = patientMessage.messageConfig.msgInd;
                                    if (options && options.data) {
                                        msgItem.outcome = options.data[msgItem.rxPatientId];
                                    }
                                }
                                //SMS
                                if (msgListKey === 'patCentricMsg' && (options.progType == '2' || options.progType == '3') && basketData[msgItem.rxPatientId]) {
                                    var pprItem = basketData[msgItem.rxPatientId];
                                    msgItem.contactPreference = pprItem.patientDetails.patientCntctInfo.prefContact;
                                    if (pprItem.patientDetails.patientCntctInfo.phone.work)
                                        msgItem.workPhone = pprItem.patientDetails.patientCntctInfo.phone.work;
                                    if (pprItem.patientDetails.patientCntctInfo.phone.home)
                                        msgItem.homePhone = pprItem.patientDetails.patientCntctInfo.phone.home;
                                    if (pprItem.patientDetails.patientCntctInfo.phone.mobile)
                                        msgItem.mobilePhone = pprItem.patientDetails.patientCntctInfo.phone.mobile;
                                    if (pprItem.patientDetails.patientCntctInfo.email)
                                        msgItem.email = pprItem.patientDetails.patientCntctInfo.email;
                                }
                                //Need to be removed actually not display reason should be set from services
                                if (options.notDisplayedReason) {
                                    msgItem.disposition = '0';
                                    msgItem.notDisplayedReason = '12';
                                    msgItem.markDisplayed = false;
                                }
                            } else if (msgListKey === 'rxCentrMsg') {
                                if ('1' == msgItem.progType) {
                                    var rxnum = appUtils.prepandZeros(msgItem.rxNum, 7);
                                    if (options && options.dispositionMap && options.dispositionMap[rxnum]) {
                                        msgItem.disposition = '1'; //Messaged dispayed dispostion
                                        msgItem.notDisplayedReason = null; //Not displayed reson null always since we definetly display
                                        msgItem.timestamp = appUtils.getCurrentTimestamp(CONFIG.timestampFormat)
                                        msgItem.markDisplayed = true;
                                        msgItem.outcome = options.dispositionMap[rxnum];
                                        // msgItem.mandatory = patientMessage.messageConfig.msgInd;
                                    }
                                    if (options && options.patientMessageRxInfoMap && options.patientMessageRxInfoMap[msgItem.rxPatientId] && options.patientMessageRxInfoMap[msgItem.rxPatientId].length) {
                                        if (options.patientMessageRxInfoMap[msgItem.rxPatientId][0].messageInfo && options.patientMessageRxInfoMap[msgItem.rxPatientId][0].messageInfo.messageConfig) {
                                            msgItem.mandatory = options.patientMessageRxInfoMap[msgItem.rxPatientId][0].messageInfo.messageConfig.msgInd;
                                        }
                                    }
                                }
                            }
                        });
                    }
                });
            },

            updateBasketMsgDisp: function(rxPatientId, msgListKey, rxNum) {
                var pprItem = null;
                if (CONFIG.storeData.isOffline) {
                    pprItem = this.getOfflineProfile();
                } else {
                    pprItem = basketData[rxPatientId];
                }
                if (pprItem) {
                    var patientMessageInfo = pprItem.patientMessageInfo;
                    var msgItemList = patientMessageInfo[msgListKey];
                    angular.forEach(msgItemList, function(msgItem) {
                        if (msgListKey === 'eanMsg') {
                            if (msgItem.rxNum == rxNum) {
                                msgItem.mandatory = 'Y';
                                msgItem.disposition = '1'; //Messaged dispayed dispostion
                                msgItem.notDisplayedReason = null; //Not displayed reson null always since we definetly display
                                msgItem.timestamp = appUtils.getCurrentTimestamp(CONFIG.timestampFormat)
                                msgItem.markDisplayed = true;
                                msgItem.commInd='Y';

                            }
                        } else if (msgListKey === 'tpComplianceMsg') {
                            if (msgItem.rxNum == rxNum) {
                                msgItem.mandatory = 'Y';
                                msgItem.disposition = '1'; //Messaged dispayed dispostion
                                msgItem.notDisplayedReason = null; //Not displayed reson null always since we definetly display
                                msgItem.timestamp = appUtils.getCurrentTimestamp(CONFIG.timestampFormat)
                                msgItem.markDisplayed = true;
                                msgItem.formSignedMap = {};
                                angular.forEach(tpComplianceMsgSignedActionMAP.formSignedMap, function(value, key) {
                                    if (key && value === 'Y') {
                                        msgItem.formSignedMap[key] = value;
                                    }
                                });

                            }
                        }
                    });
                }
            },
            removePatientFromBasket: function(patientId) {
                delete basketData[patientId];
            },
            removeAllPatients: function() {
                angular.forEach(basketData, function(profile, profileID) {
                    delete basketData[profileID];
                });
            },
            setBasketPageMsgAlert: function(data) {
                basketPageMsgAlert = data;
            },
            getBasketPageMsgAlert: function() {
                return basketPageMsgAlert;
            },
            setNewPhrEnrollment: function(data) {
                newPhrEnrollment = data;
            },
            getNewPhrEnrollment: function() {
                return newPhrEnrollment;
            },
            setTpComplianceMessageFormSigned: function(type) {
                if (type === 'AOB' || type === 'ABN' || type === 'RRP' || type === 'SS') {
                    tpComplianceMsgSignedActionMAP.formSignedMap[type] = 'Y';
                }
            },
            updateNotDisplayedReason: function(notDisplayedReasonObj) {
                if (notDisplayedReasonObj && Object.keys(notDisplayedReasonObj).length) {
                    angular.forEach(notDisplayedReasonObj, function(messageList, messageListKey) {
                        if (messageList && messageList.length) {
                            var patientIdMap = {};
                            angular.forEach(messageList, function(msgItemVar) {
                                patientIdMap[msgItemVar.rxPatientId] = msgItemVar.rxPatientId;
                            });
                            angular.forEach(patientIdMap, function(patientId, patientIdTemp) {
                                if (messageList && messageList.length && patientIdTemp) {
                                    var patientProfileTemp = basketData[patientIdTemp];
                                    var patientMessageList = patientProfileTemp.patientMessageInfo[messageListKey];
                                    angular.forEach(patientMessageList, function(patiemtMessageItem) {
                                        if (!patiemtMessageItem.markDisplayed) {
                                            angular.forEach(messageList, function(msgItemTemp) {
                                                if (patiemtMessageItem.rxNum == msgItemTemp.rxNum && patiemtMessageItem.refillNum == msgItemTemp.refillNum && patiemtMessageItem.partialFillSeqNum == msgItemTemp.partialFillSeqNum && patiemtMessageItem.editVersionNum == msgItemTemp.editVersionNum && patiemtMessageItem.messageType == msgItemTemp.messageType && patiemtMessageItem.progType == msgItemTemp.progType && patiemtMessageItem.msgSeq == msgItemTemp.msgSeq) {
                                                    patiemtMessageItem.notDisplayedReason = msgItemTemp.notDisplayedReason;
                                                    patiemtMessageItem.disposition = '0';
                                                }
                                            });
                                        }
                                    });
                                }
                            });
                        }
                    });
                }
            },

            //Used to collect the fill info of scaned Item
            getPatientProfileFillListItem:function(patientId, rxNum,refillNum,partialFillSeqNum,editVersionNum){
                var rxItem;
                angular.forEach(basketData[patientId].patientFillInfoList, function(rxItems){
                    if(rxItems.rxNum == rxNum && rxItems.refillNum == refillNum && rxItems.partialFillSeqNum == partialFillSeqNum && rxItems.editVersionNum == editVersionNum){
                            rxItem=rxItems;
                    }
                });

                return rxItem;
            },

            //update Immunization indicator to N once it is displayed.
            updatePatientProfileImmunizationFlag:function(patientId, rxNum,refillNum){
                
                angular.forEach(basketData[patientId].patientFillInfoList, function(rxItems){
                    if(rxItems.patientID == patientId && rxItems.rxNum == rxNum && rxItems.refillNum == refillNum ){
                            rxItems.immunizationDisplayInd = true ;
                    }
                });

            },

            getSelectedPatientProfileFillInfo:function(){
                return selectedRxItemFillInfo;
            },

            setSelectedPatientProfileFillInfo:function(fillInfo){
                selectedRxItemFillInfo=fillInfo;
            }


                        

        };
    });
