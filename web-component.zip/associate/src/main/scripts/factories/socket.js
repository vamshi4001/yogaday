'use strict';

angular.module('weCarePlusApp')
    .constant('SOCKET_STATUS', {
        'CONNECTING': 0,
        'OPEN': 1,
        'CLOSING': 2,
        'CLOSED': 3,
        'RECONNECT_ABORTED': 4
    });

angular.module('weCarePlusApp')
    .factory('$socket', function($rootScope, $q, $timeout, DialogService, SOCKET_STATUS, CONFIG, $location) {
        var socket;
        var url;
        var status;
        var deferredMap = {};

        var connect = function(opts) {
            if (socket) {
                return;
            }
            var deferred = $q.defer();
            var options;
            url = $location.host().match("cvsstore.cvs.com") ? opts.url : "wss://localhost:9900/associate";
            console.log('Connecting to the server. ' + url);
            socket = new WebSocket(url);
            socket.onopen = function(evt) {
                onOpen(evt);
            };

            socket.onclose = function(evt) {
                onClose(evt);
            };

            socket.onmessage = function(evt) {
                onMessage(evt);
            };

            socket.onerror = function(evt) {
                onError(evt);
                deferred.reject({
                    message: 'Error trying to connect the WebSocket with the url ' + url
                });
            };

            // $rootScope.$on('SOCKET_CLOSED', function() {
            //     if (CONFIG.socket.reconnect) {
            //         $timeout(function() {
            //             connect({
            //                 url: url
            //             });
            //         }, 5000);
            //     }
            // });

            $rootScope.$on('SOCKET_OPEN', function() {
                deferred.resolve();
            });
            return deferred.promise;
        };

        var disconnect = function() {
            var deferred = $q.defer();
            if (socket) {
                socket.close();
                deferred.resolve();
            } else {
                deferred.reject({
                    message: 'No active socket WebSocket available'
                });
            }
            return deferred.promise;
        };

        var cancelDeferred = function(deferredKey) {
            if (deferredMap[deferredKey]) {
                deferredMap[deferredKey].reject();
                delete deferredMap[deferredKey];
            }
        };

        var send = function(message, waitResponse, deferredKey) {
            var deferred = $q.defer();
            if (deferredKey) {
                deferredMap[deferredKey] = deferred;
            }
            if (socket && socket.readyState === 1) {
                socket.send(message);
                if (waitResponse && waitResponse === true) {
                    $rootScope.$on('SOCKET_MESSAGE', function(evt, response) {
                        deferred.resolve(response);
                    });
                } else {
                    deferred.resolve();
                }

                $rootScope.$on('SOCKET_ERROR', function(ev, error) {
                    deferred.reject({
                        message: 'Error which sending payload to socket: ' + error.data
                    });
                });

            } else {
                deferred.reject({
                    message: 'No active socket WebSocket available'
                });
            }
            return deferred.promise;
        };

        var clear = function() {
            send(JSON.stringify({
                type: 'CLEAR_SCREEN',
                options: {
                    route: 'home'
                }
            }), true);
        };

        var isActive = function() {
            if (socket) {
                return true;
            }
        };

        var onOpen = function() {
            console.log('Web Socket Open!' + socket.readyState);
            send(JSON.stringify({
                type: 'GET_CONFIG',
                options: {
                    configName: 'hostname'
                }
            }), true).then(function(response) {
                // return;
                CONFIG.workstationID = response.options.hostname;
                CONFIG.registerId = response.options.hostname.slice(-2);
                CONFIG.registerData.id = response.options.hostname.slice(-2);
                CONFIG.registerData.printerQname = 'wcp_pr' + response.options.hostname.slice(-2);
            }, function(err) {

            });
            $rootScope.$broadcast('SOCKET_OPEN');
        };

        var log = function(obj) {
            send(JSON.stringify({
                type: 'LOG',
                options: {
                    message: obj
                }
            }), false);
        }

        var onMessage = function(evt) {
            console.log('WebSocket Message: ' + evt.data);
            var response = JSON.parse(evt.data);
            if (response.type === 'STATUS') {
                $rootScope.$broadcast('SOCKET_STATUS_MSG', response);
            } else if (response.type === 'BARCODE_SCAN') {
                $rootScope.$broadcast('BARCODE_SCAN', response.options);
            } else {
                $rootScope.$broadcast('SOCKET_MESSAGE', response);
            }
        };

        var onError = function(evt) {
            console.log('WS Error: ' + evt.data);
            $rootScope.$broadcast('SOCKET_ERROR', evt);
        };

        var onClose = function() {
            console.log('WebSocket Closed');
            if (CONFIG.socket.reconnect) {
                var modalOptions = {
                    buttons: ['RETRY'],
                    headerText: 'Communication Error',
                    bodyText: "Cannot send data to customer screen. Please rety after 30 seconds."
                };
                DialogService.showDialog({}, modalOptions).then(function(result) {
                    socket = null;
                    connect({
                        url: CONFIG.socket.endpoint
                    });
                });
            };
            $rootScope.$broadcast('SOCKET_CLOSED');
        };

        /*
         *Connect to socket onload
         */
        connect({
            url: CONFIG.socket.endpoint
        });

        if ('WebSocket' in window && window.WebSocket.CLOSING === 2) {
            return {
                send: send,
                clear: clear,
                disconnect: disconnect,
                isActive: isActive,
                log: log,
                cancelDeferred: cancelDeferred
            };
        } else {
            console.log('WebSocket Unsupported !!!');
            return undefined;
        }
    });
