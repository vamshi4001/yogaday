'use strict';

angular.module('weCarePlusApp')
    .factory('PseFactory', function(base64, CONFIG) {
        var identityInfo = {};
        var identityType = '';
        var identityScanData = '';
        var isLicenseIdScaned = false;
        var isItemCanAddToTotal = false;
        var customerSignImage = '';
        var compressedCustomSign = '';
        var isPSEFlagIsDisplayed = false;
        var rphName = '';
        var currentOrderList = [];
        var controlledItem = [];
        var employeeTrackingName = '';
        //All request payload
        var identityRequestPayload = {
            "SrdParseRequest": {
                "parseRequest": {
                    "purposeCode": null,
                    "scanData": "",
                    "clerkId": CONFIG.loggedInUser.id
                }
            }
        };
        //Esig Compressed payload
        var esigCompressedRequestPayload = {
            "eSigCompressionRequest": {
                "base64PNGESig": ""
            }
        };
        //Inquiry Request
        var inquiryRequestPayload = {
            "PseInquiryRequest": {
                "versionNumber": 0,
                "timeStamp": null,
                "trackingID": "",
                "transactionId": null,
                "transactionTime": null,
                "idScan": null,
                "pharmacyInfo": {
                    "ncpdp": null,
                    "pharmacyId": null,
                    "siteId": null,
                    "pharmacyTech": null,
                    "pharmacistApproval": null
                },
                "inquiryDetail": [],
                "objPersonInfo": {
                    "id": "",
                    "idType": "",
                    "issuingAgency": "",
                    "expiration": "",
                    "lastName": "",
                    "firstName": "",
                    "middleName": "",
                    "birthDate": "",
                    "address1": "",
                    "city": "",
                    "state": "",
                    "zip": ""
                }
            }
        };
        //Pse Purchanse Request
        var psePurchaseRequestPayload = {
            "PsePurchaseRequest": {
                "versionNumber": 0,
                "timeStamp": null,
                "trackingID": "",
                "transactionId": "",
                "transactionTime": "",
                "personInfo": {
                    "id": "",
                    "idType": "",
                    "issuingAgency": "",
                    "expiration": "",
                    "lastName": "",
                    "firstName": "",
                    "middleName": "",
                    "birthDate": "",
                    "address1": "",
                    "city": "",
                    "state": "",
                    "zip": ""
                },
                "pharmacyInfo": {
                    "ncpdp": null,
                    "pharmacyId": "",
                    "siteId": "",
                    "pharmacyTech": "",
                    "pharmacistApproval": null
                },
                "inquirysid": 0,
                "purchase": {
                    "strPostSale": "false",
                    "purchaseDetail": []
                },
                "purchaseMetadata": null,
                "signature": {
                    "mimeType": "image/jpg",
                    "value": ""
                }
            }
        };

        var psePrintServiceRequest = {
            "PSEDeclineRequest": {
                "dailyLimit": "",
                "maxLimit": "",
                "days": "",
                "transaction": ""
            }
        };

        var pseReturnRequestPayload = {
            "PseReturnRequest": {
                "versionNumber": 0,
                "timeStamp": null,
                "trackingID": "",
                "transactionId": "",
                "transactionTime": null,
                "personInfo": {
                    "id": "",
                    "idType": "",
                    "issuingAgency": "",
                    "expiration": "",
                    "lastName": "",
                    "firstName": "",
                    "middleName": "",
                    "birthDate": "",
                    "address1": "",
                    "city": "",
                    "state": "",
                    "zip": ""
                },
                "purchaseTransactionId": null,
                "pharmacyInfo": {
                    "ncpdp": null,
                    "pharmacyId": "",
                    "siteId": "",
                    "pharmacyTech": "",
                    "pharmacistApproval": null
                },
                "returnedItems": {
                    "postSale": "true",
                    "purchaseDetail": []
                }
            }
        };

        var isPseRefund = false;
        var pseRefundPayCompleted = false;
        //pse server response
        var identityResponsePayload = {};
        var esigCompressedResponsePayload = {};
        var psePurchaseResponsePayload = {};
        var pseReturnResponsePayload = {};
        var isPserPurchaseIsCompleted = true;

        return {
            getCurrentOrderList: function() {
                return currentOrderList;
            },
            removeFromCurrentOrderList: function(otcItemToVoid) {
                var toRemoveItem = "";
                angular.forEach(currentOrderList, function(otcItem, index) {
                    if (otcItem.upc == otcItemToVoid.upc) {
                        toRemoveItem = index;
                    }
                });
                currentOrderList.splice(toRemoveItem, 1);
                if (currentOrderList && currentOrderList.length === 0) {
                    appUtils.log("No more PSE items in order. Clearing the license cache.")
                    this.clearPSEData();
                }
            },
            setControlledItem: function(item) {
                controlledItem = item;
            },
            getControlledItem: function() {
                return controlledItem;
            },
            addControlledItemToCurrentOrderList: function() {
                if (currentOrderList && controlledItem) {
                    currentOrderList.push(controlledItem);
                }
            },
            setIdentityInfo: function(data) {
                identityInfo = data;
            },
            getIdentityInfo: function() {
                return identityInfo || {};
            },
            setIdentityType: function(data) {
                identityType = data;
            },
            getIdentityType: function() {
                return identityType;
            },
            //storing base64 encode
            setIdentityScanData: function(barcode) {
                identityScanData = base64.encode(barcode);
            },
            getIdentityScanData: function() {
                return identityScanData;
            },
            setIsLicenseIdScaned: function(data) {
                isLicenseIdScaned = data;
            },
            getIsLicenseIdScaned: function() {
                return isLicenseIdScaned;
            },
            getIsItemCanAddToTotal: function() {
                return isItemCanAddToTotal;
            },
            setIsItemCanAddToTotal: function(data) {
                isItemCanAddToTotal = data;
            },
            setCustomerSignImage: function(data) {
                customerSignImage = data;
            },
            getCustomerSignImage: function() {
                return customerSignImage;
            },
            setCompressedCustomSign: function(data) {
                compressedCustomSign = data;
            },
            getCompressedCustomSign: function() {
                return compressedCustomSign;
            },
            isPseRefundPayCompleted: function() {
                return pseRefundPayCompleted;
            },
            setPseRefundPayCompleted: function(newValue) {
                if (newValue) {
                    pseRefundPayCompleted = true;
                } else {
                    pseRefundPayCompleted = false;
                }
            },
            setIsPSEFlagIsDisplayed: function(data) {
                isPSEFlagIsDisplayed = data;
            },
            getIsPSEFlagIsDisplayed: function() {
                return isPSEFlagIsDisplayed;
            },
            clearPSEData: function() {
                identityInfo = {};
                identityType = '';
                identityScanData = '';
                isLicenseIdScaned = false;
                isItemCanAddToTotal = false;
                customerSignImage = '';
                compressedCustomSign = '';
                isPSEFlagIsDisplayed = false;
                isPseRefund = false;
                pseRefundPayCompleted = false;
                isPserPurchaseIsCompleted = true;
                identityResponsePayload = {};
                esigCompressedResponsePayload = {};
                psePurchaseResponsePayload = {};
                pseReturnResponsePayload = {};
                rphName = '';
                employeeTrackingName = '';
                currentOrderList = [];
                controlledItem = [];
            },
            getRphName: function() {
                return rphName;
            },
            setRphName: function(name) {
                rphName = name;
            },
            getTrackedEmployee: function() {
                return employeeTrackingName;
            },
            setTrackedEmployee: function(name) {
                employeeTrackingName = name;
            },

            setIdentityRequestPayload: function(data) {
                identityRequestPayload = data;
            },
            getIdentityRequestPayload: function() {
                return identityRequestPayload;
            },
            setInquiryRequestPayload: function(data) {
                inquiryRequestPayload = data;
            },
            getInquiryRequestPayload: function() {
                return inquiryRequestPayload;
            },
            setPsePurchaseRequestPayload: function(data) {
                psePurchaseRequestPayload = data;
            },
            getPsePurchaseRequestPayload: function() {
                return psePurchaseRequestPayload;
            },
            getIsPseRefund: function() {
                return isPseRefund;
            },
            setIsPseRefund: function(data) {
                isPseRefund = data;
            },
            getEsigCompressedRequestPayload: function() {
                return esigCompressedRequestPayload;
            },
            setEsigCompressedRequestPayload: function(data) {
                esigCompressedRequestPayload = data;
            },
            setIdentityResponsePayload: function(data) {
                identityResponsePayload = data;
            },
            getIdentityResponsePayload: function() {
                return identityResponsePayload;
            },
            setPsePurchaseResponsePayload: function(data) {
                psePurchaseResponsePayload = data;
            },
            getPsePurchaseResponsePayload: function() {
                return psePurchaseResponsePayload;
            },
            getPsePrintServiceRequest: function() {
                return psePrintServiceRequest;
            },
            getPseReturnRequestPayload: function() {
                return pseReturnRequestPayload;
            },
            setIsPserPurchaseIsCompleted: function(data) {
                isPserPurchaseIsCompleted = data;
            },
            getIsPserPurchaseIsCompleted: function() {
                return isPserPurchaseIsCompleted;
            }

        };
    });
