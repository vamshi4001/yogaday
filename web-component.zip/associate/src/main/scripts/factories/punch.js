'use strict';

angular.module('weCarePlusApp')
    .factory('PunchFactory', function(Request) {
        var employeeId = "";
        var managerId = "";
        var managerFlag = false;

        var PUNCH_CODE_LONG_IN_RX = "In";
        var PUNCH_CODE_SHORT_IN_RX = "R";
        var PUNCH_CODE_LONG_OUT = "Out";
        var PUNCH_CODE_SHORT_OUT = "O";

        function formatCurrentDate() {
            var date = new Date();
            var day = ('0' + date.getDate()).slice(-2);
            var month = ('0' + (date.getMonth() + 1)).slice(-2);
            var year = date.getFullYear().toString().substr(2, 2);
            return year + month + day;
        }

        function getCurrentTime() {
            var dateObj = new Date();
            var curr_min = dateObj.getMinutes();
            var curr_hr = dateObj.getHours();
            var curr_sc = dateObj.getSeconds();

            if (curr_hr.toString().length == 1)
                curr_hr = '0' + curr_hr;
            if (curr_min.toString().length == 1)
                curr_min = '0' + curr_min;
            if (curr_sc.toString().length == 1)
                curr_sc = '0' + curr_sc;


            return curr_hr + curr_min + curr_sc;
        }

        return {
            setEmployeeId: function(data) {
                employeeId = data;

            },
            getEmployeeId: function() {
                return employeeId;
            },
            setManagerId: function(data) {
                managerId = data;

            },
            getManagerId: function() {
                return managerId;
            },
            setManagerFlag: function(data) {
                managerFlag = data;
            },
            getManagerFlag: function() {
                return managerFlag;
            },
            authenticateEmployee: function(employeePwd) {

                var validatePromise = Request.invoke({
                    url: appConfig.store.services.API.employees + '?emp_id=' + employeeId + '&pin=' + employeePwd,

                        method: 'GET'

                });

                return validatePromise;
            },
            punchEmployee: function(type) {


                //
                var currTimeInMS = new Date().getTime();
                var hour = currTimeInMS;
                var time = currTimeInMS;
                var punchCodeLong = "";
                var punchCodeShort = "";

                switch (type) {
                    case "In":
                        punchCodeLong = PUNCH_CODE_LONG_IN_RX;
                        punchCodeShort = PUNCH_CODE_SHORT_IN_RX;
                        break;
                    case "Out":
                        punchCodeLong = PUNCH_CODE_LONG_OUT;
                        punchCodeShort = PUNCH_CODE_SHORT_OUT;
                }

                var punchDetails = {
                    empPunchHour: hour,
                    empPunchTime: time,
                    punchIdType: 'P',
                    employeeId: employeeId,
                    punCodeLong: punchCodeLong,
                    punCodeShort: punchCodeShort,
                    managerOverrideFlag: managerFlag ? '1' : '0',
                    actualSequenceNumber: 1,
                    apprStatCode: "a",
                    txnStatus: "P"
                }

                var payload = {
                    PunchDetail: punchDetails
                };

                var punchPromise = Request.invoke({
                    url: appConfig.store.services.API.punchinout,
                    method: 'POST',
                    data: payload
                });

                return punchPromise;

            }

        }


    });
