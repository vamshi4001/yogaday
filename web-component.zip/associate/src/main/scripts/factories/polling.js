'use strict';

angular.module('weCarePlusApp')
    .factory('PollingFactory', function(Request, CONFIG) {
        var defaultPollingTime = CONFIG.DEFAULT_POLL_INTERVAL;
        var polls = {};
        var obj = {};
        obj.startPolling = function(name, url, pollingTime, callback) {
            // Check to make sure poller doesn't already exist
            if (!polls[name]) {
                var poller = function() {
                    Request.invoke({
                        url: url,
                        method: 'GET'
                    }).then(callback);
                }
                poller();
                polls[name] = setInterval(poller, pollingTime || defaultPollingTime);
            }
        };

        obj.stopPolling = function(name) {
            clearInterval(polls[name]);
            delete polls[name];
        };
        obj.dailyConfigPolling = function() {
            angular.forEach(appConfig.store.services.API.dailyConfig, function(dailyConfigValue, dailyConfigKey) {
                if (dailyConfigValue.active) {
                    obj.startPolling(dailyConfigKey, dailyConfigValue.endpoint, dailyConfigValue.interval, function(data) {
                        DAILY_CONFIG[dailyConfigKey] = data;
                    });
                } else {
                    
                }
            });
        };
        return obj;
    });
