'use strict';

angular.module('weCarePlusApp')
    .factory('ESignFactory', function($location, Request, BasketFactory, OrderFactory, CONFIG) {
        var eSignConfigData = {};
        var eSignConfigDataMap = {};
        var eSignCustData = [];
        var eSignAssocData = [];
        var posSignatureRequest = {};
        var obj = {};
        var eSignRxNumberList = [];
        var eSignCustDataHTML = '';
        //Esign Agent and Customer Screen Config
        var esignAgentConfigData = {};
        var esignCustomerConfigData = {};
        var esignCustomerConfigDataHTML = '';
        var esignCustomPaymentDataList = [];
        var rxInfoMap = {};
        var esigMasterData = {};
        var abnGSelectionMap = {
            '1': 'Option 1',
            '2': 'Option 2',
            '3': 'Option 3'
        };

        obj.doFastpassCompleteCancel = function(opts) {
            opts = opts ? opts : {};
            Request.invoke({
                url: '/service/bsl/fastpass/transaction/status/02?transId=' + OrderFactory.getFastpassData().transactionID,
                method: 'POST',
                data: {
                    "UpdateTransactionStatusReq": {
                        "statusData": {
                            "printedNameRequired": BasketFactory.getTpCompliancePatESign(),
                            "assentText": "",
                            "signatureRequired": true
                        },
                        "transactionID": OrderFactory.getFastpassData().transactionID,
                        "userID": OrderFactory.getFastpassData().userID,
                        "statusCode": opts.statusCode || "0",
                        "statusMessage": opts.statusMessage || "Complete"
                    }
                }
            });
        };

        obj.buildEsignConfigData = function(data) {
            esignAgentConfigData = {};
            rxInfoMap = {};

            var basketData = BasketFactory.getBasketData();
            angular.forEach(basketData, function(patientProfile, patientId) {
                angular.forEach(patientProfile.patientFillInfoList, function(rxInfo) {
                    var rxKey = rxInfo.rxNum + appUtils.prepandZeros((rxInfo.refillNum || 0), 2);
                    rxInfoMap[rxKey] = {
                        rxInfo: rxInfo,
                        patientId: patientId,
                        patientDetails: patientProfile.patientDetails
                    };
                });
            });

            angular.forEach(data.registerMessage, function(esigMessageItem) {
                //Check for main register text as there can be scenarios that message has only the payment terminal messages
                if (esigMessageItem.messageType === 'COUNSELING' && esigMessageItem.mainRegisterText) {
                    if (esigMessageItem.patientFillMessageList && esigMessageItem.patientFillMessageList.patientfillinfo.length) {
                        var patientRxFillListMap = {};
                        var showEsignCounsel = 0;
                        angular.forEach(esigMessageItem.patientFillMessageList.patientfillinfo, function(rxInfo) {
                            var flag = true;
                            var rxInfoKey = rxInfo.rxNum + appUtils.prepandZeros((rxInfo.refillNum || 0), 2);
                            var tempObj = rxInfoMap[rxInfoKey];
                            if (tempObj) {
                                if (patientRxFillListMap[tempObj.patientId]) {
                                    patientRxFillListMap[tempObj.patientId].rxInfoList.push(tempObj.rxInfo);
                                    showEsignCounsel++;
                                } else {
                                    patientRxFillListMap[tempObj.patientId] = {
                                        patientDetails: tempObj.patientDetails,
                                        rxInfoList: [tempObj.rxInfo]
                                    };
                                    showEsignCounsel++;
                                }
                            }
                        });
                        if (Object.keys(patientRxFillListMap).length && esigMessageItem.mainRegisterText) {
                            esignAgentConfigData[esigMessageItem.messageType] = {
                                data: esigMessageItem,
                                showAcceptDecline: esigMessageItem.acceptDecline.captureAcceptDeclineRequired === 'Y',
                                showEsignCounsel: (showEsignCounsel > 1) ? true : false,
                                patientRxFillListMap: patientRxFillListMap,
                                infoText: esigMessageItem.mainRegisterText
                            };
                        }
                    }
                } else if (esigMessageItem.messageType && esigMessageItem.mainRegisterText && esigMessageItem.messageType !== 'ReadyFill' && esigMessageItem.messageType !== 'AutoFill') {
                    var rxNumInfoList = [];
                    var rxInfoString = '';
                    var rxInfoArray = [];

                    //Build the list of Rxs for each message
                    if (esigMessageItem.messageType === 'Confirm ABN') {
                        angular.forEach(esigMessageItem.patientFillMessageList.patientMessage, function(messageItem){
                            var abnGSelectionValue = abnGSelectionMap[messageItem.posABNSectionGSelection];
                            var abnHSelectionValue = messageItem.posABNSectionHSelection ? 'Representative' : 'Patient (Section H Blank)';
                            var rxKey = messageItem.rxNum + ' ' +
                            appUtils.prepandZeros((messageItem.refillNum || 0), 2) 
                            + " - Section G " + abnGSelectionValue + ', ' + abnHSelectionValue;
                            rxNumInfoList.push(rxKey);
                        });
                    } else {
                        angular.forEach(esigMessageItem.patientFillMessageList.patientfillinfo, function(rxInfo){
                            var rxKey = rxInfo.rxNum + ' ' + appUtils.prepandZeros((rxInfo.refillNum || 0), 2);
                            rxInfoArray.push(rxKey);
                        });
                        rxInfoString = rxInfoArray.join(", ");
                        rxNumInfoList.push(rxInfoString);
                    }

                    if (rxNumInfoList.length) {
                        if (esigMessageItem.mainRegisterText) {
                            esignAgentConfigData[esigMessageItem.messageType] = {
                                infoText: esigMessageItem.mainRegisterText,
                                rxNumInfo: rxNumInfoList
                            };
                        }
                    } else {
                        if (esigMessageItem.mainRegisterText) {
                            esignAgentConfigData[esigMessageItem.messageType] = {
                                infoText: esigMessageItem.mainRegisterText,
                                rxNumInfo: []
                            };
                        }
                    }
                }
            });
        };

        obj.builPaymentConfigData = function(data) {
            var esignCustomerConfigDataArrTemp = [];
            eSignRxNumberList = [];
            esignCustomerConfigDataHTML ='';
            esignCustomPaymentDataList = [];

            //payment terminal text content
            angular.forEach(data.paymentPromptMessageContent, function(message) {
                message = message.trim();
                if (message && esignCustomerConfigDataArrTemp.indexOf(message) === -1) {
                    esignCustomerConfigDataArrTemp.push(message);
                    esignCustomerConfigDataHTML += '<br>' + message;
                }
            });

            //payment terminal rxNum list
            angular.forEach(data.paymentPromptFillInfo, function(fillInfo){
                if (fillInfo && eSignRxNumberList.indexOf(fillInfo.rxNum) === -1) {
                    eSignRxNumberList.push(fillInfo.rxNum);
                }   
            });

            angular.forEach(data.paymentMessageList, function(paymentMessage){
                var customPaymentData = {};
                var messageText = '';
                var rxNumInfoList = [];
                if (paymentMessage.message && paymentMessage.patientMessage.length) {
                    messageText = paymentMessage.message;
                    paymentMessage.patientMessage.map(function(messageItem){
                        var abnGSelectionValue = abnGSelectionMap[messageItem.posABNSectionGSelection];
                        var abnHSelectionValue = messageItem.posABNSectionHSelection ? 'Representative' : 'Patient (Section H Blank)';
                        var rxKey = 'Rx' + messageItem.rxNum + ' ' +
                        appUtils.prepandZeros((messageItem.refillNum || 0), 2) 
                        + " - Section G " + abnGSelectionValue + ', ' + abnHSelectionValue;
                        rxNumInfoList.push(rxKey);
                    });
                    customPaymentData = {
                        infoText: '- ' + paymentMessage.message,
                        rxNumInfoList: rxNumInfoList
                    }
                    esignCustomPaymentDataList.push(customPaymentData);
                }
            });
        }

        obj.getEsignAgentConfigData = function() {
            return esignAgentConfigData;
        };

        obj.getEsignCustomerConfigData = function() {
            return esignCustomerConfigData;
        };

        obj.getEsignCustomPaymentData = function() {
            return esignCustomPaymentDataList;
        };

        obj.updateEsignDisposition = function (outcomeDisposition) {
            angular.forEach(outcomeDisposition, function(msgDisposition, key){
                esigMasterData.registerMessage.map(function(messageItem){
                    if (messageItem.messageType === key) {
                        messageItem.outcome = msgDisposition;
                    }
                });
            });
        }

        obj.getESignConfigData = function() {
            return eSignConfigData;
        };
        obj.getESignConfigDataMap = function() {
            return eSignConfigDataMap;
        };
        obj.getESCCustData = function() {
            return eSignCustData;
        };
        obj.getESCAssocData = function() {
            return eSignAssocData;
        };
        obj.getEsignCustomerConfigDataHTML = function() {
            return esignCustomerConfigDataHTML;
        };
        obj.getPosSignatureRequest = function() {
            return posSignatureRequest;
        };
        obj.setPosSignatureRequest = function(data) {
            posSignatureRequest = data;
        };

        obj.getEsingConfigRxList = function() {
            return eSignRxNumberList;
        };

        obj.setEsigMasterData = function(data) {
            esigMasterData = data;
        }

        obj.getEsigMasterData = function() {
            return esigMasterData;
        }
        obj.clearEsigFactory = function() {
            eSignConfigData = {};
            eSignConfigDataMap = {};
            eSignCustData = [];
            eSignAssocData = [];
            eSignCustDataHTML = '';
            posSignatureRequest = {};
            eSignRxNumberList = [];
            esignAgentConfigData = {};
            esignCustomerConfigData = {};
            esignCustomerConfigDataHTML = '';
        };
        return obj;
    });
