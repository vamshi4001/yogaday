'use strict';

angular.module('weCarePlusApp')
    .factory('LoginFactory', function() {
        var userId;
        var password;
        var authToken = '';
        var empDetails = {};
        return {

            setUserId: function(data) {
                userId =data;
            },
            getUserId: function() {
                return userId;
            },
            setPassword: function(data) {
                password = data;
            },
            getPassword: function() {
                return password;
            },
            setAuthToken: function(data) {
                authToken = data;
            },
            getAuthToken: function() {
                return authToken;
            },
            setEmpDetails: function(data) {
                 empDetails = data;
            },
            getEmpDetails: function() {
                return empDetails;
            }


        };
    });
