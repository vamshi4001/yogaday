'use strict';

angular.module('weCarePlusApp')
    .factory('MessageFactory', function($location, Request, ESignFactory, BasketFactory, $route) {
        var patientMessage = {};
        var patientMessageList = [];
        var messageData = {};
        var collectedData = {};
        var currentIndex = 0;
        var isOfflineMessagingDone = false;
        var indexSize = 0;
        var obj = {};
        var basketData = BasketFactory.getBasketData();
        var fillInfoMap = {};
        var tmplKey;
        var tmplNameOld;
        var patientMessageRxInfoMap = {};
        var rxnumRefillNumList = [];
        var pickUpDataObj = {};
        var dispositionMap = {};
        var dispositionMapNotInBasket = {};
        var patientIdSoldDispositionMap = {};
        var notDisplayedReasonData = {};
        
        //TCPA as per New Message FrameWork
        var hasTcpaMessage = false;
        var patDemoMessage = {};
        var tcpaMessage = {};
        var tcpaBack = false;
        var tcpaEsignBack = false;
        var tcpaEsignBackInitFnc = false;

        /*Message Framework START */
        //Compile Message Response and Display Next Message Input
        var masterMessageList = [];
        var currentMessageIndex = null;
        /*END*/

        obj.setCurrentMessageIndex = function(data) {
            currentMessageIndex = data;
        };
        obj.getCurrentMessageIndex = function() {
            return currentMessageIndex;
        };
        obj.setMasterMessageList = function(data) {
            masterMessageList = data;
        };
        obj.getMasterMessageList = function() {
            return masterMessageList;
        };
        obj.setHasTcpaMessage = function(data) {
            hasTcpaMessage = data;
        };
        obj.getHasTcpaMessage = function() {
            return hasTcpaMessage;
        };
        obj.getIsOfflineMessagingDone = function() {
            return isOfflineMessagingDone;
        };

        obj.setIsOfflineMessagingDone = function(status) {
            isOfflineMessagingDone = status;
        };

        obj.setTcpaBack = function(data) {
            tcpaBack = data;
        };

        obj.setTcpaEsignBack = function(data) {
            tcpaEsignBack = data;
            tcpaBack = data;
            tcpaEsignBackInitFnc = data;
        };

        obj.setTcpaEsignBackInitFnc = function(data) {
            tcpaEsignBackInitFnc = data;
        };

        obj.resolvedTcpaMessage = function() {
            patDemoMessage = null;
            tcpaMessage = null;
            hasTcpaMessage = false;
            tcpaEsignBack = false;
            tcpaBack = false;
            tcpaEsignBackInitFnc = false;
        };

        obj.getTcpaBack = function() {
            return tcpaBack;
        };

        obj.getTcpaEsignBack = function() {
            return tcpaEsignBack;
        };

        obj.getTcpaEsignBackInitFnc = function() {
            return tcpaEsignBackInitFnc;
        };

        obj.setDispositionMap = function(key, value) {
            dispositionMap[key] = value;
        };
        obj.getDispositionMap = function() {
            return dispositionMap;
        };
        obj.resetDispositionMap = function () {
            dispositionMap = {};
            return dispositionMap;  
        }
        obj.setDispositionMapNotInBasket = function(key, value) {
            dispositionMapNotInBasket[key] = value;
        };
        obj.getDispositionMapNotInBasket = function() {
            return dispositionMapNotInBasket;
        };
        obj.resetDispositionMapNotInBasket = function () {
            dispositionMapNotInBasket = {};
            return dispositionMapNotInBasket;  
        }
        obj.setPatientIdSoldDispositionMap = function(key, value) {
            patientIdSoldDispositionMap[key] = value;
        };
        obj.getPatientIdSoldDispositionMap = function() {
            return patientIdSoldDispositionMap;
        };
        obj.setPickUpDataObj = function(data) {
            pickUpDataObj = data;
        };

        obj.getPickUpDataObj = function() {
            return pickUpDataObj || {};
        };

        obj.setTmplNameOld = function(data) {
            tmplNameOld = data;
        };

        obj.setPatientMessage = function(data) {
            patientMessage = data;
        };
        obj.getPatientMessage = function() {
            return patientMessage;
        };
        obj.setPatientMessageList = function(data) {
            patientMessageList = data;
        };
        obj.getPatientMessageList = function() {
            return patientMessageList;
        };
        obj.setCurrentIndex = function(index) {
            currentIndex = index;
        };
        obj.getCurrentIndex = function() {
            return currentIndex;
        };
        obj.setIndexSize = function(length) {
            indexSize = length;
        };
        obj.getIndexSize = function() {
            return indexSize;
        };
        obj.getPatDemoMessage = function() {
            return patDemoMessage;
        };
        obj.setPatDemoMessage = function(data) {
            patDemoMessage = data;
        };
        obj.getTcpaMessage = function() {
            return tcpaMessage;
        };
        obj.setTcpaMessage = function(data) {
            tcpaMessage = data;
        };
        obj.getRxnumRefillNumList = function() {
            return rxnumRefillNumList;
        };
        obj.getNextMessage = function(data) {
            if (data) {
                basketData = data;
            }
            rxnumRefillNumList = [];
            dispositionMap = {};
            tcpaBack = false;
            var patientMessagePromiseTemp = Request.invoke({
                url: appConfig.store.services.API.getNextMessage,
                method: 'POST'
            });
            patientMessagePromiseTemp.then(function(result) {
                if (result) {
                    if (result && result.messagesNotDisplayedCount >= 0) {
                        notDisplayedReasonData = angular.copy(result);
                        if (notDisplayedReasonData.messagesNotDisplayedCount && notDisplayedReasonData.PatientMessageInfo) {
                            BasketFactory.updateNotDisplayedReason(notDisplayedReasonData.PatientMessageInfo);
                        }
                        dispositionMap = {};
                        tmplNameOld = undefined;
                        patientMessage = {};
                        patientMessageList = [];
                        fillInfoMap = {};
                        patientMessageRxInfoMap = {};
                        ESignFactory.showEsign();
                    } else {
                        patientMessageList = result;
                        indexSize = patientMessageList.length;
                        patientMessage = patientMessageList[0];
                        tmplKey = patientMessage.messageType + '-' + patientMessage.progType;
                        if (tmplKey == '7-1' && patientMessageList.length > 1) {
                            tmplKey = patientMessageList[1].messageType + '-' + patientMessageList[1].progType;
                            tcpaMessage = patientMessageList[1];
                            patDemoMessage = patientMessageList[0];
                        } else if (tmplKey == '6-3') {
                            if (patientMessageList.length > 1) {
                                tcpaMessage = patientMessageList[0];
                                patDemoMessage = patientMessageList[1];
                            } else {
                                //Tcpa need both demographic and tcpa
                                obj.getNextMessage();
                                return;
                            }
                        }
                        angular.forEach(patientMessageList, function(msgItem) {
                            if (tmplKey == '8-1') {
                                rxnumRefillNumList.push(appUtils.prepandZeros(msgItem.rxNum, 7) + ' ' + appUtils.prepandZeros((msgItem.partialFillSeqNum || 0), 3));
                            }
                            if (msgItem.rxPatientId && msgItem.rxNum) {
                                var pprItem = basketData[msgItem.rxPatientId];
                                if (pprItem) {
                                    var fillInfoList = pprItem.patientFillInfoList;
                                    angular.forEach(fillInfoList, function(fillInfo) {
                                        if (msgItem.rxNum === fillInfo.rxNum && fillInfo.fillDisposition.dispositionKey === 'SLD') {
                                            var partialBarcodeMsgItem = obj.buildPartialRxbarcodeMsgItem(msgItem);
                                            var partialBarcodeFillInfo = obj.buildPartialRxbarcode(fillInfo);
                                            fillInfoMap[partialBarcodeMsgItem] = fillInfo;
                                            if (tmplKey == '5-1' && fillInfo.readyFillInd == 'N') {
                                                fillInfo.refillNum = fillInfo.refillNum ? fillInfo.refillNum : 0;
                                                //Readyfill - RxCentric
                                                var data = {
                                                    fillInfo: fillInfo,
                                                    messageInfo: msgItem,
                                                    partialBarcode: appUtils.prepandZeros(fillInfo.rxNum, 7)
                                                };
                                                if (patientMessageRxInfoMap[msgItem.rxPatientId]) {
                                                    var prevData = patientMessageRxInfoMap[msgItem.rxPatientId];
                                                    if (prevData && prevData.length) {
                                                        var noRxFound = true;
                                                        angular.forEach(prevData, function(tempItem) {
                                                            if (tempItem.fillInfo.rxNum === fillInfo.rxNum) {
                                                                if (parseInt(fillInfo.refillNum) > parseInt(tempItem.fillInfo.refillNum)) {
                                                                    tempItem.fillInfo = fillInfo;
                                                                }
                                                                noRxFound = false;
                                                            }
                                                        });
                                                        if (noRxFound) {
                                                            patientMessageRxInfoMap[msgItem.rxPatientId].push(data);
                                                        }
                                                    }
                                                } else {
                                                    patientMessageRxInfoMap[msgItem.rxPatientId] = [data];
                                                }
                                            }
                                        }
                                    });
                                }
                            }
                        });
                        if (tmplKey == '8-1' && patientMessage.srdConfigRule) {
                            tmplKey += '-' + patientMessage.srdConfigRule.promptAtPos[0].promptName;
                        }
                        var tmplName = TEMPLATE_MAP.messages[tmplKey];
                        if (patientMessage.messageType == 2) {
                            if (tmplNameOld && tmplName === tmplNameOld) {
                                BasketFactory.setBasketPageMsgAlert(true);
                                $route.reload();
                                return;
                            } else {
                                tmplNameOld = tmplName;
                            }
                            BasketFactory.setBasketPageMsgAlert(true);
                            $location.url('/basket');
                            return;
                        }
                        if (tmplName) {
                            if (tmplNameOld && tmplName === tmplNameOld) {
                                $route.reload();
                                return;
                            } else {
                                tmplNameOld = tmplName;
                            }
                            $location.url('/messages/' + tmplName);
                        } else {
                            obj.getNextMessage();
                            return;
                        }
                    }
                } else {
                    //Ideally else condition shouldn't execute since not displayed reason will be last response instead of NULL payload.
                    dispositionMap = {};
                    tmplNameOld = undefined;
                    patientMessage = {};
                    patientMessageList = [];
                    fillInfoMap = {};
                    patientMessageRxInfoMap = {};
                    ESignFactory.showEsign();
                }
            }, function(result) {
                appUtils.log('GET NEXT MESSAGE ERROR :' + JSON.stringify(result));
            });
        };
        obj.buildPartialRxbarcode = function(rxInfo) {
            var rxnum = appUtils.prepandZeros(rxInfo.rxNum, 7);
            var reFillNum = appUtils.prepandZeros((rxInfo.refillNum || 0), 3);
            // var editVerNum = appUtils.prepandZeros((rxInfo.editVersionNum || 0), 3);
            var parFillSeqNum = appUtils.prepandZeros((rxInfo.partialFillSeqNum || 0), 2)
            return (rxnum + reFillNum + '' + parFillSeqNum);
        };
        obj.buildPartialRxbarcodeMsgItem = function(msgItem) {
            var rxnum = appUtils.prepandZeros(msgItem.rxNum, 7);
            var reFillNum = appUtils.prepandZeros((msgItem.refillNum || 0), 3);
            // var editVerNum = appUtils.prepandZeros((msgItem.editVersionNum || 0), 3);
            var parFillSeqNum = appUtils.prepandZeros((msgItem.partialFillSeqNum || 0), 2)
            return (rxnum + reFillNum + '' + parFillSeqNum);
        };
        obj.getFillInfoMap = function() {
            return fillInfoMap;
        };
        obj.getCurrentFillInfo = function() {
            return fillInfoMap[obj.buildPartialRxbarcodeMsgItem(patientMessage)] || {};
        };
        obj.getCurrentPPR = function() {
            return basketData[patientMessage.rxPatientId];
        };
        obj.getTmplKey = function() {
            return tmplKey;
        };
        obj.getPatientMessageRxInfoMap = function() {
            return patientMessageRxInfoMap;
        };
        obj.clearData = function() {
            collectedData = {};
            isOfflineMessagingDone = false;
            currentIndex = 0;
            dispositionMap = {};
            fillInfoMap = {};
            indexSize = 0;
            messageData = {};
            patientMessage = {};
            patientMessageList = [];
            patientMessageRxInfoMap = {};
            pickUpDataObj = {};
            rxnumRefillNumList = [];
            tmplNameOld = undefined;
            notDisplayedReasonData = {};
            masterMessageList = [];
            currentMessageIndex = null;

            // For TCPA - PHANI
            tcpaMessage = null;
            tcpaBack = false;
            patDemoMessage = null; 
            tcpaEsignBack = false;
            hasTcpaMessage = false;
            tcpaEsignBackInitFnc = false;
        };
        obj.getNotDisplayedReasonData = function() {
            return notDisplayedReasonData;
        };
        return obj;
    });
