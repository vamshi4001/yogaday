'use strict';

// Here, we define our app/module.
angular.module('weCarePlusApp', [
        'ngCookies',
        'ngResource',
        'ngRoute',
        'ngSanitize',
        'ui.bootstrap',
        'utf8-base64'
    ])
    .config(function($routeProvider) {
        // Here we define all of the app routes we'll support.
        $routeProvider
        // Login page
            .when('/login', {
                templateUrl: 'views/login.html',
                controller: 'LoginCtrl',
                resolve: {
                    terminalData: TerminalCtrl.loadData
                }
            })
            .when('/password', {
                templateUrl: 'views/password.html',
                controller: 'LoginCtrl'
            })
            .when('/', {
                templateUrl: 'views/login.html',
                controller: 'LoginCtrl',
                resolve: {
                    terminalData: TerminalCtrl.loadData
                }
            })
            // Home page
            .when('/home', {
                templateUrl: 'views/home.html',
                controller: 'HomeCtrl'
            })
            // Patient page
            .when('/patient-lookup', {
                templateUrl: 'views/patient-lookup.html',
                controller: 'PatientCtrl'
            })
            .when('/patient-list', {
                templateUrl: 'views/patient-list.html',
                controller: 'PatientCtrl'
            })
            .when('/basket', {
                templateUrl: 'views/basket.html',
                controller: 'BasketCtrl'
            })
            .when('/esign-log', {
                templateUrl: 'views/esign-log.html',
                controller: 'EsigLogCtrl'
            })
            .when('/esign-select', {
                templateUrl: 'views/esign-select.html',
                controller: 'EsigSelectCtrl'
            })
            .when('/patient-match', {
                templateUrl: 'views/patient-match.html',
                controller: 'PatientCtrl'
            })
            .when('/dob-validation', {
                templateUrl: 'views/dob-validation.html',
                controller: 'PatientCtrl'
            })
            .when('/license', {
                templateUrl: 'views/license.html',
                controller: 'PseCtrl'
            })
            .when('/license-entry', {
                templateUrl: 'views/license-entry.html',
                controller: 'PseCtrl'
            })
            .when('/transaction-details', {
                templateUrl: 'views/transaction-details.html',
                controller: 'TxnDetailCtrl'
            })
            .when('/messages/:tmplName', {
                templateUrl: function(params) {
                    return 'views/messages/' + params.tmplName + '.html';
                },
                controller: 'MessageCtrl'
            })
            .when('/prescription-basket', {
                templateUrl: 'views/prescription-basket.html',
                controller: 'PatientCtrl'
            })
            // Error page
            .when('/error', {
                templateUrl: 'error.html',
                controller: 'HomeCtrl'
            })
            .when('/verify-associate', {
                templateUrl: 'views/verify-associate.html',
                controller: 'PatientCtrl'
            })
            .when('/phone-lookup', {
                templateUrl: 'views/phone-lookup.html',
                controller: 'HomeCtrl'
            })
            .when('/patient-list-by-phone', {
                templateUrl: 'views/patient-list-by-phone.html',
                controller: 'HomeCtrl'
            })
            .when('/agent-punch', {
                templateUrl: 'views/agent-punch.html',
                controller: 'PunchCtrl'
            })

        // Error page
        .otherwise({
            redirectTo: '/error'
        })

    })

// Cache templates.  When the app loads, Angular will have the
// browser make a series of requests for these files and store
// then in the $templateCache service.
.run(function($templateCache, $http) {
	//dialogs views
    $http.get('views/dialogs/block-ui.html', {
        cache: $templateCache
    });
    $http.get('views/dialogs/loading.html', {
        cache: $templateCache
    });
    //directives views
    $http.get('views/directives/calender.html', {
        cache: $templateCache
    });
    $http.get('views/directives/fourButtons.html', {
        cache: $templateCache
    });
    $http.get('views/directives/keyboard.html', {
        cache: $templateCache
    });
    $http.get('views/directives/numpad.html', {
        cache: $templateCache
    });
    $http.get('views/directives/searching.html', {
        cache: $templateCache
    });
    $http.get('views/directives/singleInputPage.html', {
        cache: $templateCache
    });
    $http.get('views/directives/threeButtons.html', {
        cache: $templateCache
    });
    //includes views
    $http.get('views/includes/footer.html', {
        cache: $templateCache
    });
    $http.get('views/includes/header.html', {
        cache: $templateCache
    });
    //messages views
    $http.get('views/messages/modals/popup-select-dropdown.html', {
        cache: $templateCache
    });
    $http.get('views/messages/modals/select-idtype.html', {
        cache: $templateCache
    });
    $http.get('views/messages/modals/select-relation.html', {
        cache: $templateCache
    });
    $http.get('views/messages/1-67.html', {
        cache: $templateCache
    });
    $http.get('views/messages/4-1.html', {
        cache: $templateCache
    });
    $http.get('views/messages/6-2-2.html', {
        cache: $templateCache
    });
    $http.get('views/messages/extra-care.html', {
        cache: $templateCache
    });
    $http.get('views/messages/message-centric.html', {
        cache: $templateCache
    });
    $http.get('views/messages/patient-counseling.html', {
        cache: $templateCache
    });
    $http.get('views/messages/patient-demographic.html', {
        cache: $templateCache
    });
    $http.get('views/messages/ready-fill.html', {
        cache: $templateCache
    });
    $http.get('views/messages/ready-fill-unenroll.html', {
        cache: $templateCache
    });
    $http.get('views/messages/ready-fill-lite.html', {
        cache: $templateCache
    });
    $http.get('views/messages/drive-ready-fill.html', {
        cache: $templateCache
    });
    $http.get('views/messages/auto-fill-confirmation.html', {
        cache: $templateCache
    });
    $http.get('views/messages/is-patient-present.html', {
        cache: $templateCache
    });
    $http.get('views/messages/retail-auto.html', {
        cache: $templateCache
    });
    $http.get('views/messages/sms-enrollement.html', {
        cache: $templateCache
    });
    $http.get('views/messages/srd-patient-id.html', {
        cache: $templateCache
    });
    $http.get('views/messages/srd-pickup-id.html', {
        cache: $templateCache
    });
    $http.get('views/messages/tcpa.html', {
        cache: $templateCache
    });
    //modals views
    $http.get('views/modals/active-note.html', {
        cache: $templateCache
    });
    $http.get('views/modals/barcode-entry.html', {
        cache: $templateCache
    });
    $http.get('views/modals/barcode.html', {
        cache: $templateCache
    });
    $http.get('views/modals/basket-rx-item.html', {
        cache: $templateCache
    });
    $http.get('views/modals/contact-update.html', {
        cache: $templateCache
    });
    $http.get('views/modals/emp-mgmt.html', {
        cache: $templateCache
    });
    $http.get('views/modals/enrollment-status.html', {
        cache: $templateCache
    });
    $http.get('views/modals/esig-confirm.html', {
        cache: $templateCache
    });
    $http.get('views/modals/helpBarcodeEntry.html', {
        cache: $templateCache
    });
    $http.get('views/modals/hipaa-form.html', {
        cache: $templateCache
    });
    $http.get('views/modals/medicare_form.html', {
        cache: $templateCache
    });
    $http.get('views/modals/offline_medicare_form.html', {
        cache: $templateCache
    });
    $http.get('views/modals/relationship_to_patient.html', {
        cache: $templateCache
    });
    $http.get('views/modals/unscanned-rx-list.html', {
        cache: $templateCache
    });
    //views pages
    $http.get('views/agent-punch.html', {
        cache: $templateCache
    });
    $http.get('views/basket.html', {
        cache: $templateCache
    });
    $http.get('views/dob-validation.html', {
        cache: $templateCache
    });
    $http.get('views/esign-log.html', {
        cache: $templateCache
    });
    $http.get('views/esign-select.html', {
        cache: $templateCache
    });
    $http.get('views/home.html', {
        cache: $templateCache
    });
    $http.get('views/license-entry.html', {
        cache: $templateCache
    });
    $http.get('views/license.html', {
        cache: $templateCache
    });
    $http.get('views/login.html', {
        cache: $templateCache
    });
    $http.get('views/password.html', {
        cache: $templateCache
    });
    $http.get('views/patient-list-by-phone.html', {
        cache: $templateCache
    });
    $http.get('views/patient-list.html', {
        cache: $templateCache
    });
    $http.get('views/patient-lookup.html', {
        cache: $templateCache
    });
    $http.get('views/patient-match.html', {
        cache: $templateCache
    });
    $http.get('views/phone-lookup.html', {
        cache: $templateCache
    });
    $http.get('views/prescription-basket.html', {
        cache: $templateCache
    });
    $http.get('views/transaction-details.html', {
        cache: $templateCache
    });
    $http.get('views/verify-associate.html', {
        cache: $templateCache
    });
});
