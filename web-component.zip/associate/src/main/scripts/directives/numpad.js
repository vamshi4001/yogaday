'use strict';

angular.module('weCarePlusApp')
    .directive('numpad', function() {
        return {
            restrict: 'E',
            templateUrl: 'views/directives/numpad.html',
            link: function(scope, elem, attrs) {
                scope.row1 = ['1', '2', '3'];
                scope.row2=  ['4', '5', '6'];
                scope.row3=  ['7', '8', '9'];
                scope.row4=  ['0','00'];

                scope.onClick = function(keyType, keyValue, event) {
                    event.preventDefault();
                    /*
                     * The default action is prevented.
                     * Invoke the click function in the isolate scope with the key type and value.
                     */
                    scope.performClick({
                        keyType: keyType,
                        keyValue: keyValue
                    });
                };
            },
            scope: {
                performClick: "&onClick",
                enterEnabled: "=enableEnter",
                dotEnabled: "=enableDot",
                spaceEnabled: "=enableSpace",
                doubleZeroEnabled: "=enableDoubleZeroEnabled",
                active: "=active"
            }
        };
    });

