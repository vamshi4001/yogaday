'use strict';

angular.module('weCarePlusApp')
    .directive('keyboard', function() {
        return {
            restrict: 'E',
            templateUrl: 'views/directives/keyboard.html',
            link: function(scope, elem, attrs) {
                scope.row1 = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '@'];
                scope.row2 = ['Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P'];
                scope.row3 = ['A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', '\''];
                scope.row4 = ['Z', 'X', 'C', 'V', 'B', 'N', 'M', ',', '.', '/'];

                scope.onClick = function(keyType, keyValue, event) {
                    event.preventDefault();
                    /*
                     * The default action is prevented. 
                     * Invoke the click function in the isolate scope with the key type and value. 
                     */
                    scope.performClick({
                        keyType: keyType,
                        keyValue: keyValue
                    });
                };
            },
            scope: {
                performClick: "&onClick",
                enterEnabled: "=enableEnter",
                showRefused: "=showRefused"
            }
        };
    });
