'use strict';

angular.module('weCarePlusApp')
    .directive('searching', function() {
        return {
            restrict: 'E',
            transclude : true,
            templateUrl: 'views/directives/searching.html', 
            scope: {
                header : '@'
            }
        };
    });
