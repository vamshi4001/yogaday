'use strict';

angular.module('weCarePlusApp')
    .directive('fourButtons', function() {
        return {
            restrict: 'E',
            templateUrl: 'views/directives/fourButtons.html', 
            scope: {
                productname : '@',
                productid : '@',
                price : '@',
                status : '@',
                button1action : '&',
                button1content : '@',
                button2action : '&',
                button2content : '@',
                button3action : '&',
                button3content : '@',
                button4action : '&',
                button4content : '@',
               	backgroundcolor : '@',
                button3Selected : '='
            },
            link: function(scope, elem, attrs) {
            
                elem.on('click', function(e){
                    if(e && e.target.getAttribute('class')=='button3') {
                        e.target.style.backgroundColor = 'green';
                    } else {
                    e.preventDefault();
                    }
            })
        }
        };
    });
