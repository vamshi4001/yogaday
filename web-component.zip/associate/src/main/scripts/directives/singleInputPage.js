'use static';

angular.module('weCarePlusApp')
    .directive('singleInputPage', function($timeout, $location) {
        return {
            restrict: 'E',
            transclude: true,
            templateUrl: 'views/directives/singleInputPage.html',
            controller: function($scope) {
                $scope.row1 = ['1', '2', '3'];
                $scope.row2 = ['4', '5', '6'];
                $scope.row3 = ['7', '8', '9'];
                $scope.row4 = ['0', '00'];
                $scope.isEnableEnter = false;
                $scope.enterEnabled;
                $scope.maxInputLength;

                $scope.onInputFocusListner = function(currentFocusModel) {
                    console.log(currentFocusModel);
                    $scope.currentFocus = {
                        model: currentFocusModel
                    };
                };

                $scope.onClick = function(keyType, keyValue, event) {

                    var tempValue = $scope[$scope.currentFocus.model];
                    if (keyType === 'normKey') {
                        tempValue = tempValue ? (tempValue + keyValue) : keyValue;
                        if ($scope.maxInputLength) {
                            var maxInputLength = parseInt($scope.maxInputLength);
                            if (tempValue && tempValue.length > maxInputLength) {
                                return;
                            }
                        }
                        if ($scope.enterEnabled == tempValue.length) {
                            $scope.isEnableEnter = true;
                        }
                    } else if (keyType === 'splKey') {
                        switch (keyValue) {
                            case 'clear':
                                tempValue = '';
                                $scope.isEnableEnter = false;
                                break;
                            case 'cancel':
                                if ($scope.cancelAction) {
                                    $scope.cancelAction();
                                };
                                if ($scope.cancelLocation && $scope.cancelLocation !== '') {
                                    $location.url($scope.cancelLocation);
                                };
                                break;
                            case 'back':
                                tempValue = tempValue ? (tempValue.length > 0 ? tempValue.substr(0, tempValue.length - 1) : '') : null;
                                if (tempValue.length != $scope.enterEnabled) {
                                    $scope.isEnableEnter = false;
                                };
                                break;
                            default:
                                break;
                        }
                    } else {
                        appUtils.log("Invalid type of key pressed.");
                    };
                    $scope[$scope.currentFocus.model] = tempValue;
                    $scope.currentFocus.el.target.focus();
                };
            },
            scope: {
                inputLabel: '@inputLabel',
                cancelLocation: '@cancelLocation',
                cancelAction: '&',
                helpText: '@helpText',
                performClick: "&",
                enterEnabled: "@enableEnter",
                dotEnabled: "=enableDot",
                spaceEnabled: "=enableSpace",
                doubleZeroEnabled: "=enableDoubleZeroEnabled",
                cancelEnabled: "=enableCancel",
                active: "=active",
                inputType: "@inputType" || "text",
                maxInputLength: "@maxInputLength",
                inputdata: "=inputdata",
                maskCurrency: "@maskCurrency"
            }
        };

    });
