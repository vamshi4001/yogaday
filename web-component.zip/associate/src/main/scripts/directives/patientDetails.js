'use strict';

angular.module('weCarePlusApp')
    .directive('patientDetails', function(CONFIG) {
        return {
            restrict: 'E',
            templateUrl: 'views/directives/patientDetails.html', 
            scope: {
                patient : "=patient",
                showDob : "=showDob",
                showAddress: "=showAddress"
            }
        };
    });
