'use strict';

angular.module('weCarePlusApp')
    .directive('threeButtons', function() {
        return {
            restrict: 'E',
            templateUrl: 'views/directives/threeButtons.html', 
            scope: {
                productname : '@',
                productid : '@',
                price : '@',
                status : '@',
                button1action : '&',
                button1content : '@',
                button2action : '&',
                button2content : '@',
                button3action : '&',
                button3content : '@',
               	backgroundcolor : '@'
            }
        };
    });
