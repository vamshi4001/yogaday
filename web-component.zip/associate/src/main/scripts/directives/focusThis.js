'use strict';

angular.module('weCarePlusApp').directive('focusThis', function() {
    return {
        link: function(scope, element, attrs) {
            scope.$watch('focusedIndex', function(newVal, oldVal) {
                if (newVal == attrs['focus-this']) {
                    element.focus();
                } else {
                    element.blur();
                }
            });
        }
    };
});
