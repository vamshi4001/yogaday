'use strict';

angular.module('weCarePlusApp')
    .directive('myCalender', function() {
        return {
            restrict: 'E',
            templateUrl: 'views/directives/calender.html',
            link: function(scope, elem, attrs) {

                scope.row = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct','Nov','Dec'];
                scope.onClick = function(keyType, keyValue, event) {
                    event.preventDefault();
                    /*
                     * The default action is prevented.
                     * Invoke the click function in the isolate scope with the key type and value.
                     */
                    scope.performClick({
                        keyType: keyType,
                        keyValue: keyValue
                    });
                };
            },
            scope: {
                performClick: "&onClick",
                enterEnabled: "=enableEnter"
            }
        };
    });
