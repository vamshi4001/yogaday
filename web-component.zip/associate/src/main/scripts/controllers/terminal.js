'use strict';

var TerminalCtrl = angular.module('weCarePlusApp')
    .controller('TerminalCtrl', ["$rootScope", "$interval", "$scope", "$location", "$modal", "$log",
        "$timeout", '$socket', "Request", "PatientFactory", "CONFIG", 'BasketFactory', 'OrderFactory',
        "DialogService", "MessageFactory", 'ESignFactory', 'PseFactory','FastpassBarcode',
        'HipaaService','$modalStack', 'BasketService', 'MessageService',
        function($rootScope, $interval, $scope, $location, $modal, $log, $timeout, $socket, Request,
            PatientFactory, CONFIG, BasketFactory, OrderFactory, DialogService, MessageFactory,
            ESignFactory, PseFactory,FastpassBarcode,  HipaaService,$modalStack, BasketService, MessageService) {

            var date = new Date();
            $scope.CONFIG = CONFIG;

            $scope.sourceRoute = "";

            function formatAMPM(date) {
                var hours = date.getHours();
                var minutes = date.getMinutes();
                var ampm = hours >= 12 ? 'pm' : 'am';
                hours = hours % 12;
                hours = hours ? hours : 12; // the hour '0' should be '12'
                minutes = minutes < 10 ? '0' + minutes : minutes;
                var strTime = hours + ':' + minutes + ' ' + ampm;
                return strTime;
            }

            function getFullDateDisplay(date) {
                return (date.getMonth() + 1) + '/' + date.getDate() + '/' + date.getFullYear();
            }

            $scope.currentDate = getFullDateDisplay(date);
            $scope.currentTime = formatAMPM(date);
            $scope.currentFocus = {};
            $scope.bridge = {};
            $scope.showDoB = false;
            $scope.loggedInUser = CONFIG.loggedInUser;
            $scope.registerData = CONFIG.registerData;
            $scope.unBinders = {};
            $scope.eccData = {
                eccNumber: null
            };
            // this property has to be modified by every page when it is changed.
            $scope.CONFIG.pageTitle = 'CVS Health';

            /*To update the time and date in the footer every 19 seconds. 
            Every 19 seconds because it will be triggered at least 3 times.*/
            $interval(function() {
                $scope.currentDate = getFullDateDisplay(new Date());
                $scope.currentTime = formatAMPM(new Date());
                // appUtils.log($scope.currentTime);
            }, 19 * 1000);

            
            $rootScope.$on("$routeChangeSuccess", function(event, current, previous, rejection) {
                var previousURI = $scope.currentURI ? $scope.currentURI : "";
                var transactionId = CONFIG.txnInfo.transactionId;
                var associateId = CONFIG.loggedInUser.id;
                $scope.currentURI = $location.path();
                if ($scope.currentURI == "/home" && previousURI == "/home") {
                    return;
                }
                // $modalStack.dismissAll();
                appUtils.log('ROUTE:' + $scope.currentURI + ' #TXN-ID:' + (transactionId ? transactionId : 'NA') + ' #ASSOCIATE-ID:' + (associateId ? associateId : 'NA'));
            });


            // Verify PoS Terminal Logged in by an User
            $scope.isLoggedIn = function() {};

            // Set Logged in User Information
            $scope.setLoggedInUser = function(loggedInUser) {
                $scope.loggedInUser = loggedInUser;
            };

            // Set Current PoS Register ID 
            $scope.setRegisterID = function(registerID) {
                $scope.registerID = registerID;
            };

            $scope.onScreenKeyClick = function(keyType, keyValue) {
                $scope.bridge.updateModel(keyType, keyValue);
            };

            $rootScope.$on('IdleTimeout', function() {
                appUtils.log("User timed out. Clearing session.");
                // $scope.clearAllFactories();
                // CONFIG.storeData.isOffline = false;
                delete CONFIG.loggedInUser.id;
            });

            $scope.enableRootScanListeners = function ()
            {
                $scope.unBinders.unbindEccListener = $scope.$on('SCANNED_DATA_ECC', eccScanListener) ;
            }

            $scope.disableRootScanListeners = function ()
            {
                if($scope.unBinders.unbindEccListener) $scope.unBinders.unbindEccListener();
            }

            $rootScope.goOffLine = function() {
                MessageService.clearWholeData();
                $modalStack.dismissAll();
                $socket.clear();
                CONFIG.storeData.isOffline = true;
                var modalOptions = {
                    buttons: ['Ok'],
                    headerText: 'Rx Connect Offline',
                    bodyText: "Rx connect is offline. The Prescriptions in the basket will be removed. Please rescan again in Home screen."
                };
                if (!CONFIG.loggedInUser.id) {
                    modalOptions.headerText = "Error!";
                    modalOptions.bodyText = "Error contacting server while logging in.";
                }
                DialogService.showDialog({}, modalOptions).then(function(result) {
                    BasketFactory.clearRxItemsInOrder();
                    BasketFactory.removeAllPatients();
                    $scope.disableRootScanListeners();
                    $scope.enableRootScanListeners();
                    BasketService.updateBasketData('0', {});
                    if (!CONFIG.loggedInUser.id)
                        $location.url('/login');
                    else
                        $location.url('/home');
                });

            };
            $scope.goHome = function(shouldConfirm) {
                if (shouldConfirm) {
                    var modalOptions = {
                        buttons: ['Yes', 'No'],
                        headerText: 'Return to HOME',
                        bodyText: 'Are you sure you want to return to Home screen? <br> All work will be lost.'
                    };
                    DialogService.showDialog({}, modalOptions).then(function(result) {
                        if (result && result === 'Yes') {
                            $scope.clearAllFactories(true);
                            $location.url("/home");
                        }
                    });
                } else {
                    PatientFactory.clearSelectedPatientList();
                    $location.url("/home");
                }
            };

            $scope.doCancel = function() {
                var modalOptions = {
                    buttons: ['Yes', 'No'],
                    headerText: 'Return to POS',
                    bodyText: 'Are you sure you want to cancel the operation?'
                };
                DialogService.showDialog({}, modalOptions).then(function(result) {
                    if (result && result === 'Yes') {
                        $scope.clearAllFactories(true);
                        $location.url("/home");
                    }
                });
            };

            $scope.patientLookup = function(event) {
                event.preventDefault();
                $location.url('/patient-lookup');
            };

            $scope.updateSecDispPriceList = function() {
                var options = {
                    route: 'priceTable',
                    payload: {
                        items: []
                    }
                };
                angular.forEach(BasketFactory.getRxItemsInOrder(), function(value, key) {
                    options.payload.items.push({
                        desc: "F 1 RX #: " + appUtils.prepandZeros(value.basketItemInfo.rxNum, 8) + appUtils.prepandZeros(value.basketItemInfo.refillNum, 3) + appUtils.prepandZeros(value.basketItemInfo.partialFillSeqNum, 1),
                        price: value.basketItemInfo.fillDisposition.priceModify ? value.basketItemInfo.fillDisposition.modifiedPrice : value.basketItemInfo.patPayAmt
                    });
                });
                angular.forEach(OrderFactory.getOtcDataFromTxn(), function(otcItem) {
                    options.payload.items.push({
                        desc: otcItem.description,
                        price: otcItem.priceModify ? otcItem.modifiedPrice : otcItem.retailPrice
                    });
                });
                angular.forEach(OrderFactory.getMinuteClinicDepositsOrder(), function(mcdItem) {
                    options.payload.items.push({
                        desc: mcdItem.label,
                        price: mcdItem.amount
                    });
                });

                if (options.payload.items.length) {
                $socket.send(JSON.stringify({
                    type: 'DISPLAY_ONLY',
                    options: options
                }), true).then(function(response) {
                    appUtils.log('DISPLAY_ONLY ACK');
                });
                }
                else
                {
                    $socket.clear();
                }

            };

            $scope.$on('BARCODE_SCAN', function(evt, options) {
                var SCANNED_BARCODE_TYPE = 'SCANNED_DATA_GENERIC';
                /**
                 * Barcode symbologies at the very end of the page.
                 */
                var barcodeData = window.atob(options.scanData);
                appUtils.log("Barcode Scanned... " + barcodeData);
                if (!CONFIG.loggedInUser.id && barcodeData) {
                    if (barcodeData.length == 3) {
                        //Only fire barcode scan event for new employee which has barcode length 3, Since user will not be loggedin
                        $scope.$broadcast('SCANNED_DATA_GENERIC', barcodeData);
                    } else {
                        return;
                    }
                }
                switch (options.scanDataType) {
                    case "101":
                    case "102":
                    case "103":
                    case "104":
                    case "111":
                    case "112":
                    case "113":
                    case "114":
                    case "115":
                    case "116":
                    case "117":
                    case "118":
                    case "119":
                    case "120":
                        //UPC and EAN type barcodes
                        //Check if ECC else process Item lookup.

                        if (barcodeData.match("^4871") || barcodeData.match("^4872") ||
                            barcodeData.match("^4873") || barcodeData.match("^4878") ||
                            barcodeData.match("^4879") || barcodeData.match("^911") ||
                            barcodeData.match("^912") || barcodeData.match("^476") ||
                            barcodeData.match("^470") || barcodeData.match("^202")) {
                            SCANNED_BARCODE_TYPE = 'SCANNED_DATA_ECC';
                            $scope.$broadcast('SCANNED_DATA_ECC', barcodeData);
                        } else {
                            SCANNED_BARCODE_TYPE = 'SCANNED_DATA_OTC';
                            $scope.$broadcast('SCANNED_DATA_OTC', barcodeData);
                        }
                        break;
                    case "110":
                        //CODE 128
                        // First Set of ECC were Code 128 - Need to handle - TODO
                        // could be RX, Special Rx or PHR barcode
                        if (barcodeData.match("^27")) {
                            SCANNED_BARCODE_TYPE = 'SCANNED_DATA_RX';
                            $scope.$broadcast('SCANNED_DATA_RX', barcodeData);
                        } else if (barcodeData.match("^37")) {
                            SCANNED_BARCODE_TYPE = 'SCANNED_DATA_SPLRX';
                            $scope.$broadcast('SCANNED_DATA_SPLRX', barcodeData);
                        } else if (barcodeData.match("^19") && barcodeData.length == 22) {
                            SCANNED_BARCODE_TYPE = 'SCANNED_DATA_PHR';
                            $scope.$broadcast('SCANNED_DATA_PHR', barcodeData);
                        }

                        break;
                    case "143":
                        // MSI code 
                        // check if starts with 8000 - ECC. Else error.
                        if (barcodeData.match("^8000")) {
                            SCANNED_BARCODE_TYPE = 'SCANNED_DATA_ECC';
                            $scope.$broadcast('SCANNED_DATA_ECC', barcodeData);
                        }
                        break;

                    case "201":
                        // PDF417 code - Fastpass
                        if (FastpassBarcode.isFastPass(barcodeData)) {
                            var result = FastpassBarcode.parseBarcode(barcodeData);

                            if(result && result.fastPassID && result.fastPassID !== '0' && result.version) 
                            {
                            	LOGGER.info('Fastpass ID: '+ result.fastPassID);
                            	OrderFactory.setFastpassVersion(result.version);
                                OrderFactory.setMobileConnectivity(result.connectivity);
                                $scope.$broadcast('SCANNED_DATA_FASTPASS', barcodeData, 'FASTPASS');
                            }
                            if (result && result.extraCareCard && result.extraCareCard.length > 2)
                            {
                                LOGGER.info('Extracare Card Number: '+ result.extraCareCard, 'FASTPASS');
                                $scope.$broadcast('SCANNED_DATA_ECC', result.extraCareCard);
                            }
                        }
                        else
                        {
                            $scope.$broadcast('SCANNED_DATA_LICENSE', barcodeData);
                        }
                        break;

                    default:
                        //other code
                        if (barcodeData.length == 9) {
                            SCANNED_BARCODE_TYPE = 'SCANNED_DATA_ECC';
                            $scope.$broadcast('SCANNED_DATA_ECC', barcodeData);
                        } else
                            appUtils.log("Invalid barcode scanned - " + barcodeData);
                        break;
                }
                //Broadcast a generic data
                $scope.$broadcast('SCANNED_DATA_GENERIC', barcodeData, SCANNED_BARCODE_TYPE,  options.scanDataType);
            });


            $scope.displayNextMessage = function() {
                if (!CONFIG.offline) {
                    $location.url('/messages/');
                }
            };

            /*
            Below is the code that identifies if the system is being tested 
            on a development environment or a local testing. The environment 
            is evalutated by using the address bar location to cvsstore.cvs.com
            */
            $scope.isLocalTesting = $location.host().match("cvsstore.cvs.com") ? false : true;
            console.log("isLocalTesting = " + $scope.isLocalTesting);
            if ($scope.isLocalTesting) {
                CONFIG.socket.endpoint = "wss://localhost:9900/associate";

                // $("body").css("cursor", "default");
                angular.element(document.querySelector("body")).css("cursor", "default");
                window.setInterval(function() {
                    CONFIG.workstationID = "wcp-wks01";
                    CONFIG.registerId = "01";
                    CONFIG.registerData.id = "01";
                    // $(".btn").css("cursor", "pointer");
                    angular.element(document.querySelectorAll(".btn")).css("cursor", "pointer");
                }, 1000);

                /**
                 * Setup the environment for Local Testing
                 */
                $scope.showBarcodePopup = function() {
                    var esigModel = $modal.open({
                        templateUrl: 'views/modals/barcode-entry.html',
                        keyboard: false,
                        backdrop: false,
                        size: 'md',
                        controller: 'BarcodeDevEntry'
                    });
                };
            }

            //Fastpass callback
            $scope.fastPassListner = function(barcode, pickupID) {

                OrderFactory.getTransactionIdData();
                // var transId  = OrderFactory.getTransactionIdData().transactionId;
                var fastPassPatientPromise;
                var parsedBarcode = FastpassBarcode.parseBarcode(barcode);
                var version = OrderFactory.getFastpassVersion();
                var fastPassID = parsedBarcode.fastPassID;
                var userID = parsedBarcode.userID;
                var transId = parsedBarcode.transId;
                var connectivity = parsedBarcode.connectivity;
                var mcxflag = parsedBarcode.mcxflag;
                if (barcode) {
                    fastPassPatientPromise = Request.invoke({
                        url: appConfig.store.services.API.fastPassPatient + version + "?scannedId=" + fastPassID + "&transID=" + transId
                        + "&userID=" + userID + "&connectivityFlag=" + connectivity + "&payFlag=" + mcxflag,
                        method: 'GET'
                    });
                } else {
                    fastPassPatientPromise = Request.invoke({
                        loadMessage: "Looking up pickup number...",
                        url: appConfig.store.services.API.fastPassPatient + "0" + "?pickupCode=" + pickupID,
                        method: 'GET'
                    });
                }
                
                fastPassPatientPromise.then(function(data) {
                        var transactionID = data.transactionID;
                        var fastPassID = data.fastPassID;
                        var pickupCode = data.pickupCode;
                        var extraCareID = data.extraCareID;
                        var userID = data.userID;
                        var qparam = "";
                        var patientList = data.patientList;
                        angular.forEach(data.patientList, function(patientItem) {
                            qparam += "id=" + patientItem.patientId + "&";
                        });
                        var fastPassScanPromise = Request.invoke({
                            loadMessage: "Loading patients...",
                            url: appConfig.store.services.API.fastPassScan + "?" + qparam,
                            method: 'GET'
                        });
                        fastPassScanPromise.then(function(data) {
                                if (data && data.patientProfileList.length) {
                                    data.transactionID = transactionID;
                                    data.fastPassID = fastPassID;
                                    data.pickupCode = pickupCode;
                                    data.extraCareID = extraCareID;
                                    data.userID = userID;
                                    OrderFactory.setFastpassData(data);
                                    angular.forEach(data.patientProfileList, function(pprItem) {
                                        PatientFactory.addToSelectedPatientList(pprItem.patientDetails);
                                        BasketService.updateBasketData(pprItem.patientDetails.rxCPatientId, pprItem);
                                    });
                                    OrderFactory.setFastpass(true);
                                    if (data.patientProfileList.length === patientList.length) {
                                        $location.url("/basket");
                                    } else {
                                        // Show error that some patient are not found.
                                        var modalOptions = {
                                            buttons: ['OK'],
                                            headerText: 'Information',
                                            bodyText: 'Some of the patients are not found in this store.'
                                        };
                                        DialogService.showDialog({}, modalOptions).then(function(result) {
                                            $location.url("/basket");
                                        });
                                    }
                                } else {
                                    var modalOptions = {
                                        buttons: ['OK'],
                                        headerText: 'Information',
                                        bodyText: 'No Prescriptions Available at this location'
                                    };
                                    DialogService.showDialog({}, modalOptions).then(function(result) {
                                        //Close window
                                    });
                                }
                            },
                            function(data) {
                                var modalOptions = {
                                    buttons: ['OK'],
                                    headerText: 'Error',
                                    bodyText: 'Mobile Pick Up ID not valid'
                                };
                                DialogService.showDialog({}, modalOptions).then(function(result) {
                                    //Close window
                                });
                            });
                    },
                    function(data) {
                        var modalOptions = {
                            buttons: ['OK'],
                            headerText: 'Error',
                            bodyText: 'Mobile Pick Up ID not valid'
                        };
                        DialogService.showDialog({}, modalOptions).then(function(result) {
                            //Close window
                        });
                    });
            };

            $scope.clearAllFactories = function(fromGoHomeAction) {
                BasketFactory.clearBasketData();
                BasketFactory.clearWholeOrder();
                ESignFactory.clearEsigFactory();
                MessageFactory.clearData();
                OrderFactory.clearTxnObject(fromGoHomeAction);
                PatientFactory.clearSelectedPatientList();
                !fromGoHomeAction && PseFactory.clearPSEData();
                !fromGoHomeAction && $socket.clear();
                fromGoHomeAction && $scope.updateSecDispPriceList();
                $scope.disableRootScanListeners();
                $scope.enableRootScanListeners();
            };

            $scope.signOff = function() {
                var modalOptions = {
                    buttons: ['Yes', 'No'],
                    headerText: 'Confirm Sign Off',
                    bodyText: 'Are you sure you want to sign off?'
                };
                DialogService.showDialog({}, modalOptions).then(function(result) {
                    if (result == "Yes") {
                        $scope.clearAllFactories();
                        CONFIG.storeData.isOffline = false;
                        delete CONFIG.loggedInUser.id;
                        $location.url('/login');
                    }
                });
            };

            $scope.buildRxBarcode = function(rxInfo, specialtyOrderNum) {
                var rxnum = appUtils.prepandZeros(rxInfo.rxNum, 7);
                var reFillNum = appUtils.prepandZeros((rxInfo.refillNum || 0), 3);
                var editVerNum = appUtils.prepandZeros((rxInfo.editVersionNum || 0), 3);
                var parFillSeqNum = appUtils.prepandZeros((rxInfo.partialFillSeqNum || 0), 2);
                var priceAmt = appUtils.prepandZeros((Math.round(rxInfo.patPayAmt * 100) || 0),7)
                if(specialtyOrderNum){
                    return ("37" + rxnum + editVerNum + parFillSeqNum + priceAmt);
                }
                else{
                    return ("27" + rxnum + reFillNum + editVerNum + parFillSeqNum + priceAmt);
                }
                
            };
            
            $scope.buildPartialRxbarcode = function(rxInfo) {
                var rxnum = appUtils.prepandZeros(rxInfo.rxNum, 7);
                var reFillNum = appUtils.prepandZeros((rxInfo.refillNum || 0), 3);
                var editVerNum = appUtils.prepandZeros((rxInfo.editVersionNum || 0), 3);
                var parFillSeqNum = appUtils.prepandZeros((rxInfo.partialFillSeqNum || 0), 2);
                return (rxnum + reFillNum + editVerNum + parFillSeqNum);
            };
            $scope.buildPartialRxbarcodeMsgItem = function(msgItem) {
                var rxnum = appUtils.prepandZeros(msgItem.rxNum, 7);
                var reFillNum = appUtils.prepandZeros((msgItem.refillNum || 0), 3);
                var editVerNum = appUtils.prepandZeros((msgItem.editVersionNum || 0), 3);
                var parFillSeqNum = appUtils.prepandZeros((msgItem.partialFillSeqNum || 0), 2);
                return (rxnum + reFillNum + editVerNum + parFillSeqNum);
            };
            $scope.agentPunch = function(data) {
                $scope.sourceRoute = data;
                $location.url('/agent-punch');
            };

            var eccScanListener = function(evt, barcode) {
                if (HipaaService.getHipaaInProcess()) {
                    $rootScope.$broadcast('SCANNED_DATA_ECC_HIPAA', barcode);
                    return;
                }
                var q = 'card_nbr=' + barcode;
                if (!OrderFactory.getEccNumber()) {
                    var eccLookupPromise = Request.invoke({
                        url: appConfig.store.services.API.extraCareLookUp + '?' + q,
                        method: 'GET'
                    });
                    eccLookupPromise.then(function(result) {
                        OrderFactory.setEccNumber(barcode);
                        OrderFactory.setEccData(result);

                        // var modalOptions = {
                        //     buttons: ['OK'],
                        //     headerText: 'Extracare Card Scanned',
                        //     bodyText: 'Extracare Card has been scanned'
                        // };
                        // DialogService.showDialog({}, modalOptions).then(function(result) {});
                    }, function(error) {
                        var modalOptions = {
                            buttons: ['OK'],
                            headerText: 'Error',
                            bodyText: 'Invalid Extracare Card Scanned'
                        };
                        DialogService.showDialog({}, modalOptions).then(function(result) {});
                    });
                } else {
                    var modalOptions = {
                        buttons: ['OK'],
                        headerText: 'Information',
                        bodyText: 'EXTRACARE CARD WAS<br/>ALREADY SELECTED'
                    };
                    DialogService.showDialog({}, modalOptions).then(function(result) {});
                }
            };
        }
    ]);

TerminalCtrl.loadData = function($timeout, $socket, Request, PollingFactory, CONFIG) {
    PollingFactory.dailyConfigPolling();
    var storeNumberPromise = Request.invoke({
        loadMessage: "Loading store number...",
        url: appConfig.store.services.API.storeNumber,
        method: 'GET'
    });
    storeNumberPromise.then(function(data) {
        if (data.value) {
            CONFIG.storeData.number = data.value;
        }
    });

    var stateCodePromise = Request.invoke({
        loadMessage: "Loading state code...",
        url: appConfig.store.services.API.stateCode,
        method: 'GET'
    });
    stateCodePromise.then(function(data) {
        if (data) {
            CONFIG.storeData.stateCode = data;
        }
    });

    /**
     * To get the RPH ID capture flag for the PSE
     * 
     */
    Request.invoke({
        url: appConfig.store.services.API.pseRphIdReqired,
        method: 'GET'
    }).then(function(data) {
        if (data.value) {
            CONFIG.pseConfig.pseRphIdReqired = data.value;
        }
    });
    /*
    To get the settings for if we should capture the Employee ID
     */
    Request.invoke({
        url: appConfig.store.services.API.pseEmpTracking,
        method: 'GET'
    }).then(function(data) {
        if (data.value) {
            CONFIG.pseConfig.pseEmpTracking = data.value;
        }
    });

    /*
    To get the settings for if the store can refund PSE items
     */
    Request.invoke({
        url: appConfig.store.services.API.pseRefundBlocked,
        method: 'GET'
    }).then(function(data) {
        if (data.value) {
            CONFIG.pseConfig.pseRefundBlocked = data.value;
        }
    });

};




angular.module('weCarePlusApp')
    .controller('BarcodeDevEntry', function($scope, $modalInstance, $rootScope) {
        $scope.code = "";
        $scope.codetype = "101";
        $scope.sendEvent = function() {
            $rootScope.$broadcast('BARCODE_SCAN', {
                scanData: window.btoa($scope.code),
                scanDataType: $scope.codetype
            });
            $modalInstance.close();
        };

        $scope.dismiss = function() {
            $modalInstance.close();
        };
    });


// 
// SCAN_SDT_UPCA        = 101;  // Digits
// SCAN_SDT_UPCE        = 102;  // Digits
// SCAN_SDT_JAN8        = 103;  // = EAN 8
// SCAN_SDT_EAN8        = 103;  // = JAN 8
// SCAN_SDT_JAN13       = 104;  // = EAN 13
// SCAN_SDT_EAN13       = 104;  // = JAN 13
// SCAN_SDT_TF          = 105;  // (Discrete 2 of 5)
// SCAN_SDT_ITF         = 106;  // (Interleaved 2 of 5)
// SCAN_SDT_Codabar     = 107;  // Digits, -, $, :, /, .,
// SCAN_SDT_Code39      = 108;  // Alpha, Digits, Space,
// SCAN_SDT_Code93      = 109;  // Same characters as
// SCAN_SDT_Code128     = 110;  // 128 data characters
// SCAN_SDT_UPCA_S      = 111;  // UPC-A with
// SCAN_SDT_UPCE_S      = 112;  // UPC-E with
// SCAN_SDT_UPCD1       = 113;  // UPC-D1
// SCAN_SDT_UPCD2       = 114;  // UPC-D2
// SCAN_SDT_UPCD3       = 115;  // UPC-D3
// SCAN_SDT_UPCD4       = 116;  // UPC-D4
// SCAN_SDT_UPCD5       = 117;  // UPC-D5
// SCAN_SDT_EAN8_S      = 118;  // EAN 8 with
// SCAN_SDT_EAN13_S     = 119;  // EAN 13 with
// SCAN_SDT_EAN128      = 120;  // EAN 128
// SCAN_SDT_OCRA        = 121;  // OCR "A"
// SCAN_SDT_OCRB        = 122;  // OCR "B"
// SCAN_SDT_RSS14       = 131;  // Reduced Space Symbology - 14 digit GTIN
// SCAN_SDT_RSS_EXPANDED= 132;  // RSS - 14 digit GTIN plus additional fields
// SCAN_SDT_GS1DATABAR  = 131;  // GS1 DataBar Omnidirectional (normal or stacked)
// SCAN_SDT_GS1DATABAR_E= 132;  // GS1 DataBar Expanded (normal or stacked)
// SCAN_SDT_ITF_CK           = 133;  // Interleaved 2 of 5 check digit verified and 
// SCAN_SDT_GS1DATABAR_TYPE2 = 134; // GS1 DataBar Limited
// SCAN_SDT_AMES             = 135;  // Ames Code
// SCAN_SDT_TFMAT            = 136;  // Matrix 2 of 5
// SCAN_SDT_Code39_CK        = 137;  // Code 39 with check character verified and 
// SCAN_SDT_Code32           = 138;  // Code 39 with Mod 32 check character
// SCAN_SDT_CodeCIP          = 139;  // Code 39 CIP
// SCAN_SDT_TRIOPTIC39       = 140;  // Tri-Optic Code 39
// SCAN_SDT_ISBT128          = 141;  // ISBT-128
// SCAN_SDT_Code11           = 142;  // Code 11
// SCAN_SDT_MSI              = 143;  // MSI Code
// SCAN_SDT_PLESSEY          = 144;  // Plessey Code
// SCAN_SDT_TELEPEN          = 145;  // Telepen
// SCAN_SDT_CCA         = 151;  // Composite Component A.
// SCAN_SDT_CCB         = 152;  // Composite Component B.
// SCAN_SDT_CCC         = 153;  // Composite Component C.
// SCAN_SDT_TLC39       = 154;  // TLC-39
// SCAN_SDT_PDF417      = 201;
// SCAN_SDT_MAXICODE    = 202;
// SCAN_SDT_DATAMATRIX  = 203;  // Data Matrix
// SCAN_SDT_QRCODE      = 204;  // QR Code
// SCAN_SDT_UQRCODE     = 205;  // Micro QR Code
// SCAN_SDT_AZTEC       = 206;  // Aztec
// SCAN_SDT_UPDF417     = 207;  // Micro PDF 417
// SCAN_SDT_GS1DATAMATRIX = 208;  // GS1 DataMatrix
// SCAN_SDT_GS1QRCODE     = 209;  // GS1 QR Code
// SCAN_SDT_Code49        = 210;  // Code 49
// SCAN_SDT_Code16k       = 211;  // Code 16K
// SCAN_SDT_CodablockA    = 212;  // Codablock A
// SCAN_SDT_CodablockF    = 213;  // Codablock F
// SCAN_SDT_Codablock256  = 214;  // Codablock 256
// SCAN_SDT_HANXIN        = 215;  // Han Xin Code
// SCAN_SDT_AusPost       = 301;  // Australian Post
// SCAN_SDT_CanPost       = 302;  // Canada Post
// SCAN_SDT_ChinaPost     = 303;  // China Post
// SCAN_SDT_DutchKix      = 304;  // Dutch Post
// SCAN_SDT_InfoMail      = 305;  // InfoMail
// SCAN_SDT_JapanPost     = 306;  // Japan Post
// SCAN_SDT_KoreanPost    = 307;  // Korean Post
// SCAN_SDT_SwedenPost    = 308;  // Sweden Post
// SCAN_SDT_UkPost        = 309;  // UK Post BPO
// SCAN_SDT_UsIntelligent = 310;  // US Intelligent Mail
// SCAN_SDT_UsPlanet      = 311;  // US Planet Code
// SCAN_SDT_PostNet       = 312;  // US Postnet
// SCAN_SDT_OTHER       = 501;  // Start of Scanner-
// SCAN_SDT_UNKNOWN     =   0;  // Cannot determine the
