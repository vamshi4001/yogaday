'use strict';
angular.module('weCarePlusApp')
    .controller('PatientCtrl', function($scope, $location, $route, $routeParams, Request, PatientFactory, BasketFactory, $timeout, CONFIG, DialogService, $filter, OrderFactory, NumberEntryService, BasketService) {
        //$scope.patientSearchResultList = PatientFactory.getPatientSearchList();
        $scope.patientSearchResultList = PatientFactory.getPatientSearchList();
        $scope.selectPatientRowItem = {};
        $scope.confirmPatientInfo = PatientFactory.getSelectedPatient();
        $scope.patientSearchStr = '';
        $scope.enterKeyActive = false;
        $scope.continueKeyActive = false;
        $scope.dob = '';
        $scope.numpadActive = false;
        $scope.patientSearchTitle = PatientFactory.getPatientSearchStr() ? PatientFactory.getPatientSearchStr() : 'Waiters';
        $scope.showDoB = PatientFactory.getDobVerifyText();
        $scope.$on('SCANNED_DATA_FASTPASS', function(evt, barcode) {
            $scope.fastPassListner(barcode);
        });

        $scope.dobValidation = function() {
            $location.url('dob-validation');
        };

        $scope.onFocusListner = function(currentFocusModel) {
            $scope.currentFocus = {
                model: currentFocusModel
            };
        };
        $scope.onScreenKeyClick = function(keyType, keyVal) {
            var tempValue = $scope[$scope.currentFocus.model];
            if (keyType === 'normKey') {
                tempValue = tempValue ? (tempValue + keyVal) : keyVal;
            } else if (keyType === 'splKey') {
                switch (keyVal) {
                    case 'clear':
                        tempValue = '';
                        break;
                    case 'backspace':
                        tempValue = tempValue ? (tempValue.length > 0 ? tempValue.substr(0, tempValue.length - 1) : '') : null;
                        break;
                    case 'enter':
                        $scope.searchPatient();
                        break;
                    case 'cancel':
                        $scope.showCancel();
                        break;
                    default:
                        break;
                }
            } else {
                appUtils.log("Invalid type of key pressed.");
            }
            $scope[$scope.currentFocus.model] = tempValue;
            $scope.enterKeyActive = isPatientSearchStrValid(tempValue);
            $scope.currentFocus.el.target.focus();
        };

        $scope.doFastPassPickup = function() {
            NumberEntryService.showDialog({}, {
                inputText: "Enter Customer's Pickup Number here from CVS Mobile App",
                headerText: 'Pickup Number Entry'
            }).then(function(result) {
                appUtils.log("FastPass Pickup number = " + JSON.stringify(result));
                $scope.fastPassListner(null, result);
            });
        };

        $scope.onScreenKeyClickVA = function(keyType, keyVal) {
            var tempValue = $scope[$scope.currentFocus.model];
            if (keyType === 'normKey') {
                tempValue = tempValue ? (tempValue + keyVal) : keyVal;
            } else if (keyType === 'splKey') {
                switch (keyVal) {
                    case 'clear':
                        tempValue = '';
                        break;
                    case 'back':
                        tempValue = tempValue ? (tempValue.length > 0 ? tempValue.substr(0, tempValue.length - 1) : '') : null;
                        break;
                    case 'enter':
                        $scope.confirmAndAddBasket('VA');
                        break;
                    case 'cancel':
                        $scope.showCancel();
                        break;
                    default:
                        break;
                }
            } else {
                appUtils.log("Invalid type of key pressed.");
            }
            $scope[$scope.currentFocus.model] = tempValue;
            $scope.enterKeyActive = tempValue.length > 5;
            $scope.currentFocus.el.target.focus();
        };


        $scope.showCancel = function() {
                $scope.doCancel();
            }
            /*
            Space action disabled
            */
        $scope.onScreenKeyClickDoB = function(keyType, keyVal) {
            var tempValue = $scope[$scope.currentFocus.model];
            var monthMaxDays = CONFIG.MONTH_MAX_DAYS[keyVal.toUpperCase()];
            if (keyType === 'normKey') {
                if (CONFIG.MONTH_MAX_DAYS[keyVal.toUpperCase()]) {
                    $scope[$scope.currentFocus.model] = keyVal + CONFIG.DATE_DELIMETER;
                    tempValue = $scope[$scope.currentFocus.model];
                    $scope.numpadActive = true;
                } else {
                    tempValue += keyVal;
                    var dobSplit = tempValue.split('-');
                    if (!$scope.numpadActive) {
                        return;
                    }
                    if (dobSplit.length > 1 && dobSplit[1].length > 2) {
                        return;
                    }
                    if (dobSplit[1].length == 2 && parseInt(dobSplit[1]) == 0) {
                        return;
                    }
                    if (dobSplit.length > 1 && dobSplit[1] !== '') {
                        monthMaxDays = parseInt(CONFIG.MONTH_MAX_DAYS[dobSplit[0].toUpperCase()]);
                        var dobDay = parseInt(dobSplit[1]);
                        if (dobDay !== 0 && dobDay > monthMaxDays) {
                            return;
                        } else {
                            $scope.enterKeyActive = true;
                        }
                    }
                }
            } else if (keyType === 'splKey') {
                switch (keyVal) {
                    case 'clear':
                        tempValue = '';
                        $scope.numpadActive = false;
                        $scope.enterKeyActive = false;
                        break;
                    case 'back':
                        var dobSplit = tempValue.split('-');
                        if (dobSplit.length > 1 && dobSplit[1] !== '') {
                            tempValue = tempValue ? (tempValue.length > 0 ? tempValue.substr(0, tempValue.length - 1) : '') : null;
                        } else {
                            tempValue = "";
                        }
                        break;
                    case 'enter':
                        // $scope.confirmAndAddBasket();
                        break;
                    default:
                        break;
                }
            } else {
                appUtils.log("Invalid type of key pressed.");
            }
            $scope[$scope.currentFocus.model] = tempValue;
            $scope.currentFocus.el.target.focus();
        };

        $scope.searchPatient = function(byPass) {
            if (!$scope.enterKeyActive && !byPass) {
                return;
            }
            PatientFactory.setPatientSearchStr($scope.patientSearchStr);
            var patientSearchArr = $scope.patientSearchStr.replace(/^\s+|\s+$/g, "").split(/\s*,\s*/);
            var q = '';
            if (patientSearchArr.length > 1) {
                q += 'lastName=' + patientSearchArr[0];
                q += '&firstName=' + patientSearchArr[1];
                if (patientSearchArr.length === 3) {
                    q += '&dob=' + patientSearchArr[2];
                }
            } else {
                q += 'phone=' + patientSearchArr[0];
            }

            var patientSearchPromise = Request.invoke({
                loadMessage: "Searching for " + $scope.patientSearchStr + "...",
                url: appConfig.store.services.API.patientSearch + '?' + q,
                method: 'GET'
            });
            patientSearchPromise.then(function(result) {
                if (result.patientDetails && result.patientDetails.length) {
                    PatientFactory.setPatientSearchList(result.patientDetails);
                    $location.url('/patient-list');
                } else {
                    var modalOptions = {
                        buttons: ['OK'],
                        headerText: 'No Search results',
                        bodyText: 'No Search Results were found. Press OK to return to Patient Lookup screen.'
                    };
                    DialogService.showDialog({}, modalOptions).then(function(result) {
                        //Close window
                    });
                }
            }, function(result, statusCode) {
                var modalOptions = {
                    buttons: ['OK'],
                    headerText: 'No Search results',
                    bodyText: 'No Search Results were found. Press OK to return to Patient Lookup screen.'
                };
                DialogService.showDialog({}, modalOptions).then(function(result) {
                    //Close window
                });
            });
        };

        $scope.waiters = function(byPass) {
            PatientFactory.setPatientSearchStr(null);
            var waitersPromise = Request.invoke({
                loadMessage: "Loading waiters...",
                url: appConfig.store.services.API.waiters,
                method: 'GET'
            });
            waitersPromise.then(function(result) {
                if (result && result.patientDetails && result.patientDetails.length) {
                    PatientFactory.setPatientSearchStr('Waiters');
                    PatientFactory.setPatientSearchList(result.patientDetails);
                    $location.url('/patient-list');
                } else {
                    var modalOptions = {
                        buttons: ['ok'],
                        headerText: 'No Patients Found',
                        bodyText: 'No Patients In Waiting List'
                    };
                    DialogService.showDialog({}, modalOptions).then(function(result) {
                        //Close window
                    });
                }
            }, function(result, statusCode) {
                var modalOptions = {
                    buttons: ['Okay'],
                    headerText: 'Error',
                    bodyText: result.message || 'No Patients Found'
                };
                DialogService.showDialog({}, modalOptions).then(function(result) {
                    //Close window
                });
            });
        };

        $scope.repeatLastSearch = function(event) {
            event && event.preventDefault();
            $scope.patientSearchStr = PatientFactory.getPatientSearchStr();
            if ($scope.patientSearchStr) {
                $scope.searchPatient(true);
            } else {
                return;
            }
        };
        $scope.showPatientLookUp = function() {
            $location.url('/patient-lookup');
        };
        $scope.continueToBasket = function(event) {
            event && event.preventDefault();
            if (PatientFactory.getSelectedPatientList() && Object.keys(PatientFactory.getSelectedPatientList()).length) {
                $location.url('/basket');
            } else {
                var modalOptions = {
                    buttons: ['OK'],
                    headerText: 'Error',
                    bodyText: 'No Patients added to Basket'
                };
                DialogService.showDialog({}, modalOptions).then(function(result) {});
            }
        };

        var isPatientSearchStrValid = function(val) {
            if (val && val.length > 0) {
                var nameArray = val.split(',');
                if (nameArray.length > 1 && nameArray[1].length >= 2) {
                    return true;
                }
                var phoneno = /^\d{10}$/;
                if (val.match(phoneno)) {
                    return true;
                }
            }
            return false;
        };
        /**
         **  Patient Search Result List -------------------- START ------------------------  
         **/
        $scope.rowSelectPatient = function(event, index, item) {
            var basketPatientList = PatientFactory.getSelectedPatientList();

            if (basketPatientList[item.rxCPatientId]) {
                var modalOptions = {
                    buttons: ['Continue'],
                    headerText: 'Patient Already Confirmed',
                    bodyText: 'Patient has already been confirmed, select Continue to return to Search Results'
                };
                DialogService.showDialog({}, modalOptions).then(function(result) {});
                return;
            }
            $scope.selectedRowIndex = index;
            $scope.selectPatientRowItem = item;
            $scope.continueKeyActive = true;

        };

        $scope.selectPatientToContinue = function(event) {
            event.preventDefault();
            if (!$scope.continueKeyActive) {
                return;
            }
            PatientFactory.setSelectedPatient($scope.selectPatientRowItem);

            if ($scope.showDoB) {
                $location.url('/patient-match');
            } else {
                $location.url('/dob-validation');


            }
        };
        $scope.buttonInvocation = function(msg) {
            window.alert(msg);
        };
        $scope.goBackToPatientList = function(event) {
            event && event.preventDefault();
            $location.url('/patient-list');
        };
        $scope.continueToPatientMatch = function() {
            $location.url('/patient-match');
        };

        $scope.confirmAndNewPatient = function() {
            if (!$scope.showDoB && !$scope.enterKeyActive) {
                $location.url('/dob-validation');
                return;
            } else if (!$scope.showDoB && $scope.enterKeyActive) {
                if (!$scope.validateDoB()) {
                    return;
                }
            }
            confirmSelectedPatient(function() {
                $location.url('/patient-lookup');
            });
        };
        $scope.confirmAndAddBasket = function(page) {
            OrderFactory.getTransactionIdData();
            if (page === 'VA') {
                if ($scope.associateId != CONFIG.loggedInUser.id) {
                    var modalOptions = {
                        buttons: ['Ok'],
                        headerText: 'Invalid LoggentIn UserId',
                        bodyText: 'Please provide correct logged in Agent ID'
                    };
                    DialogService.showDialog({}, modalOptions).then(function(type) {});
                    return;
                }
            } else {
                if (!$scope.showDoB && !$scope.enterKeyActive) {
                    return;
                } else if (!$scope.showDoB && $scope.enterKeyActive) {
                    if (!$scope.validateDoB()) {
                        return;
                    }
                }
            }
            confirmSelectedPatient(function() {
                $location.url('/basket');
            });
        };

        $scope.validateDoB = function() {
            var existingDOB = $filter('date')($scope.confirmPatientInfo.birthday, CONFIG.birthDayFormat);
            var existingDOBArr = existingDOB.split('-');
            existingDOB = existingDOBArr[0] + '-' + parseInt(existingDOBArr[1]);
            var currentDOB = $scope.dob;
            var currentDOBArr = currentDOB.split('-');
            currentDOB = currentDOBArr[0] + '-' + parseInt(currentDOBArr[1]);
            if (existingDOB !== currentDOB) {
                DialogService.showDialog({}, {
                    buttons: ['Ok'],
                    headerText: 'Error',
                    bodyText: "The date entered does not match the selected Patient's birthday. Please confirm and re-enter the value "
                }).then(function(type) {});
                return false;
            }
            return true;
        };

        var confirmSelectedPatient = function(callback) {
            var phrStatusPromise = Request.invoke({
                loadMessage: "Checking rewards enrollment status",
                url: appConfig.store.services.API.phrStatus + '?patient-id=' + $scope.confirmPatientInfo.rxCPatientId,
                method: 'GET'
            });
            var patientBasketPromise = Request.invoke({
                loadMessage: "Patient Profile Lookup",
                url: appConfig.store.services.API.patientBasket + '?patientId=' + $scope.confirmPatientInfo.rxCPatientId,
                method: 'GET'
            });

            patientBasketPromise.then(function(result) {
                if (result.patientFillInfoList.length != 0) {
                    PatientFactory.addToSelectedPatientList($scope.confirmPatientInfo);
                    BasketService.updateBasketData($scope.confirmPatientInfo.rxCPatientId, result);
                    $scope.loadActionNoteInformation(result);
                    phrStatusPromise.then(function(eccData) {
                        PatientFactory.setEccInfoByPatientId($scope.confirmPatientInfo.rxCPatientId, eccData);
                    }, function(eccData) {
                        // var modalOptions = {
                        //     buttons: ['OK'],
                        //     headerText: 'Error',
                        //     bodyText: 'Sorry, we are temporarily unable to complete this transaction due to system issue.<br/>If you would like to join the Pharmacy ExtraBucks Rewards program, you can go online<br/>to cvs.com/rxrewards today or we can take care of this for you on your next visit.',
                        //     blockUI: true
                        // };
                        // DialogService.showDialog({}, modalOptions).then(function(type) {});
                    });
                    callback && callback();
                } else {
                    var modalOptions = {
                        buttons: ['OK'],
                        headerText: 'No Prescriptions Found',
                        bodyText: 'No prescriptions were found for this patient.'
                    };
                    DialogService.showDialog({}, modalOptions).then(function(result) {
                        $location.url('/patient-lookup');
                    });
                }
            }, function(result) {
                appUtils.log('Empty Patient profile got from RxConnect');
                var modalOptions = {
                    buttons: ['OK'],
                    headerText: 'System Error',
                    bodyText: 'Patient Profile cannot be fetched from RxConnect due to system issue for this patient.'
                };
                DialogService.showDialog({}, modalOptions).then(function(result) {
                    $location.url('/patient-lookup');
                });
            });
        };

        $scope.loadActionNoteInformation = function(result) {

            var scriptBarcode;
            var isActionable = false;
            var actionable;
            var isRXItemActionable = false;
            var isActionCommunicated = true;
            var isTpComplinceMess = true;
            var messageConfig;
            var messageConfigButtons;
            var progType;
            //for all action note message type is 1
            var messageType = 1;
            var ensMessageId;
            var tpMessageid;
            var isTpComplinceMessage;
            var eanMsg;

            //Action Note message data  
            angular.forEach(result.patientMessageInfo.eanMsg, function(actionItem) {
                ensMessageId = $scope.buildPartialRxbarcodeMsgItem(actionItem);
                isActionable = true;
                isActionCommunicated = true;
                eanMsg = actionItem;
                progType = actionItem.progType;
                if (actionItem.commInd === 'N') {
                    isActionCommunicated = false;
                }

                angular.forEach(result.patientFillInfoList, function(rxItem) {
                    scriptBarcode = $scope.buildPartialRxbarcode(rxItem);
                    isRXItemActionable = false;
                    if (scriptBarcode === ensMessageId) {
                        // if (rxItem.itemStatus.actionable === 'Y') {
                        isRXItemActionable = true;
                        // }
                        actionable = rxItem.itemStatus.actionable;
                        angular.forEach(DAILY_CONFIG.messageConfig.messageConfig.msgConfig, function(message) {
                            if (message.msgType == messageType) {
                                if (message.progType == progType) {
                                    messageConfig = message;
                                }
                            }
                        });

                        if (rxItem.itemStatus.actionable === 'Y') {
                            messageConfigButtons = DAILY_CONFIG.actionNoteButtonConfig.actionNoteButtonConfig.actionableButtonsConfig;
                        } else {
                            messageConfigButtons = DAILY_CONFIG.actionNoteButtonConfig.actionNoteButtonConfig.nonActionableButtonsConfig;
                        }

                        return isRXItemActionable;

                    }
                });

                var actionNotedata = {
                    barcode: ensMessageId,
                    isActionable: isActionable,
                    isActionCommunicated: isActionCommunicated,
                    isRXItemActionable: isRXItemActionable,
                    messageConfig: messageConfig,
                    messageConfigButtons: messageConfigButtons,
                    progType: progType,
                    messageType: messageType,
                    eanMsg: eanMsg,
                    patientId: result.patientDetails.rxCPatientId,
                    actionable: actionable
                };

                PatientFactory.setActionNoteDetails(actionNotedata);
            });
            //TP compliances Message -- As this logic is moved to server side need to remove below code
            scriptBarcode = '';
            var tpcomplianceMsg;

            angular.forEach(result.patientMessageInfo.tpComplianceMsg, function(tpcomplianceMessage) {
                tpMessageid = '' + tpcomplianceMessage.rxNum + tpcomplianceMessage.refillNum + tpcomplianceMessage.partialFillSeqNum + tpcomplianceMessage.editVersionNum;
                isTpComplinceMess = true;
                angular.forEach(result.patientFillInfoList, function(rxItem) {
                    scriptBarcode = '' + rxItem.rxNum + rxItem.refillNum + rxItem.partialFillSeqNum + rxItem.editVersionNum;
                    if (scriptBarcode === tpMessageid) {
                        tpcomplianceMsg = tpcomplianceMessage;
                    }
                });

                var tpData = {
                    tpMessageid: tpMessageid,
                    tpMessage: tpcomplianceMsg,
                    isTpComplinceMess: isTpComplinceMess
                };

                PatientFactory.setTpComplianceMessageDetails(tpData);
                //console.log(tpData);
            });


        };
        $scope.showVerifyAgent = function() {
            $location.url("/verify-associate");
        };


    });
