'use strict';
angular.module('weCarePlusApp')
    .controller('EmployeeMgmtCtrl', function($scope, CONFIG, EmployeeMgmtFactory, $modalInstance, DialogService, Request, NumberEntryService) {
        $scope.employeeInfo = EmployeeMgmtFactory.getUserInfo();
        $scope.enableMealWaiver = (CONFIG.storeData.stateCode === 'CA') ? true : false;

        $scope.dismiss = function() {
            $modalInstance.dismiss();
        };

        $scope.removeEmp = function(employee) {
            var modalOptions = {
                buttons: ['No', 'Yes'],
                headerText: ' Confirm',
                bodyText: 'Are you sure you want to delete saved login info for ' + employee.firstName + ' , ' + employee.lastName + ' ?'
            };
            DialogService.showDialog({}, modalOptions).then(function(result) {
                if (result == "Yes") {
                    var empDelPromise = Request.invoke({
                        url: appConfig.store.services.API.employees + '/' + employee.empId,
                        method: 'DELETE'
                    });
                    empDelPromise.then(function(result) {
                        for (var i = $scope.employeeInfo.length - 1; i >= 0; i--) {
                            if ($scope.employeeInfo[i].empId == employee.empId) {
                                $scope.employeeInfo.splice(i, 1);
                            }
                        }
                    }, function(result, statusCode) {

                    });
                }

            }, function() {
                //
            });
        };

        $scope.doMealWaiverAction = function(type, employee) {
            var selectedShift = (type === 'firstMealWaiver') ? '< 6 hr' : '10 - 12 hr';
            var modalOptions = {
                buttons: ['No', 'Yes'],
                headerText: 'Confirm',
                bodyText: 'You are about to change the meal waiver option for shift <b>' + selectedShift + '</b> for <b>' + employee.lastName + ',' + employee.firstName + '</b>. Do you want to proceed?'
            };
            DialogService.showDialog({}, modalOptions).then(function(result) {
                if (result === 'Yes') {
                    var modalOptionsEmp = {
                        usernameHeaderText: 'Verify Employee',
                        usernameInputTextHelp: 'Enter Employee ID Number',
                        passwordHeaderText: 'Verify Employee',
                        passwordInputTextHelp: 'Password',
                        usernameCancelConfirm: true,
                        passwordCancelConfirm: true
                    };
                    NumberEntryService.showDialog({}, {
                        inputText: modalOptionsEmp.usernameInputTextHelp,
                        headerText: modalOptionsEmp.usernameHeaderText,
                        cancelConfirm: modalOptionsEmp.usernameCancelConfirm
                    }).then(function(resUN) {
                        if (resUN) {
                            if (employee.empId !== resUN) {
                                var modalOptionsMatch = {
                                    buttons: ['OK'],
                                    headerText: 'Error',
                                    bodyText: "Employee ID didn't match with selection"
                                };
                                DialogService.showDialog({}, modalOptionsMatch).then(function(result) {

                                });
                            } else if (employee.empId === resUN) {
                                NumberEntryService.showDialog({}, {
                                    inputText: modalOptionsEmp.passwordInputTextHelp,
                                    headerText: modalOptionsEmp.passwordHeaderText,
                                    cancelConfirm: modalOptionsEmp.passwordCancelConfirm,
                                    inputType: 'password'
                                }).then(function(resPW) {
                                    if (resPW) {
                                        Request.invoke({
                                            url: appConfig.store.services.API.employees + '?emp_id=' + resUN + '&pin=' + resPW,
                                            method: 'GET',
                                            loadMessage: "Authenticating Employee..."
                                        }).then(function(result) {
                                            if (employee[type]) {
                                                employee[type] = false;
                                            } else {
                                                employee[type] = true;
                                            }
                                            var payload = {
                                                "EmployeeWaiverRequest": {
                                                    "employeeId": employee.empId,
                                                    "firstMealWaiver": (type === 'firstMealWaiver') ? employee.firstMealWaiver : null,
                                                    "secondMealWaiver": (type === 'secondMealWaiver') ? employee.secondMealWaiver : null
                                                }
                                            };
                                            var mealWaiverPromise = Request.invoke({
                                                loadMessage: "Updating meal waiver...",
                                                url: appConfig.store.services.API.mealWaiver,
                                                method: 'POST',
                                                data: payload
                                            });
                                            mealWaiverPromise.then(function(data) {}, function() {
                                                DialogService.showDialog({}, {
                                                    buttons: ['OK'],
                                                    headerText: 'Error',
                                                    bodyText: 'Error updating meal waiver, Please try again later.'
                                                }).then(function(type) {});
                                                employee[type] = !employee[type];
                                            });
                                        }, function(result, statusCode) {
                                            DialogService.showDialog({}, {
                                                buttons: ['OK'],
                                                headerText: 'Error',
                                                bodyText: CONFIG.lastCallResponse.moreInfo || 'Employee not on file'
                                            }).then(function(type) {});
                                        });
                                    }
                                });
                            }
                        }
                    });
                }
            });
        };
    });
