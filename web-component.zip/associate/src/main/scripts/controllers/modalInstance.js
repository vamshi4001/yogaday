'use strict';

	// Please note that $modalInstance represents a modal window (instance) dependency.
	// It is not the same as the $modal service used above.
	// This is the controller with in the modal window. any buttons or functions we have to write here 

angular.module('weCarePlusApp')
    .controller('ModalInstanceCtrl', function ($scope, $modalInstance, items) {
    	$scope.items = items;
		$scope.basketData = items.basketData;
		$scope.selectedPatientList = items.selectedPatientList;

	  $scope.ok = function () {
	  	//from this parameter we would be able to send data back to invoking controller. 
	    $modalInstance.close($scope.basketData);
	  };

	  $scope.buttonInvocation = function (buttonID, patientInfo,basketItemInfo) {
	  	if(buttonID =='continueWithoutSelling') {
	 	  var lengthOfBasket = $scope.basketData[patientInfo.patientID].length;
          for(var i=0; i<lengthOfBasket; i++) {
            if($scope.basketData[patientInfo.patientID][i].rxItemId == basketItemInfo.rxItemId) {
              $scope.basketData[patientInfo.patientID][i].greenSelectedItem = true;
            } 
          }
         }
       }

	 /* $scope.cancel = function () {
	    $modalInstance.dismiss('cancel');
	  };*/
    });
    


