angular.module('weCarePlusApp')
    .controller('HipaaFormModalCtrl', function($scope, $modalInstance, $modal, $socket, CONFIG,
        Request, BasketFactory, PrintService, OrderFactory, data, HipaaService, PatientFactory, 
        DialogService) {
        $scope.extraCareCardNo = data.extraCareCardNo || "";
        $scope.phrEnrollmentBarcode = data.phrEnrollmentBarcode;
        $scope.customerSigned = data.customerSigned;

        $scope.$on('SCANNED_DATA_ECC_HIPAA', function(evt, barcode) {
            if (OrderFactory.getEccNumber() && barcode !== OrderFactory.getEccNumber()) {
                var modalOptions = {
                    buttons: ['Use Scanned<br/>Card', 'Use Original<br/>Card'],
                    headerText: 'Information',
                    bodyText: 'The ExtraCare card scanned is different than the card used for original ExtraCare Pharmacy & Health Rewards enrollment.<br/>Confirm patient wants to move enrollment to the Scanned Card.',
                    blockUI: true
                };
                DialogService.showDialog({}, modalOptions).then(function(result) {
                    if (result === 'Use Scanned<br/>Card') {
                        $scope.extraCareCardNo = barcode;
                    }
                });
            } else {
                if (!$scope.extraCareCardNo) {
                    $scope.extraCareCardNo = barcode;
                } else if ($scope.extraCareCardNo !== barcode) {
                    var modalOptions = {
                        buttons: ['OK'],
                        headerText: 'Information',
                        bodyText: 'ExtraCare card already scanned.',
                        blockUI: true
                    };
                    DialogService.showDialog({}, modalOptions).then(function(result) {
                        $scope.extraCareCardNo = barcode;
                    });
                }
            }
            $scope.$apply();
        });

        $scope.enrollPHR = function() {
            if ($scope.enrollmentType && $scope.extraCareCardNo) {
                BasketFactory.setDriveThru(false);
                var payload = {
                    "hrEnrollRequest": {
                        "actionCd": "E",
                        "idTypeCd": "R",
                        "idNbr": data.patinetId,
                        "encodedXtraCardNbr": $scope.extraCareCardNo,
                        "hippaSignByCd": $scope.enrollmentType,
                        "esigFmtCd": "D",
                        "esigData": HipaaService.getEsignData(),
                        "formVerNbr": $scope.customerSigned ? "9" : "10"
                    }
                };
                var phrEnrollmentPromise = Request.invoke({
                    loadMessage: "Enrolling in health rewards...",
                    url: appConfig.store.services.API.phrEnrollment,
                    method: 'POST',
                    data: payload
                });
                phrEnrollmentPromise.then(
                    function(result) {
                        HipaaService.setHipaaInProcess(false);
                        var enrollmentStatus = data.customerSigned ? 'E' : 'P';
                        PatientFactory.updatePhrEnrolled(data.patinetId, enrollmentStatus);
                        PatientFactory.updateHipaaResolved(data.patinetId);
                        $modalInstance.close();
                    },
                    function(result) {
                        HipaaService.setHipaaInProcess(false);
                        PatientFactory.updateHipaaResolved(data.patinetId);
                        var modalOptions = {
                            buttons: ['OK'],
                            headerText: 'Error',
                            bodyText: 'Sorry, we are temporarily unable to complete this transaction due to system issue.<br/>If you would like to join the Pharmacy ExtraBucks Rewards program, you can go online<br/>to cvs.com/rxrewards today or we can take care of this for you on your next visit.',
                            blockUI: true
                        };
                        DialogService.showDialog({}, modalOptions).then(function(result) {});
                        $modalInstance.close();
                    });
            }
        };

        $scope.cancel = function() {
            HipaaService.setHipaaInProcess(false);
            PatientFactory.updateHipaaResolved(data.patinetId);
            $modalInstance.close();
        };
    });
