angular.module('weCarePlusApp')
    .controller('ContactUpdateModalCtrl', function($scope, $modalInstance, data, CONFIG, $socket, DialogService, BasketFactory, deferred) {
        $scope.data = data;
        $scope.CONFIG = CONFIG;
        $scope.currentFocus = {};
        $scope.basketItemInfo = BasketFactory.getBasketData()[$scope.data.patientId];
        $scope.inputValue = $scope.data.phoneNumber;
        var oldNum = $scope.inputValue ? ($scope.inputValue + "") : "";

        $scope.onScreenKeyClick = function(keyType, keyVal) {
            var tempValue = $scope[$scope.currentFocus.model];
            if (keyType === 'normKey') {
                tempValue = tempValue ? (tempValue + keyVal) : keyVal;
                if (tempValue.length > 10) {
                    return;
                }
            } else if (keyType === 'splKey') {
                switch (keyVal) {
                    case 'cancel':
                        tempValue = '';
                        $modalInstance.dismiss();
                        break;
                    case 'clear':
                        tempValue = '';
                        break;
                    case 'back':
                        tempValue = tempValue ? (tempValue.length > 0 ? tempValue.substr(0, tempValue.length - 1) : '') : null;
                        break;
                    case 'enter':
                        if ($scope.enterKeyActive) {
                            if ($scope.inputValue.charAt(0) == '0') {
                                var modalOptions = {
                                    buttons: ['OK'],
                                    headerText: 'Error',
                                    bodyText: 'Invalid area code.',
                                    blockUI: true
                                };
                                DialogService.showDialog({}, modalOptions).then(function(result) {});
                                return;
                            } 
                            var phoneValidMessage = appUtils.phoneValidation($scope.inputValue);
                            if (phoneValidMessage !== "VALID") {
                                var modalOptions = {
                                    buttons: ['OK'],
                                    headerText: 'Error',
                                    bodyText: phoneValidMessage,
                                    blockUI: true
                                };
                                DialogService.showDialog({}, modalOptions).then(function(result) {});
                                return;
                            }
                            if ($scope.data.parent === 'SMS') {
                                var modalOptions = {
                                    buttons: [],
                                    headerText: 'Customer Terminal Processing',
                                    bodyText: 'WAITING FOR CUSTOMER RESPONSE',
                                    blockUI: true
                                };
                                DialogService.showDialog({}, modalOptions);
                                $socket.send(JSON.stringify({
                                    type: 'DISPLAY_QUESTION',
                                    options: {
                                        route: 'smsEnrollConfirm',
                                        payload: {
                                            mobile: $scope.inputValue
                                        }
                                    }
                                }), true).then(function(response) {
                                    if (response.options.accepted) {
                                        deferred && deferred.resolve($scope.inputValue);
                                        $scope.enterKeyActive = true;
                                        $modalInstance.dismiss();
                                    } 
                                    DialogService.closeDialog();
                                });

                            } else if ($scope.data.parent === 'PATIENT_DEMOGRAPHIC') {
                                deferred && deferred.resolve($scope.inputValue);
                                $modalInstance.dismiss();
                            }
                        } else {
                            if (tempValue.length === 10) {
                                if ($scope.data.parent === 'SMS') {
                                    var modalOptions = {
                                        buttons: [],
                                        headerText: 'Customer Terminal Processing',
                                        bodyText: 'WAITING FOR CUSTOMER RESPONSE',
                                        blockUI: true
                                    };
                                    DialogService.showDialog({}, modalOptions);
                                    $socket.send(JSON.stringify({
                                        type: 'DISPLAY_QUESTION',
                                        options: {
                                            route: 'smsEnrollConfirm',
                                            payload: {
                                                mobile: $scope.inputValue
                                            }
                                        }
                                    }), true).then(function(response) {
                                        if (response.options.accepted) {
                                            deferred && deferred.resolve($scope.inputValue);
                                            $scope.enterKeyActive = true;
                                            $modalInstance.dismiss();
                                        } 
                                        DialogService.closeDialog();
                                    });

                                } else if ($scope.data.parent === 'PATIENT_DEMOGRAPHIC' && $scope.data.key === 'mobile' && $scope.data.smsEnrolled) {
                                    var modalOptions = {
                                        buttons: [],
                                        headerText: 'Customer Terminal Processing',
                                        bodyText: 'WAITING FOR CUSTOMER RESPONSE',
                                        blockUI: true
                                    };
                                    DialogService.showDialog({}, modalOptions);
                                    $socket.send(JSON.stringify({
                                        type: 'DISPLAY_QUESTION',
                                        options: {
                                            route: 'smsEnrollConfirm',
                                            payload: {
                                                mobile: $scope.inputValue
                                            }
                                        }
                                    }), true).then(function(response) {
                                        if (response.options.accepted) {
                                            deferred && deferred.resolve($scope.inputValue);
                                            $modalInstance.dismiss();
                                        }
                                        DialogService.closeDialog();
                                    });
                                } else if ($scope.data.parent === 'PATIENT_DEMOGRAPHIC') {
                                    deferred && deferred.resolve($scope.inputValue);
                                    $modalInstance.dismiss();
                                }
                            } else if (tempValue.length === 0) {
                                if ($scope.data.parent === 'PATIENT_DEMOGRAPHIC') {
                                    if ($scope.basketItemInfo.patientDetails.textMessagingEnrollmentIndicator === 'Yes' && $scope.data.key === 'mobile') {
                                        var modalOptions = {
                                            buttons: ['OK'],
                                            headerText: 'Not Allowed',
                                            bodyText: 'This number is enrolled in text messaging and<br/>cannot be cleared.',
                                            blockUI: true
                                        };
                                        DialogService.showDialog({}, modalOptions).then(function(result) {});
                                        return;
                                    } else {
                                        deferred && deferred.resolve($scope.inputValue);
                                        $modalInstance.dismiss();
                                    }
                                }
                            }
                        }
                        return;
                        break;
                    default:
                        break;
                }
            } else {
                appUtils.log("Invalid type of key pressed.");
            }
            $scope[$scope.currentFocus.model] = tempValue;
            $scope.enterKeyActive = tempValue.length === 10;
        };

        $scope.patientEntry = function() {
            var modalOptions = {
                buttons: [],
                headerText: 'Customer Terminal Processing',
                bodyText: 'WAITING FOR CUSTOMER RESPONSE',
                blockUI: true
            };
            DialogService.showDialog({}, modalOptions);
            $socket.send(JSON.stringify({
                type: 'DISPLAY_QUESTION',
                options: {
                    route: 'newPhone',
                    payload: {
                        mobile: $scope.basketItemInfo.patientDetails.patientCntctInfo.phone.mobile,
                        fromTcpa: $scope.data.fromTcpa
                    }
                }
            }), true).then(function(response) {
                DialogService.closeDialog();
                if (response.options.phone) {
                    $scope.inputValue = response.options.phone;
                    $scope.enterKeyActive = true;
                    $scope.$apply();
                } else {
                    $scope.enterKeyActive = false;
                }
            });
        };
    });
