/*
	MedD Informational Message Popup Controller

	data = {
	    patientDetails: //Patient Details
	    basketItem: //Current RxInfo Object,
	    message: //MedD Message,
	    messageType: 'MedD',
	    callback: //Popup dismiss Callback
	}	
*/
angular.module('weCarePlusApp')
    .controller('MedDInfoCtrl', function($scope, data, $modalInstance) {
        $scope.data = data;
        $scope.continue = function() {
            event && event.preventDefault();
            $modalInstance.dismiss();
            data && data.callback && data.callback(true);
        }
    });
