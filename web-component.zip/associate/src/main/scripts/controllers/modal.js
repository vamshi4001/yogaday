'use strict';

angular.module('weCarePlusApp')
    .controller('ModalCtrl', function($scope, $modal, $log) {
    	//sample data that could me passed to a modal screen controller
      $scope.items = ['item1', 'item2', 'item3'];

	  $scope.animationsEnabled = true;
	  // when you clicked on the button this open function will be called. 
	  $scope.open = function (size) {
	  	// This is a function in the UI bootstrap Modal to open a modal
	    var modalInstance = $modal.open({
	      animation: $scope.animationsEnabled,
	      templateUrl: 'myModalContent.html',
	      controller: 'ModalInstanceCtrl',
	      size: size,
	      // to inject model (data) to modal screen controller 
	      resolve: {
	        items: function () {
	          return $scope.items;
	        }
	      }
	    });
	    // iwe receive data from modal screen controller back when you click on continue button first function will be called. 
	    modalInstance.result.then(function (selectedItem) {
	      $scope.selected = selectedItem;
	    }, function () {
	      $log.info('Modal dismissed at: ' + new Date());
	    });
	  };

	  $scope.toggleAnimation = function () {
	    $scope.animationsEnabled = !$scope.animationsEnabled;
	  };
    });
