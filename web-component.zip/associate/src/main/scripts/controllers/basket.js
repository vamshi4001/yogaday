'use strict';

angular.module('weCarePlusApp')
    .controller('BasketCtrl', function($rootScope, $scope, $location, $route, $routeParams, $modal, Request, PatientFactory,
        BasketFactory, DialogService, $log, $filter, $socket, CONFIG, OrderFactory, NumberEntryService, PrintService, ModalService,
        MessageService, BasketService,$q) {
        $scope.selectedPatientList = PatientFactory.getSelectedPatientList();
        $scope.actionNoteForPatients = PatientFactory.getActionNoteDetails();
        $scope.tpMessagesForPatients = PatientFactory.getTpcomplianceMessageDetail();
        $scope.basketData = BasketFactory.getBasketData();
        $scope.rxItemsInOrder = BasketFactory.getRxItemsInOrder();
        $scope.countClick = 0;
        $scope.hasUnScannedRxItems = true;
        $scope.CONFIG.pageTitle = "Prescription Basket";
        $scope.continueKeyActive = false;
        $scope.tempData = {
            orderTotal: 0
        };
        $scope.isSpecialityOrderCompleted = true;
        $scope.noDispositionCount = 0;
        $scope.selectedPatient = null;
        var SCENORIO_STRING = "scenario";
        $scope.noOfPatients = Object.keys($scope.basketData).length;
        $scope.itemsInOrderCount = 0;
        $scope.orderHasImmunizationFlag = false;
        $scope.isImmunizationResolved = false;
        $scope.isEccScanAllowed = true;
        $scope.isEccInOrder = OrderFactory.getEccNumber();
        $scope.isFastpass = OrderFactory.getFastpass() && OrderFactory.getFastpassData();
        $scope.messageAlertsQueued = [];
        $scope.rxScanMessages = {};
        $scope.partialBarcodeRxInfoMap = BasketFactory.getPartialBarcodeRxInfoMap()

        $scope.init = function() {
            if (BasketFactory.getBasketPageMsgAlert()) {
                $modal.open({
                    templateUrl: 'views/messages/message-centric.html',
                    keyboard: false,
                    backdrop: false,
                    controller: 'MessageCentricCtrl',
                    size: 'md',
                    windowClass: 'minor-popup'
                });
            }
        };

        $scope.scanItem = function(basketData, event) {
            $scope.codetype = "110";
            $scope.code = $scope.buildRxBarcode(basketData, basketData.specialtyOrderNum)
            if ($scope.code) {
                $rootScope.$broadcast('BARCODE_SCAN', {
                    scanData: window.btoa($scope.code),
                    scanDataType: $scope.codetype
                });
            }
            event.stopPropagation();
        };

        $scope.resolveBasketActionNotes = function(isRxScan) {
            var unresolvedCount = 0;
            angular.forEach($scope.basketData, function(pprItem, patientID) {
                angular.forEach(pprItem.patientFillInfoList, function(fillInfo) {
                    if ((isRxScan && fillInfo.itemStatus.actionable === 'Y') || !isRxScan) {
                        var partialBarcode = $scope.buildPartialRxbarcode(fillInfo);
                        var actionNoteInfo = $scope.actionNoteForPatients[partialBarcode];
                        if (actionNoteInfo && actionNoteInfo.isActionable && !actionNoteInfo.isActionCommunicated) {
                            unresolvedCount++;
                            $scope.messageAlertsQueued.push({
                                patientDetails: pprItem.patientDetails,
                                fillInfo: fillInfo,
                                messageType: 'AN'
                            });
                            // $scope.actionNoteEvent(pprItem.patientDetails, fillInfo);
                        }
                    }
                });
            });
            return unresolvedCount;
        };
        $scope.resolveAllMessAlertsQueued = function(fromCallback) {
            if (fromCallback && $scope.messageAlertsQueued && $scope.messageAlertsQueued.length) {
                $scope.messageAlertsQueued.shift();
            }
            if ($scope.messageAlertsQueued.length) {
                if ($scope.messageAlertsQueued[0].messageType === 'AN') {
                    //$scope.actionNoteEvent($scope.messageAlertsQueued[0].patientDetails, $scope.messageAlertsQueued[0].fillInfo);
                } else if ($scope.messageAlertsQueued[0].messageType === 'TP') {
                    //$scope.tpComplinceMessageActoion($scope.messageAlertsQueued[0].patientDetails, $scope.messageAlertsQueued[0].basketItem, $scope.messageAlertsQueued[0].data);
                } else if ($scope.messageAlertsQueued[0].messageType === 'MedD') {
                    //Show MedD Popup Message
                    $scope.showMedDInfoMessage($scope.messageAlertsQueued[0]);
                } else if ($scope.messageAlertsQueued[0].messageType === 'MedB') {
                    $scope.showMedBMessage($scope.messageAlertsQueued[0]);
                }
            }
        };

        // Show MedD Popup Message
        /*
            data = {
                patientDetails: //Patient Details
                basketItem: //Current RxInfo Object,
                message: //MedD Message,
                messageType: 'MedD',
                callback: //Popup dismiss Callback
            }
        */
        $scope.showMedDInfoMessage = function(data) {
            //Open the MedD Popup Message
            $modal.open({
                templateUrl: 'views/modals/med-d.html',
                keyboard: false,
                windowClass: 'modal-dialog-full',
                controller: 'MedDInfoCtrl',
                backdrop: 'static',
                resolve: {
                    'data': function() {
                        return data;
                    }
                }
            });
        }
        $scope.getWaitingBinCount = function(patientId) {
            var waitingBinCount = 0;
            angular.forEach($scope.basketData[patientId].patientFillInfoList, function(basketItem) {
                if ((basketItem.itemStatus.fillConfigCode === 'WB' || basketItem.itemStatus.fillConfigCode === 'SWB') && basketItem.fillDisposition.dispositionKey !== 'SLD') {
                    waitingBinCount++;
                }
            });
            return waitingBinCount;
        };

        $scope.getBasketOrderTotal = function() {
            var basketOrderTotal = 0;
            angular.forEach($scope.basketData, function(pprItem, patientID) {
                angular.forEach(pprItem.patientFillInfoList, function(basketItem) {
                    if (basketItem.fillDisposition.barcode && basketItem.fillDisposition.dispositionKey == 'SLD') {
                        basketOrderTotal += basketItem.patPayAmt;
                    }
                });
            });
            return basketOrderTotal;
        };

        $scope.processSelectedFill = function(patientInfo, basketItemInfo) {

            BasketFactory.setSelectedPatientProfileFillInfo(basketItemInfo);
            MessageService.compileMessage('rxSelect',$q.defer());
        };

       /* $scope.expediteServiceInvoke = function(basketItemInfo) {
            appUtils.log("Expedited service called on :" + JSON.stringify(basketItemInfo));
            var payload = {
                "ExpediteRequest": {
                    "rxNumber": basketItemInfo.rxNum,
                    "refillNumber": basketItemInfo.refillNum,
                    "editVersionNumber": basketItemInfo.editVersionNum,
                    "partialFillSeqNumber": basketItemInfo.partialFillSeqNum
                }
            };
            var expediteServiceRequest = Request.invoke({
                url: appConfig.store.services.API.expedite,
                method: 'POST',
                data: payload
            });
            expediteServiceRequest.then(function(result) {
                appUtils.log('expedite service is update with details');
            }, function(result) {
                appUtils.log('expedite Not able to service the request');
            });
        }*/
        $scope.home = function() {
            $socket.clear();
            PatientFactory.clearSelectedPatientList();
            BasketFactory.clearWholeOrder();
            $location.url('/home');
        }

        $scope.pharmacyHealthRewards = function() {
            $scope.isEccScanAllowed = false;
            $modal.open({
                templateUrl: 'views/modals/enrollment-status.html',
                keyboard: false,
                /*windowClass: 'major-popup',*/
                backdrop: false,
                scope: $scope.$new(),
                controller: 'PHRModalCtrl',
                resolve: {
                    'data': function() {
                        return {
                            selectedPatientList: $scope.selectedPatientList,
                            isEccScanAllowed: $scope.isEccScanAllowed
                        };
                    }
                }
            });
        };

        $scope.completeHipaaForm = function(selectedPatient, socketResp) {
            socketResp = socketResp ? socketResp : {};
            if (socketResp.noSingnature) {
                var modalOptions = {
                    buttons: ['OK'],
                    headerText: '',
                    bodyText: 'Customer DID NOT sign electronically.'
                };
                DialogService.showDialog({}, modalOptions).then(function(result) {
                    PrintService.doPrint(appConfig.store.services.API.printService.phrEnrollment, {});
                    $modal.open({
                        templateUrl: 'views/modals/hipaa-form.html',
                        keyboard: false,
                        /*windowClass: 'major-popup',*/
                        backdrop: false,
                        scope: $scope.$new(),
                        controller: 'PHRModalCtrl',
                        resolve: {
                            'data': function() {
                                return {
                                    selectedPatient: selectedPatient,
                                    socketResp: socketResp
                                };
                            }
                        }
                    });
                });
            } else {
                $modal.open({
                    templateUrl: 'views/modals/hipaa-form.html',
                    keyboard: false,
                    /*windowClass: 'major-popup',*/
                    backdrop: false,
                    scope: $scope.$new(),
                    controller: 'PHRModalCtrl',
                    resolve: {
                        'data': function() {
                            return {
                                selectedPatient: selectedPatient,
                                socketResp: socketResp
                            };
                        }
                    }
                });
            }
        };

        $scope.$on('SCANNED_DATA_GENERIC', function(evt, barcode, SCANNED_BARCODE_TYPE) {
            if (SCANNED_BARCODE_TYPE !== 'SCANNED_DATA_RX' && SCANNED_BARCODE_TYPE !== 'SCANNED_DATA_SPLRX' && SCANNED_BARCODE_TYPE !== 'SCANNED_DATA_ECC') {
                var modalOptions = {
                    buttons: ['OK'],
                    headerText: 'Error',
                    bodyText: 'Unexpected Bar Code Type Scanned.'
                };
                DialogService.showDialog({}, modalOptions).then(function(result) {
                    //Close window
                });
                return;
            }
        });

        $scope.$on('SCANNED_DATA_RX', function(evt, barcode) {
            if (DAILY_CONFIG.screenConfig.screenConfig && DAILY_CONFIG.screenConfig.screenConfig.maxPosSold && (Object.keys($scope.rxItemsInOrder).length >= DAILY_CONFIG.screenConfig.screenConfig.maxPosSold)) {
                var modalOptions = {
                    buttons: ['OK'],
                    headerText: 'Error',
                    bodyText: 'Max POS Items in Order, Action not allowed.'
                };
                DialogService.showDialog({}, modalOptions).then(function(result) {
                    //Close window
                });
                return;
            }
            appUtils.log("Rx Scanned...");
            $scope.addRxItemToOrder(barcode);
        });

        $scope.$on('SCANNED_DATA_SPLRX', function(evt, barcode) {
            if (DAILY_CONFIG.screenConfig.screenConfig && DAILY_CONFIG.screenConfig.screenConfig.maxPosSold && (Object.keys($scope.rxItemsInOrder).length >= DAILY_CONFIG.screenConfig.screenConfig.maxPosSold)) {
                var modalOptions = {
                    buttons: ['OK'],
                    headerText: 'Error',
                    bodyText: 'Max POS Items in Order, Action not allowed.'
                };
                DialogService.showDialog({}, modalOptions).then(function(result) {
                    //Close window
                });
                return;
            }
            appUtils.log("Rx Scanned...");
            $scope.addRxItemToOrder(barcode);
        });

        $scope.addPatient = function() {
            //alert('hihi')
            $location.url('/patient-lookup');
        };

        /*$scope.orderHasImmunization = function() {
            if ($scope.orderHasImmunizationFlag) {
                return;
            }
            var isImmunizationRxInBasket = false;
            var immuniztionRxItems = [];
            angular.forEach($scope.rxItemsInOrder, function(item, barcode) {
                if (item.basketItemInfo.immunizationRxInd == 'Y') {
                    isImmunizationRxInBasket = true;
                    immuniztionRxItems.push(item.basketItemInfo.rxNum);
                }
            });
            if (isImmunizationRxInBasket) {
                var modalOptions = {
                    buttons: ['OK'],
                    headerText: 'Prescription for Immunization Appointment',
                    bodyText: 'Rx #: ' + immuniztionRxItems.toString() + '<br><br>Update the Immunization information in RxConnect for the listed Rx #’s and print a consent form before the immunization is administered'
                };

                DialogService.showDialog({}, modalOptions).then(function(result) {
                    if (result === 'OK') {
                        $scope.isImmunizationResolved = true;
                        $scope.orderHasImmunizationFlag = true;
                        return;
                    }
                });
            } else {
                $scope.isImmunizationResolved = true;
                $scope.orderHasImmunizationFlag = true;
                return;
            }
        };
*/
        $scope.completeRxOrder = function(event) {
            
            var completeOrderMessagePromiss= MessageService.completeRxOrder('completeRxOrder');

            //if ($scope.resolveBasketActionNotes() > 0) {
            //   return;
           // }
            var unScannedRxItemsInBasket = $scope.hasUnScannedRxInBasket();
            /*if (unScannedRxItemsInBasket) {
                // if ($scope.itemsInOrderCount === 0) {
                //     var modalOptions = {
                //         buttons: ['OK'],
                //         headerText: 'Error',
                //         bodyText: 'No Items in Order'
                //     };
                //     DialogService.showDialog({}, modalOptions).then(function(result) {
                //         //Close window
                //     });
                //     return;
                // }
                $modal.open({
                    templateUrl: 'views/modals/unscanned-rx-list.html',
                    keyboard: false,
                    backdrop: false,
                    windowClass: 'modal-dialog-full',
                    controller: 'UnScannedRxModalCtrl',
                    resolve: {
                        'data': function() {
                            return {
                                basketData: $scope.basketData,
                                selectedPatientList: $scope.selectedPatientList,
                                continueKeyActive: $scope.continueKeyActive,
                                expediteServiceInvoke: $scope.expediteServiceInvoke,
                                scope: $scope
                            };
                        }
                    }
                });
            } else {*/
                completeOrderMessagePromiss && completeOrderMessagePromiss.then(function(){
                 var rxOderPayload = BasketFactory.getRxOrderData();
                //used to constract Complete Order Request
                var patientProfileRsp = {
                    'patientProfileList': rxOderPayload,
                    miscInfo: null
                };
                var completeOderRequest = {
                    'TransactionObject': patientProfileRsp
                };

                // appUtils.log(JSON.stringify(completeOderRequest));
                var completeRxOrderService = Request.invoke({
                    loadMessage: "Completing order...",
                    url: appConfig.store.services.API.completeRxOrder,
                    method: 'POST',
                    data: completeOderRequest
                });
                completeRxOrderService.then(function(result) {
                    //setting data to order Factory for reusing
                    OrderFactory.setRxOrderDataToTxn(rxOderPayload);
                    OrderFactory.setTransactionDetails(result);
                    $location.url('/transaction-details');
                    // $location.url('/patient-list');
                }, function(result) {
                    if (result.code == '500') {
                        var errorList = result.payload;
                        angular.forEach(errorList, function(errorItem) {
                            if (errorItem.rxNumber && errorItem.exceptionMessage) {
                                var modalOptions = {
                                    buttons: ['OK'],
                                    headerText: 'Error',
                                    bodyText: (errorItem.exceptionMessage + ' ' + errorItem.rxNumber)
                                };
                                DialogService.showDialog({}, modalOptions).then(function(result) {
                                    //Close window
                                });
                            }
                        });
                    }


                });
                /*if ($scope.itemsInOrderCount === 0) {
                    $scope.clearAllFactories();
                    $location.url("/home");
                    return;
                }
                if (!$scope.isImmunizationResolved) {
                    $scope.orderHasImmunization();
                }
                if (!$scope.orderHasImmunizationFlag) {
                    $scope.orderHasImmunizationFlag = false;
                    return;
                }
                $scope.hasAnySpecialOrderInItem();

                if (!$scope.isSpecialityOrderCompleted) {
                    $scope.isSpecialityOrderCompleted = true;
                    return;
                }*/


                
                });

            
        };
       /* $scope.hasAnySpecialOrderInItem = function() {
            $scope.isSpecialityOrderCompleted = true;
            var orderNumber = 0;
            angular.forEach($scope.rxItemsInOrder, function(Item, barcode) {
                var specialtyOrderNum = Item.basketItemInfo.specialtyOrderNum;
                if (specialtyOrderNum > 0) {
                    angular.forEach($scope.basketData, function(pprItem, patientID) {
                        angular.forEach(pprItem.patientFillInfoList, function(basketItem) {
                            if ($scope.isSpecialityOrderCompleted) {
                                if (basketItem.rxNum != Item.basketItemInfo.rxNum) {
                                    if (basketItem.specialtyOrderNum == Item.basketItemInfo.specialtyOrderNum && basketItem.fillDisposition.dispositionKey != 'SLD') {
                                        orderNumber = Item.basketItemInfo.specialtyOrderNum;
                                        $scope.isSpecialityOrderCompleted = false;
                                        return;
                                    }
                                }
                            }
                        });
                    });
                }

            });

            if (!$scope.isSpecialityOrderCompleted && orderNumber > 0) {
                var modalOptions = SPECIALTY_ORDER_MESSAGE['SPECIALTY_COMPLETE_ORDER_FAIL'];
                DialogService.showDialog({}, modalOptions).then(function(result) {
                    //Close window
                });
            }

        };*/

        $scope.hasUnScannedRxInBasket = function() {
            var noDispFlag = false;
            $scope.itemsInOrderCount = 0;
            angular.forEach($scope.basketData, function(pprItem, patientID) {
                angular.forEach(pprItem.patientFillInfoList, function(basketItem) {
                    // if (basketItem.itemStatus.fillConfigCode === 'SLD') {
                    //     basketItem.fillDisposition.disposition = 1;
                    //     basketItem.fillDisposition.dispositionKey = 'SLD';
                    // }
                    if (basketItem.rxNum && (!basketItem.fillDisposition.disposition && basketItem.itemStatus.fillConfigCode !== 'SLD' && basketItem.itemStatus.fillConfigCode !== 'REQ')) {
                        noDispFlag = true;
                    }
                    if (basketItem.rxNum && basketItem.fillDisposition.dispositionKey && basketItem.fillDisposition.dispositionKey == 'SLD') {
                        $scope.itemsInOrderCount++;
                    }
                });
            });
            // if (noDispFlag || ($scope.itemsInOrderCount == 0)) {
            //     return true;
            // } 
            if (noDispFlag) {
                return true;
            } else {
                return false;
            }
        };

        $scope.addRxItemToOrder = function(barcode) {

            var scanedBarcode = barcode;
            BasketFactory.setScanedBarcode(barcode);
            var rxItemInOrder = $scope.rxItemsInOrder[barcode];
            if (!rxItemInOrder) {
                var processRxScanPromise = MessageService.processRxScan(barcode, 'rxScan');
                processRxScanPromise && processRxScanPromise.then(
                    function(data) {
                        // RxScan 
                        var updatedFillInfo = data.fillInfo;
                        var patientId = data.patientId;
                        var partialBarcode = BasketService.buildPartialBarcode(updatedFillInfo);
                        var currentFillInfo = $scope.partialBarcodeRxInfoMap[partialBarcode];
                        angular.merge(currentFillInfo, updatedFillInfo);
                        //Disposition
                        currentFillInfo.fillDisposition.taxCollected = 0;
                        currentFillInfo.fillDisposition.scanInd = 'Y';
                        currentFillInfo.fillDisposition.userId = CONFIG.loggedInUser.id;
                        currentFillInfo.fillDisposition.lineVoidedLater = 'N'; //this is mandatory filed Y or N, value becomes Y when you do price modify
                        currentFillInfo.fillDisposition.fillLevel = 'N'; //Passing N for now
                        currentFillInfo.fillDisposition.locationOfRx = 'WB'; //Need various possible values
                        currentFillInfo.fillDisposition.voidedTransactionNumber = null; //
                        currentFillInfo.fillDisposition.priceSource = 'T'; //T-RxConnect, B-Bar Code, P-Price Modify, M-Manual Ring, N-Source Not Set (Used for line-void)                                                        
                        currentFillInfo.fillDisposition.barcode = scanedBarcode;
                        currentFillInfo.inOrder = true;
                        //New dispostion
                        currentFillInfo.fillDisposition.disposition = 1;
                        currentFillInfo.fillDisposition.dispositionKey = 'SLD';
                        rxItemInOrder = {
                            patientInfo: $scope.selectedPatientList[patientId],
                            basketItemInfo: currentFillInfo
                        };
                        $scope.rxItemsInOrder[barcode] = rxItemInOrder;
                        $scope.tempData.orderTotal += rxItemInOrder.basketItemInfo.patPayAmt;
                        //If item not moved to left uncomment below and delete this comment - PHANI
                        // $scope.basketData = BasketFactory.getBasketData();
                        $scope.updateSecDispPriceList();
                    },
                    function(data) {
                        // Reject will be invoked when hard stop actions like HWB/RTS is clicked - PHANI
                        if (data) {
                            // Update fill dispostion
                        }
                    }
                );
            }
        };

        var isRxItemInOrder = function(barcode) {
            return $scope.rxItemsInOrder[barcode];
        };

        $scope.doSelectPatient = function(data) {
            $scope.selectedPatient = data;
        };

        $scope.removePatient = function() {
            if ($scope.selectedPatient) {
                var modalOptions = {
                    buttons: ['Yes', 'No'],
                    headerText: 'Delete Patient?',
                    bodyText: 'Are you sure you want to delete this patient from order?'
                };

                DialogService.showDialog({}, modalOptions).then(function(result) {
                    if (result === 'Yes') {
                        $scope.removePatientFromBasket();
                    } else {
                        delete $scope.selectedPatient;
                    }
                });
            } else {
                var modalOptions = {
                    buttons: ['Okay'],
                    headerText: 'Select Patient',
                    bodyText: 'Please select Patient to Remove'
                };
                DialogService.showDialog({}, modalOptions).then(function(result) {

                });
            }
        };

        $scope.removePatientFromBasket = function() {
            angular.forEach($scope.rxItemsInOrder, function(item, barcode) {
                if (item.patientInfo.rxCPatientId == $scope.selectedPatient.rxCPatientId) {
                    delete $scope.rxItemsInOrder[barcode];
                }
            });
            PatientFactory.removeFromSelectedPatientList($scope.selectedPatient.rxCPatientId);
            BasketFactory.removePatientFromBasket($scope.selectedPatient.rxCPatientId);
            $scope.updateSecDispPriceList();
            delete $scope.basketData[$scope.selectedPatient.rxCPatientId];
            delete $scope.selectedPatientList[$scope.selectedPatient.rxCPatientId];
            delete $scope.selectedPatient;
            if (!Object.keys($scope.selectedPatientList).length) {
                $location.url('/patient-lookup')
            }

        };

        $scope.enterBarcode = function() {
            if ($scope.selectedPatientList) {
                NumberEntryService.showDialog({}, {
                    inputText: 'Enter Barcode',
                    headerText: 'Barcode'
                }).then(function(result) {
                    $scope.$broadcast('SCANNED_DATA_RX', result);
                });
            }
        };

        $scope.isRxNumberHasActionNote = function(basketItem) {
            var partialBarcode = $scope.buildPartialRxbarcode(basketItem);
            if ($scope.actionNoteForPatients[partialBarcode]) {
                return $scope.actionNoteForPatients[partialBarcode].isActionable;
            }
        };

         $scope.isActionNoteResolved = function(basketItem) {
            var partialBarcode = $scope.buildPartialRxbarcode(basketItem);
            if ($scope.actionNoteForPatients[partialBarcode]) {
                return $scope.actionNoteForPatients[partialBarcode].isActionCommunicated;
            }
        };

        $scope.isRxNumberHasTpComplianceMessage = function(basketItem) {
            var rxItem = '' + basketItem.rxNum + basketItem.refillNum + basketItem.partialFillSeqNum + basketItem.editVersionNum;
            if ($scope.tpMessagesForPatients[rxItem] && !$scope.tpMessagesForPatients[rxItem].tpMessage.markDisplayed) {
                return $scope.tpMessagesForPatients[rxItem].isTpComplinceMess;
            }
        };

        /*$scope.tpComplinceMessageActoion = function(patientInfo, basketItem, tpmessage) {
            var rxItem = '' + basketItem.rxNum + basketItem.refillNum + basketItem.partialFillSeqNum + basketItem.editVersionNum;
            //For testing 
            //tpmessage.tpComplianceMsg.formsProvided = 'SS';
            $modal.open({
                templateUrl: 'views/modals/medicare_form.html',
                keyboard: false,
                windowClass: 'modal-dialog-full',
                controller: 'BasketLevelMessages',
                backdrop: false,
                resolve: {
                    'data': function() {
                        return {
                            basketItemInfo: basketItem,
                            patientInfo: patientInfo,
                            messageDetails: tpmessage.tpComplianceMsg,
                            tpComplinceConfig: tpmessage.tpComplianceMsgConfig,
                            callback: $scope.resolveAllMessAlertsQueued
                        };
                    }
                }
            });
        };*/

       /* $scope.actionNoteEvent = function(patientInfo, basketItem) {
            var actionNotemessageConfig
            var rxItem = $scope.buildPartialRxbarcode(basketItem);
            if ($scope.actionNoteForPatients[rxItem]) {
                actionNotemessageConfig = $scope.actionNoteForPatients[rxItem];
            }
            $modal.open({
                templateUrl: 'views/modals/active-note.html',
                keyboard: false,
                windowClass: 'modal-dialog-full',
                controller: 'BasketLevelMessages',
                backdrop: false,
                resolve: {
                    'data': function() {
                        return {
                            basketItemInfo: basketItem,
                            patientInfo: patientInfo,
                            actionNoteConfig: actionNotemessageConfig,
                            callback: $scope.resolveAllMessAlertsQueued
                        };
                    }
                }

            });
        };*/

        $scope.showMedBMessage = function(data) {
            var templateUrl = "views/messages/basket/med-b/index.html";
            var modalOptions = {
                templateUrl: templateUrl,
                windowClass: 'modal-dialog-full',
                controller: 'MedBModalCtrl',
                resolve: {
                    'data': function() {
                        return data;
                    }
                }
            };
            var customOptions = {
                promise: true
            };
            var medBModalPromise = ModalService.showModal(modalOptions, customOptions);
            medBModalPromise.then(function(data) {
                $scope.resolveAllMessAlertsQueued(true);
            }, function(data) {});
        };
    });



angular.module('weCarePlusApp')
    .controller('PHRModalCtrl', function($scope, $modalInstance, $modal, $socket, data, CONFIG,
        PatientFactory, Request, BasketFactory, PrintService, OrderFactory, HipaaService) {
        $scope.data = data || {};
        $scope.extracarecard = OrderFactory.getEccNumber();;
        $scope.enrollmentType = null;
        $scope.isDriveThru = BasketFactory.isDriveThru();
        $scope.currentPatientItem = {};
        $scope.patEnrollBarcode = '19000000000' + ($scope.data && $scope.data.selectedPatient ? $scope.data.selectedPatient.rxCPatientId : '') + '0';

        $scope.enrollPatient = function(patientItem) {
            var opts = {
                patinetId: patientItem.rxCPatientId,
                patientName: patientItem.lastName + ', ' + patientItem.firstName,
                phrEnrollmentBarcode: '1900000000' + patientItem.rxCPatientId + '0'
            };
            if (patientItem.eccData && patientItem.eccData.xtracareCardNumber) {
                opts.extraCareCardNo = patientItem.eccData.xtracareCardNumber;
            }
            HipaaService.enroll(opts);
            // $modalInstance.dismiss();
        };

        $scope.dismiss = function(event) {
            event && event.preventDefault();
            data.isEccScanAllowed = true;
            $modalInstance.dismiss();
        };
    });

angular.module('weCarePlusApp')
    .controller('BasketRxItemModalCtrl', function($scope, $modalInstance, CONFIG, MessageService,MessageFactory,$q,BasketFactory) {
        $scope.rxScriptData=MessageFactory.getPatientMessageList()[0]; 
        $scope.basketData=BasketFactory.getBasketData();
        $scope.basketItemDetails=BasketFactory.getPatientProfileFillListItem($scope.rxScriptData.rxPatientId,$scope.rxScriptData.rxNum,$scope.rxScriptData.refillNum,$scope.rxScriptData.partialFillSeqNum,$scope.rxScriptData.editVersionNum);
        $scope.data = {

                            basketItemInfo:$scope.basketItemDetails ,
                            patientInfo: $scope.basketData[$scope.rxScriptData.rxPatientId].patientDetails,
                            rxItemsInOrder: $scope.rxItemsInOrder,
                            tempData: $scope.tempData,
                            //updateSecDispPriceList: $scope.updateSecDispPriceList,
                            //expediteServiceInvoke: $scope.expediteServiceInvoke,
                            //basketScenario: $scope.rxScriptData.messageConfig
                            //BasketFactory.getCurrentBasketScenario($scope.basketItemDetails.itemStatus.fillConfigCode, $scope.basketItemDetails.fillDisposition.disposition)
        };
        $scope.CONFIG = CONFIG;

        $scope.doAction = function(idVal) {
            if ($scope.data.basketItemInfo.itemStatus && $scope.data.basketItemInfo.itemStatus.fillConfigCode && $scope.data.basketItemInfo.itemStatus.fillConfigCode === 'SLD') {
                $modalInstance.close();
                return;
            }
            var disposition = BASKET_SCENARIO.ACTION_STATUS[idVal];
            var dispositionKey = BASKET_SCENARIO.STATUS_KEY[disposition];
            if (dispositionKey) {
                //New disposition
                $scope.data.basketItemInfo.fillDisposition.disposition = disposition;
                $scope.data.basketItemInfo.fillDisposition.dispositionKey = dispositionKey;
                $scope.data.basketItemInfo.fillDisposition.scanInd = 'Y';
                //Disposition
                $scope.data.basketItemInfo.fillDisposition.taxCollected = 0;
                $scope.data.basketItemInfo.fillDisposition.userId = CONFIG.loggedInUser.id;
                $scope.data.basketItemInfo.fillDisposition.lineVoidedLater = 'N'; //this is mandatory filed Y or N, value becomes Y when you do price modify
                $scope.data.basketItemInfo.fillDisposition.fillLevel = 'N'; //Passing N for now
                $scope.data.basketItemInfo.fillDisposition.locationOfRx = 'WB'; //Need various possible values
                $scope.data.basketItemInfo.fillDisposition.voidedTransactionNumber = null; //
                $scope.data.basketItemInfo.fillDisposition.priceSource = 'T'; //T-RxConnect, B-Bar Code, P-Price Modify, M-Manual Ring, N-Source Not Set (Used for line-void)                                                        

                if (dispositionKey === BASKET_SCENARIO.STATUS_KEY["2"]) {

                    ExpidateService.expidateScript(data.basketItemInfo);
                }
                if ($scope.data.basketItemInfo.inOrder) {
                    $scope.data.basketItemInfo.inOrder = false;
                    delete $scope.data.rxItemsInOrder[$scope.data.basketItemInfo.fillDisposition.barcode];
                    $scope.data.tempData.orderTotal -= data.basketItemInfo.patPayAmt;
                    $scope.data.updateSecDispPriceList();
                    MessageService.removeRxItemFromQueue($scope.data.basketItemInfo.fillDisposition.barcode);
                    //Logic comes here phani

                    return null;
                }
            }
            $modalInstance.close();
        };

        $scope.dismiss = function() {
            $modalInstance.dismiss();
        };
    });

//Rx and Patient Level Messages controller
angular.module('weCarePlusApp')
    .controller('BasketLevelMessages', function($scope, $modalInstance, $modal, data, CONFIG, BasketFactory) {
        $scope.data = data;
        $scope.CONFIG = CONFIG;
        $scope.messageType = null;
        $scope.tpComplianceMsgOk = false;
        $scope.continueActive = false;
        $scope.sigNotSignSelected = false;
        $scope.sigNotSignSelectedAction;
        $scope.relationshipToPatient;

        $scope.isMedicareFormContinueActive = function() {
            if (($scope.data.messageDetails.formsProvided && $scope.data.messageDetails.formsProvided != 'NIL') && $scope.data.messageDetails.formsSigned.formType[0] != 'NIL') {
                if ($scope.sigNotSignSelected && $scope.tpComplianceMsgOk) {
                    $scope.continueActive = true;
                    return true;
                } else {
                    return false;
                }
            } else if ($scope.data.messageDetails.formsProvided && $scope.data.messageDetails.formsProvided != 'NIL') {
                if ($scope.tpComplianceMsgOk) {
                    $scope.continueActive = true;
                    return true;
                } else {
                    return false;
                }
            } else if ($scope.data.messageDetails.formsSigned.formType[0] != 'NIL') {
                if ($scope.sigNotSignSelected) {
                    $scope.continueActive = true;
                    return true;
                } else {
                    return false;
                }
            }
        };

       /* $scope.doAction = function(basketItemInfo, idVal) {

            var disposition = BASKET_SCENARIO.ACTION_STATUS[idVal];
            var dispositionKey = BASKET_SCENARIO.STATUS_KEY[disposition];

            if (dispositionKey) {
                //New disposition
                basketItemInfo.fillDisposition.disposition = disposition;
                basketItemInfo.fillDisposition.dispositionKey = dispositionKey;
                basketItemInfo.fillDisposition.scanInd = 'Y';
                //Disposition
                basketItemInfo.fillDisposition.taxCollected = 0;
                basketItemInfo.fillDisposition.userId = CONFIG.loggedInUser.id;
                basketItemInfo.fillDisposition.lineVoidedLater = 'N'; //this is mandatory filed Y or N, value becomes Y when you do price modify
                basketItemInfo.fillDisposition.fillLevel = 'N'; //Passing N for now
                basketItemInfo.fillDisposition.locationOfRx = 'WB'; //Need various possible values
                basketItemInfo.fillDisposition.voidedTransactionNumber = null; //
                basketItemInfo.fillDisposition.priceSource = 'T'; //T-RxConnect, B-Bar Code, P-Price Modify, M-Manual Ring, N-Source Not Set (Used for line-void)                                                        

            }
            BasketFactory.updateBasketMsgDisp(data.patientInfo.rxCPatientId, 'eanMsg', data.basketItemInfo.rxNum);
            data.actionNoteConfig.isActionable = false;
            data.actionNoteConfig.isActionCommunicated = true;
            data && data.callback && data.callback(true);
            $modalInstance.dismiss();
        };
*/
        $scope.doTpComplianceAction = function() {
            $scope.tpComplianceMsgOk = true;
            BasketFactory.setTpComplianceMessageFormSigned('SS');
        };
        $scope.doPatientRelationShipAction = function(relKey, relVal) {
            $scope.relationshipToPatient = relKey;
        };

        $scope.doSignedAction = function(formType, actionId) {
            $scope.sigNotSignSelected = true;
            $scope.sigNotSignSelectedAction = actionId;
            if (actionId && parseInt(actionId) == 6) {
                BasketFactory.setTpComplianceMessageFormSigned(formType);
            }
        };
        $scope.dismiss = function() {
            $modalInstance.dismiss();
        };

        $scope.continueAction = function(messageData, patientInfo, basketItemInfo) {
            if (messageData.rltnToBenfcryReq == 'Y') {
                if ($scope.relationshipToPatient && parseInt($scope.relationshipToPatient) > 0) {
                    BasketFactory.updateBasketMsgDisp(patientInfo.rxCPatientId, 'tpComplianceMsg', basketItemInfo.rxNum);
                    messageData.disposition = 1;
                    messageData.markDisplayed = true;
                    $modalInstance.dismiss();
                }
            } else {
                BasketFactory.updateBasketMsgDisp(patientInfo.rxCPatientId, 'tpComplianceMsg', basketItemInfo.rxNum);
                messageData.disposition = 1;
                messageData.markDisplayed = true;
                $modalInstance.dismiss();
            }
            data && data.callback && data.callback(true);
        };

        $scope.setMessageStatus = function(messageData) {
            if (!$scope.continueActive) {
                return;
            }
            if ($scope.data.messageDetails.rltnToBenfcryReq == 'Y') {
                $modalInstance.dismiss();
                $modal.open({
                    templateUrl: 'views/modals/relationship_to_patient.html',
                    keyboard: false,
                    windowClass: 'counseling-popup',
                    controller: 'BasketLevelMessages',
                    backdrop: false,
                    resolve: {
                        'data': function() {
                            return {
                                basketItemInfo: $scope.data.basketItemInfo,
                                patientInfo: $scope.data.patientInfo,
                                messageData: messageData,
                                callback: data.callback
                            };
                        }
                    }
                });
            } else {
                $scope.continueAction(messageData, data.patientInfo, data.basketItemInfo);
            }
        };
    });

angular.module('weCarePlusApp')
    .controller('BasketLevelTwoMsgPopupCtrl', function($scope, $modalInstance, BasketFactory, MessageFactory) {
        $scope.patientMessage = MessageFactory.getPatientMessage();

        $scope.doAction = function() {
            BasketFactory.setBasketPageMsgAlert(false);
            BasketFactory.updateMsgDisp($scope.patientMessage, 'msgCentrMsg', {
                progType: $scope.patientMessage.progType
            });
            $modalInstance.dismiss();
            MessageFactory.getNextMessage();
        };
    });
