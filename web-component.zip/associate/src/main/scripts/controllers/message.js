'use strict';

angular.module('weCarePlusApp')
    .controller('MessageCtrl', function($scope, MessageFactory, MessageService, BasketFactory, BasketService) {
        $scope.patientMessageList = MessageFactory.getPatientMessageList();
        $scope.patientMessageConfig = $scope.patientMessageList[0].messageConfig && $scope.patientMessageList[0].messageConfig.configInfo['1'];
        $scope.screenButtonConfig = $scope.patientMessageList[0].messageConfig && $scope.patientMessageList[0].messageConfig.scrButton;
        $scope.basketData = BasketFactory.getBasketData();
        
        $scope.displayNextMessage = function() {
            BasketService.updatePatientMessageDispostion($scope.patientMessageList);
            MessageService.displayMessage();
        };
    });