'use strict';

angular.module('weCarePlusApp')
    .controller('PunchCtrl', ['$scope', "PunchFactory", "DialogService", "$location", "$route",
        function($scope, PunchFactory, DialogService, $location, $route) {
            var EMPLOYEE_ID_STRING = "Enter Employee ID Number";
            var EMPLOYEE_PWD_STRING = "Enter Employee Password";
            var MANAGER_ID_STRING = "Enter Manager ID";
            var MANAGER_PWD_STRING = "Enter Manager Password";

            $scope.labelName = EMPLOYEE_ID_STRING;
            $scope.inputValue = "";
            $scope.inputType = "text";
            $scope.enterKeyActive = false;

            var employeedIDCounter = 0;
            $scope.onPunchScreenClick = function(keyType, keyVal) {
                var tempValue = $scope[$scope.currentFocus.model];
                if (keyType === 'normKey') {
                    tempValue = tempValue ? (tempValue + keyVal) : keyVal;
                    if ($scope.labelName == MANAGER_PWD_STRING || $scope.labelName == EMPLOYEE_PWD_STRING) {
                        if (tempValue.length > 4) {
                            $scope.enterKeyActive = true;
                            return;
                        }
                    }
                } else if (keyType === 'splKey') {
                    switch (keyVal) {
                        case 'clear':
                            tempValue = '';
                            break;
                        case 'back':
                            tempValue = tempValue ? (tempValue.length > 0 ? tempValue.substr(0, tempValue.length - 1) : '') : null;
                            break;
                        case 'cancel':
                            var modalOptions = {
                                buttons: ['Yes', 'No'],
                                headerText: 'Warning',
                                bodyText: 'Are you sure you want to CANCEL the operation?'
                            };
                            if ($scope.labelName == EMPLOYEE_PWD_STRING || $scope.labelName == MANAGER_PWD_STRING) {
                                DialogService.showDialog({}, modalOptions).then(function(result) {
                                    if (result == "Yes") {
                                        $route.reload();
                                    }
                                });

                            } else {
                                DialogService.showDialog({}, modalOptions).then(function(result) {
                                    if (result == "Yes") {
                                        $location.url('/' + $scope.sourceRoute);
                                    }
                                });

                            }
                            break;
                        case 'enter':
                            if (!$scope.enterKeyActive) {
                                return;
                            }
                            if (tempValue) {
                                if ($scope.labelName == MANAGER_PWD_STRING || $scope.labelName == EMPLOYEE_PWD_STRING) {
                                    if (tempValue.length < 4) {
                                        $scope.enterKeyActive = false;
                                        return;
                                    }
                                }
                                $scope.punchScreenValidation();
                            } else {
                                return;
                            }
                            return;
                            break;
                        default:
                            break;
                    }
                } else {
                    appUtils.log("Invalid type of key pressed.");
                }
                $scope[$scope.currentFocus.model] = tempValue;
                $scope.enterKeyActive = tempValue.length >= 3;
                // $scope.currentFocus.el.target.focus();

            }

            $scope.punchScreenValidation = function() {
                $scope.enterKeyActive = false;
                switch ($scope.labelName) {
                    case EMPLOYEE_ID_STRING:
                        PunchFactory.setEmployeeId($scope.inputValue);
                        $scope.labelName = EMPLOYEE_PWD_STRING;
                        $scope.inputValue = "";
                        $scope.inputType = "password";
                        break;
                    case MANAGER_ID_STRING:
                        PunchFactory.setEmployeeId($scope.inputValue);
                        $scope.labelName = MANAGER_PWD_STRING;
                        $scope.inputValue = "";
                        $scope.inputType = "password";
                        break;
                    case EMPLOYEE_PWD_STRING:
                    case MANAGER_PWD_STRING:
                        if (!$scope.inputValue) {
                            return;
                        }
                        if ($scope.labelName == MANAGER_PWD_STRING) {
                            //set manager flag to true
                            PunchFactory.setManagerFlag(1);
                        }
                        var employeePwd = $scope.inputValue;
                        $scope.inputValue = "";
                        var authEmployeePromise = PunchFactory.authenticateEmployee(employeePwd);
                        authEmployeePromise.then(function(successData) {
                                if (successData.roles !== "P" && $scope.labelName == MANAGER_PWD_STRING) {
                                    var modalOptions = {
                                        buttons: ['Retry', 'Cancel'],
                                        headerText: '',
                                        bodyText: 'Invalid Manager Login'
                                    };
                                    DialogService.showDialog({}, modalOptions).then(function(type) {
                                        if (type == "Retry") {
                                            $scope.labelName = MANAGER_ID_STRING;
                                            $scope.inputType = "text";
                                        } else {
                                            $location.url('/' + $scope.sourceRoute);
                                        }

                                    });
                                    return;
                                }
                                var modalOptions = {
                                    buttons: ['In', 'Out', 'Cancel'],
                                    headerText: '',
                                    bodyText: 'Enter Punch Type'
                                };
                                DialogService.showDialog({}, modalOptions).then(function(type) {
                                    if (type == "Cancel") {
                                        $location.url("/" + $scope.sourceRoute);
                                        return;
                                    }
                                    var punchPromise = PunchFactory.punchEmployee(type);
                                    punchPromise.then(function(successData) {
                                        PunchFactory.setManagerFlag(0);
                                        var modalOptions = {
                                            buttons: ['OK'],
                                            headerText: 'Success',
                                            bodyText: 'Punch was successfully completed'
                                        };
                                        DialogService.showDialog({}, modalOptions).then(function(type) {
                                            $location.url("/" + $scope.sourceRoute);
                                            return;
                                        });
                                    }, function(errorData) {
                                        console.log(errorData);
                                        var modalOptions = {
                                            buttons: ['OK'],
                                            headerText: '',
                                            bodyText: 'Employee is already Punched ' + type
                                        };
                                        DialogService.showDialog({}, modalOptions).then(function(type) {

                                        });
                                        PunchFactory.setManagerFlag(0);
                                    });
                                });

                                /* else {

                                     PunchFactory.setManagerFlag(0);

                                     employeedIDCounter++;

                                     //increment count and check for count
                                     //if count >= 2, show manage screen otherwise go back to employee id screen
                                     if (employeedIDCounter >= 2) {
                                         employeedIDCounter = 0;
                                         //show manage override screen
                                         var modalOptions = {
                                             buttons: ['Manager override', 'Cancel'],
                                             headerText: '',
                                             bodyText: 'Punch was not completed successfully <br> EMPLOYEE IS NOT ON FILE'
                                         };
                                         DialogService.showDialog({}, modalOptions).then(function(type) {
                                             if (type == "Manager override") {
                                                 $scope.labelName = MANAGER_ID_STRING;
                                                 $scope.inputType = "text";
                                             } else if (type == "Cancel") {
                                                 $location.url("/home");
                                             }

                                         });

                                     } else {
                                         //go back to employee id screen
                                         $scope.labelName = EMPLOYEE_ID_STRING;
                                         $scope.inputType = "text";
                                     }
                                 }*/

                            },
                            function(errorData) {
                                PunchFactory.setManagerFlag(0);
                                //validation fail
                                employeedIDCounter++;

                                //increment count and check for count
                                //if count >= 2, show manage screen otherwise go back to employee id screen
                                if (employeedIDCounter >= 2) {
                                    employeedIDCounter = 0;
                                    //show manage override screen
                                    var modalOptions = {
                                        buttons: ['Manager<br/>Override', 'Cancel'],
                                        headerText: '',
                                        bodyText: errorData.moreInfo || ('Punch was not completed successfully <br> EMPLOYEE IS NOT ON FILE')
                                    };
                                    DialogService.showDialog({}, modalOptions).then(function(type) {

                                        if (type == "Manager<br/>Override") {
                                            $scope.labelName = MANAGER_ID_STRING;
                                            $scope.inputType = "text";
                                        } else if (type == "Cancel") {
                                            $location.url("/" + $scope.sourceRoute);
                                        }
                                    });

                                } else {
                                    var modalOptions = {
                                        buttons: ['OK'],
                                        headerText: 'Error',
                                        bodyText: errorData.moreInfo || ('Punch was not completed successfully <br> EMPLOYEE IS NOT ON FILE')
                                    };
                                    DialogService.showDialog({}, modalOptions).then(function(type) {
                                        //go back to employee id screen
                                        $scope.labelName = EMPLOYEE_ID_STRING;
                                        $scope.inputType = "text";
                                    });
                                }
                            });
                        break;
                }

            }
        }
    ]);
