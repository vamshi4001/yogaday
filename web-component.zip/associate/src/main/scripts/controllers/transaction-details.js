'use strict';

angular.module('weCarePlusApp')
    .controller('TxnDetailCtrl', function($scope, $location, OrderFactory, MessageFactory, Request, BasketFactory, MessageService) {
        $scope.CONFIG.pageTitle = "Transaction Details";
        $scope.transactionDetails=OrderFactory.getTransactionDetails() || {};
        $scope.listOfControledItems=$scope.transactionDetails.controlledDrugList;
        $scope.totalRxitemCost =$scope.transactionDetails.totalAmount;
        $scope.isEccInOrder = OrderFactory.getEccNumber();
        
        $scope.inStore = function() {
            MessageService.compileMessage('inStore');
            return;
        };

        $scope.goToBasket = function(event) {
            event && event.preventDefault();
            $location.url('/basket');
        };
        $scope.previous = function(){
            $location.url('/basket');
        }
    });
