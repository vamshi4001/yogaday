'use strict';

angular.module('weCarePlusApp')
    .controller('SmsMsgCtrl', function($scope, $location, $modal, DialogService, $socket, ModalService) {
        $scope.CONFIG.pageTitle = $scope.patientMessageConfig.dispTitle;
        $scope.dispositionMap = {};
        $scope.continueActive = false;
        $scope.unEnrolledLength = 0;
        $scope.basketDataInfo = angular.copy($scope.basketData);

        $scope.doActionLineBtn = function(patientMessageItem, actionId) {
            var patientProfile = $scope.basketDataInfo[patientMessageItem.rxPatientId];
            if (actionId === 6) {
                if (patientProfile.patientDetails.patientCntctInfo.phone.mobile) {
                    var modalOptions = {
                        buttons: [],
                        headerText: 'Customer Terminal Processing',
                        bodyText: 'WAITING FOR CUSTOMER RESPONSE',
                        blockUI: true
                    };
                    DialogService.showDialog({}, modalOptions);
                    $socket.send(JSON.stringify({
                        type: 'DISPLAY_QUESTION',
                        options: {
                            route: 'smsEnrollConfirm',
                            payload: {
                                mobile: patientProfile.patientDetails.patientCntctInfo.phone.mobile
                            }
                        }
                    }), true).then(function(response) {
                        if (response.options.accepted) {
                            $scope.dispositionMap[patientMessageItem.rxPatientId] = actionId;
                            patientMessageItem.mobilePhone=patientProfile.patientDetails.patientCntctInfo.phone.mobile;
                            patientMessageItem.outcome=actionId;
                        } else {
                            
                            var modalOptions = {
                                templateUrl: 'views/modals/contact-update.html',
                                keyboard: false,
                                backdrop: false,
                                windowClass: 'over-containerwidth',
                                controller: 'ContactUpdateModalCtrl',
                                resolve: {
                                    'data': function() {
                                        return {
                                            patientId: patientMessageItem.rxPatientId,
                                            phoneNumber: patientProfile.patientDetails.patientCntctInfo.phone.mobile,
                                            parent: 'SMS'
                                        };
                                    }
                                }
                            };

                            var customOptions = {
                                promise: true
                            };

                            ModalService.showModal(modalOptions, customOptions).then(function(result) {
                                $scope.dispositionMap[patientMessageItem.rxPatientId] = actionId;
                                patientMessageItem.outcome = actionId;
                                patientMessageItem.mobilePhone = result;
                                patientProfile.patientDetails.patientCntctInfo.phone.mobile = result;
                            });

                        }
                        DialogService.closeDialog();
                    });
                } else {
                    var modalOptions = {
                        templateUrl: 'views/modals/contact-update.html',
                        keyboard: false,
                        backdrop: false,
                        windowClass: 'over-containerwidth',
                        controller: 'ContactUpdateModalCtrl',
                        resolve: {
                            'data': function() {
                                return {
                                    patientId: patientMessageItem.rxPatientId,
                                    phoneNumber: patientProfile.patientDetails.patientCntctInfo.phone.mobile,
                                    parent: 'SMS'
                                };
                            }
                        }
                    };

                    var customOptions = {
                        promise: true
                    };

                    ModalService.showModal(modalOptions, customOptions).then(function(result) {
                        $scope.dispositionMap[patientMessageItem.rxPatientId] = actionId;
                        patientMessageItem.outcome = actionId;
                        patientMessageItem.mobilePhone = result;
                        patientProfile.patientDetails.patientCntctInfo.phone.mobile = result;
                    });

                }
            } else {
                $scope.dispositionMap[patientMessageItem.rxPatientId] = actionId;
                patientMessageItem.outcome = actionId;
                //Needed if user enrolled for sms but changed his mind to unenroll
                patientMessageItem.mobilePhone = null;
            }
        };

        $scope.isContinueActive = function() {
            if (Object.keys($scope.dispositionMap).length == $scope.patientMessageList.length) {
                $scope.continueActive = true;
                return true;
            } else {
                $scope.continueActive = false;
                return false;
            }
        };

        $scope.nextMessage = function() {
            if ($scope.continueActive) {
               $scope.displayNextMessage();
            }
        };
    });
