'use strict';

angular.module('weCarePlusApp')
    .controller('SpecialityCtrl', function($scope, $modalInstance, MessageFactory, deferred) {
        $scope.patientMessageList = MessageFactory.getMasterMessageList()[0][0];
         // $scope.basketItemInfo=  BasketFactory.getPatientProfileFillListItem($scope.patientMessageList.rxPatientId,$scope.patientMessageList.rxNum,basketItem.refillNum,basketItem.partialFillSeqNum,basketItem.editVersionNum);
        $scope.doAction = function() {
        	$modalInstance.dismiss();
            deferred.resolve();
        }
    });