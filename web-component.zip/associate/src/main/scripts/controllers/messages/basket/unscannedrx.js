'use strict';
//UnScanned Rx Modual Controller 
angular.module('weCarePlusApp')
    .controller('UnScannedRxModalCtrl', function($scope, $modalInstance, CONFIG,deferred,BasketFactory,PatientFactory,MessageFactory,ExpidateService) {

        $scope.data = {
                    basketData:  MessageFactory.getPatientMessageList(),
                    selectedPatientList: PatientFactory.getSelectedPatientList(),
                    expediteServiceInvoke: $scope.expediteServiceInvoke,
                };
        $scope.CONFIG = CONFIG;
        $scope.continueKeyActive = false;
        $scope.noActionCount = 0;
        $scope.actionCount = 0;
        $scope.basketScenarioMap = {};
        $scope.BASKET_SCENARIO = BASKET_SCENARIO;
        $scope.basketData=BasketFactory.getBasketData();

        $scope.isDispositionEqualsButton = function(buttonId, item) {
            console.log("button id - " + buttonId);
            console.log("basket item disposition", item.fillDisposition.disposition);
            return BASKET_SCENARIO.ACTION_STATUS[buttonId] == item.fillDisposition.disposition;
        }

        $scope.doAction = function(basketItem, idVal) {
            $scope.actionCount += 1;
            var disposition = BASKET_SCENARIO.ACTION_STATUS[idVal];
            var dispositionKey = BASKET_SCENARIO.STATUS_KEY[disposition];
            $scope.basketItemInfo=  BasketFactory.getPatientProfileFillListItem(basketItem.patientID,basketItem.rxNum,basketItem.refillNum,basketItem.partialFillSeqNum,basketItem.editVersionNum);
            
            basketItem.fillDisposition.disposition = disposition;

            if (dispositionKey === BASKET_SCENARIO.STATUS_KEY["2"]) {
                ExpidateService.expidateScript( $scope.basketItemInfo);
            }
            if (dispositionKey) {
                //New disposition
                $scope.basketItemInfo.fillDisposition.dispositionKey = dispositionKey;
                $scope.basketItemInfo.fillDisposition.scanInd = 'Y';
                //Disposition
                $scope.basketItemInfo.fillDisposition.taxCollected = 0;
                $scope.basketItemInfo.fillDisposition.userId = CONFIG.loggedInUser.id;
                $scope.basketItemInfo.fillDisposition.lineVoidedLater = 'N'; //this is mandatory filed Y or N, value becomes Y when you do price modify
                $scope.basketItemInfo.fillDisposition.fillLevel = 'N'; //Passing N for now
                $scope.basketItemInfo.fillDisposition.locationOfRx = 'WB'; //Need various possible values
                $scope.basketItemInfo.fillDisposition.voidedTransactionNumber = null; //
                $scope.basketItemInfo.fillDisposition.priceSource = 'T'; //T-RxConnect, B-Bar Code, P-Price Modify, M-Manual Ring, N-Source Not Set (Used for line-void)                                                        
            }
            ($scope.noActionCount === $scope.actionCount) && ($scope.continueKeyActive = true) && ($scope.data.continueKeyActive =
                true);
            basketItem.markDisplayed = true;
            console.log(basketItem);
        };

        $scope.isPatientHaseUnscand=function(patientID,basketItems){
              angular.forEach(basketItems, function(basketItem) {
                        if(basketItem.rxPatientId === patientID){
                            return true;
                        }else{
                            return false;
                        }
                    });
            
        };

        $scope.dismiss = function() {
            //data.scope.hasUnScannedRxItems = false;
            $modalInstance.dismiss();
             deferred.resolve(MessageFactory.getPatientMessageList());
        };

       /* $scope.getCurrentBasketScenario = function(basketItem) {
            $scope.basketScenarioMap[basketItem.rxNum] = BasketFactory.getCurrentBasketScenario(basketItem.itemStatus.fillConfigCode, basketItem.fillDisposition.disposition);
            basketItem.itemStatus.unScannedRxStatus = false;
        };*/

        $scope.incNoActionCount = function() {
            $scope.noActionCount += 1;
        };

        $scope.noDispositionStatus = function(basketItem) {
            if (basketItem.rxNum) {
                if (basketItem.itemStatus.unScannedRxStatus) {
                    return true;
                } else if (!(basketItem.inOrder || basketItem.itemStatus.current)) {
                    return true;
                }
            }
        };
    });
