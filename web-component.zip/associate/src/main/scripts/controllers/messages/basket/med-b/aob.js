angular.module('weCarePlusApp')
    .controller('AOBModalCtrl', function($scope, DialogService, $socket, CONFIG) {
        $scope.inProgress = false;

        $scope.doScanAOB = function(section) {
            $scope.dispositionMap[$scope.messageConfig.progSubType].enableScan = section;
            $scope.dispositionMap[$scope.messageConfig.progSubType][section] = $scope.dispositionMap[$scope.messageConfig.progSubType][section] || {};
        };
    });