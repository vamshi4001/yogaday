angular.module('weCarePlusApp')
    .controller('IPledgeMessageModalCtrl', function($scope, $modalInstance, MessageFactory, deferred) {
        $scope.patientMessageList = MessageFactory.getPatientMessageList();
        $scope.iPledgeMessage = $scope.patientMessageList[0];
        
        $scope.doAction = function() {
            $modalInstance.dismiss();
            deferred.resolve($scope.patientMessageList);
        }
    });
