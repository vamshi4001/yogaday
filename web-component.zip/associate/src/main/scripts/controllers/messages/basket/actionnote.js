'use strict';

angular.module('weCarePlusApp')
    .controller('ActionNoteMessagesCtrl', function(BasketService, $scope, $modalInstance, MessageFactory, deferred,BasketFactory,PatientFactory,CONFIG) {
         // For doing UI logic Show and hide button       
         $scope.actionNoteForPatients = PatientFactory.getActionNoteDetails();
                                        
         $scope.actionNoteConfig = MessageFactory.getPatientMessageList()[0];
         $scope.basketData=BasketFactory.getBasketData();
       	 $scope.patientDetails = $scope.basketData[$scope.actionNoteConfig.rxPatientId].patientDetails;
       	 $scope.basketItemInfo=  BasketFactory.getPatientProfileFillListItem($scope.actionNoteConfig.rxPatientId,$scope.actionNoteConfig.rxNum,$scope.actionNoteConfig.refillNum,$scope.actionNoteConfig.partialFillSeqNum,$scope.actionNoteConfig.editVersionNum);

       $scope.doAction = function(basketItemInfo, idVal,$rootScope) {
            var disposition = BASKET_SCENARIO.ACTION_STATUS[idVal];
            var dispositionKey = BASKET_SCENARIO.STATUS_KEY[disposition];

            if (dispositionKey) {
                //New disposition
                if(disposition!=1){
                $scope.basketItemInfo.fillDisposition.disposition = disposition;
                $scope.basketItemInfo.fillDisposition.dispositionKey = dispositionKey;
                }
                $scope.basketItemInfo.fillDisposition.scanInd  = 'Y';
                $scope.actionNoteConfig.commInd='Y';
                //Disposition
                $scope.basketItemInfo.fillDisposition.taxCollected = 0;
                $scope.basketItemInfo.fillDisposition.userId = CONFIG.loggedInUser.id;
                $scope.basketItemInfo.fillDisposition.lineVoidedLater = 'N'; //this is mandatory filed Y or N, value becomes Y when you do price modify
                $scope.basketItemInfo.fillDisposition.fillLevel = 'N'; //Passing N for now
                $scope.basketItemInfo.fillDisposition.locationOfRx = 'WB'; //Need various possible values
                $scope.basketItemInfo.fillDisposition.voidedTransactionNumber = null; //
                $scope.basketItemInfo.fillDisposition.priceSource = 'T'; //T-RxConnect, B-Bar Code, P-Price Modify, M-Manual Ring, N-Source Not Set (Used for line-void)                                                        
                $scope.basketItemInfo.itemStatus.actionable='N';
            }
            BasketFactory.updateBasketMsgDisp($scope.actionNoteConfig.rxPatientId, 'eanMsg', basketItemInfo.rxNum);

            var partialBarcode = $scope.buildPartialRxbarcode($scope.basketItemInfo);
            $scope.actionNoteForPatients[partialBarcode].isActionable = false;
            $scope.actionNoteForPatients[partialBarcode].isActionCommunicated = true;
         
            $modalInstance.dismiss();
            // Reject will be invoked when hard stop actions like HWB/RTS is clicked 
            if(disposition==3 || disposition==4){
                deferred.reject();
            }else{
                deferred.resolve($scope.actionNoteConfig);
        }
        };

            $scope.buildPartialRxbarcode = function(rxInfo) {
                var rxnum = appUtils.prepandZeros(rxInfo.rxNum, 7);
                var reFillNum = appUtils.prepandZeros((rxInfo.refillNum || 0), 3);
                var editVerNum = appUtils.prepandZeros((rxInfo.editVersionNum || 0), 3);
                var parFillSeqNum = appUtils.prepandZeros((rxInfo.partialFillSeqNum || 0), 2);
                return (rxnum + reFillNum + editVerNum + parFillSeqNum);
            };
      
    });
