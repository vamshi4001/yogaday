angular.module('weCarePlusApp')
    .controller('ImmunizationCtrl', function($scope, $modalInstance, MessageFactory, BasketFactory, deferred,PatientFactory) {
        $scope.patientMessageList = MessageFactory.getMasterMessageList()[0][0];
        $scope.basketData=BasketFactory.getBasketData();

        $scope.doAction = function() {

        	$scope.patientMessageList.markDisplayed=true;
        	
        	angular.forEach($scope.patientMessageList.rxMsgInfoList, function(rxItem) {
        		BasketFactory.updatePatientProfileImmunizationFlag (rxItem.patientID,rxItem.rxNumber,rxItem.rxFillNumber,PatientFactory.getSelectedPatientList()/*,rxItem.*/);
        	});

        	$modalInstance.dismiss();
            deferred.resolve();
        }
    });