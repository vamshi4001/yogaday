/*

    Will be used in combination with ProgType
    Below are ABN specific domain values(ProgType=10)
        1-ABN Required 
        2–ABN Selection Confirm
        3-ABN Option 
        4-ABN Option Mismatch 1
        5-ABN Option Mismatch 2
        6-ABN Option Mismatch 3 
        7-ABN Refusal to sign Unassigned
        8-ABN Refusal to sign Assigned
        9-ABN Refusal to sign Assigned items
        10-ABN Enter Employee Number
        11-ABN Signature / Date
        12-Return ABN to Patient / Representative
          
    Below are AOB specific domain values(ProgType=11)
        1-AOB Required Patient
        2-AOB Required Representative
        3-AOB Signature/Date
        4-AOB Patient Refusal to sign
        5-AOB Representative Refuse to sign - Max Days
        6-AOB Representative Refuse to sign - Threshold
        7-Return AOB to Patient / Representative
*/
angular.module('weCarePlusApp')
    .controller('MedBModalCtrl', function($scope, $modalInstance, CONFIG, data, BasketFactory, $state, deferred, DialogService) {
        $scope.data = data
        $scope.deferred = deferred;
        $scope.CONFIG = CONFIG;
        $scope.messageKey = $scope.data.messageData.messageKey;
        $scope.messageType = $scope.messageKey === "5-10" ? "AOB" : "ABN";
        $scope.commonData = {
            continueActive: false
        };
        var patientPresentMap = BasketFactory.getPatientPresentMap();
        var basketData = BasketFactory.getBasketData();
        $scope.dispositionMap = {};
        $scope.prevProgSubType = null;
        $scope.nextProgSubType = null;
        $scope.masterData = {
            "5-10": {
                verifyScanData: {
                    sectionI: {
                        header: 'Verify Customer Signature',
                        imageType: 'SIGNATURE'
                    },
                    sectionJ: {
                        header: 'Verify Date',
                        imageType: 'DATE'
                    }
                },
                continueActiveThreshold: {
                    // CONFIG.PROG_SUB_TYPE.AOB.AOB_SIGN_DATE
                    3: 2
                },
                rxDispostion: {
                    // CONFIG.PROG_SUB_TYPE.AOB.AOB_REFUSE
                    4: {
                        "21": "4",
                        "22": "3"
                    },
                    // CONFIG.PROG_SUB_TYPE.AOB.AOB_REFUSE_MAXDAYS
                    5: {
                        "21": "4",
                        "22": "3"
                    },
                    // CONFIG.PROG_SUB_TYPE.AOB.AOB_REFUSE_THRESHOLD
                    6: {
                        "21": "1"
                    },
                    // CONFIG.PROG_SUB_TYPE.AOB.AOB_RETURN
                    7: {
                        "20": "1"
                    }
                },
                screenButtonMap: {
                    // CONFIG.PROG_SUB_TYPE.AOB.AOB_REQUIRED_PT
                    1: {
                        "REFUSE": 23,
                        "CONTINUE": 11
                    },
                    // CONFIG.PROG_SUB_TYPE.AOB.AOB_REQUIRED_REP
                    2: {
                        "REFUSE": 23,
                        "CONTINUE": 11
                    },
                    // CONFIG.PROG_SUB_TYPE.AOB.AOB_SIGN_DATE
                    3: {
                        "REFUSE": 23,
                        "CONTINUE": 11
                    },
                    // CONFIG.PROG_SUB_TYPE.AOB.AOB_REFUSE
                    4: {
                        "PREVIOUS": 22
                    },
                    // CONFIG.PROG_SUB_TYPE.AOB.AOB_REFUSE_MAXDAYS
                    5: {
                        "PREVIOUS": 22
                    },
                    // CONFIG.PROG_SUB_TYPE.AOB.AOB_REFUSE_THRESHOLD
                    6: {
                        "PREVIOUS": 22
                    }
                }
            },
            "5-11": {
                sectionGSubprogramTypeMap: {
                    20: CONFIG.PROG_SUB_TYPE.ABN.ABN_OPTION_MISMATCH_1,
                    21: CONFIG.PROG_SUB_TYPE.ABN.ABN_OPTION_MISMATCH_2,
                    22: CONFIG.PROG_SUB_TYPE.ABN.ABN_OPTION_MISMATCH_3
                },
                rxCPayerSectionGMap: {
                    1: 20,
                    2: 21,
                    3: 22
                },
                verifyScanData: {
                    sectionI: {
                        header: 'Verify Customer Signature',
                        imageType: 'SIGNATURE'
                    },
                    sectionJ: {
                        header: 'Verify Date',
                        imageType: 'DATE'
                    }
                },
                continueActiveThreshold: {
                    // CONFIG.PROG_SUB_TYPE.ABN.ABN_OPTION
                    3: 2,
                    // CONFIG.PROG_SUB_TYPE.ABN.ABN_REFUSE_ASSIGNED_ITEMS
                    9: 1
                },
                rxDispostion: {
                    // CONFIG.PROG_SUB_TYPE.ABN.ABN_OPTION_MISMATCH_1
                    4: {
                        "21": "3"
                    },
                    // CONFIG.PROG_SUB_TYPE.ABN.ABN_OPTION_MISMATCH_2
                    5: {
                        "21": "3"
                    },
                    // CONFIG.PROG_SUB_TYPE.ABN.ABN_OPTION_MISMATCH_3
                    6: {
                        "21": "3"
                    },
                    // CONFIG.PROG_SUB_TYPE.ABN.ABN_REFUSE_UNASSIGNED
                    7: {
                        "21": "4",
                        "22": "3"
                    },
                    // CONFIG.PROG_SUB_TYPE.ABN.ABN_REFUSE_ASSIGNED_ITEMS
                    8: {
                        "21": "1"
                    },
                    //CONFIG.PROG_SUB_TYPE.ABN.ABN_SIGN_DATE
                    11: {
                        "20": "3"
                    }
                },
                screenButtonMap: {
                    // CONFIG.PROG_SUB_TYPE.ABN.ABN_REQUIRED
                    1: {
                        "REFUSE": 23,
                        "CONTINUE": 11
                    },
                    // CONFIG.PROG_SUB_TYPE.ABN.ABN_OPTION
                    3: {
                        "REFUSE": 23,
                        "CONTINUE": 11
                    },
                    // CONFIG.PROG_SUB_TYPE.ABN.ABN_OPTION_MISMATCH_1
                    4: {
                        "GOBACKTOOPTIONS": 13
                    },
                    // CONFIG.PROG_SUB_TYPE.ABN.ABN_OPTION_MISMATCH_2
                    5: {
                        "GOBACKTOOPTIONS": 13
                    },
                    // CONFIG.PROG_SUB_TYPE.ABN.ABN_OPTION_MISMATCH_3
                    6: {
                        "GOBACKTOOPTIONS": 13
                    },
                    // CONFIG.PROG_SUB_TYPE.ABN.ABN_REFUSE_UNASSIGNED
                    7: {
                        "GOBACKTOOPTIONS": 13
                    },
                    // CONFIG.PROG_SUB_TYPE.ABN.ABN_REFUSE_ASSIGNED_ITEMS
                    9: {
                        "GOBACKTOOPTIONS": 13,
                        "CONTINUE": 11
                    },
                    // CONFIG.PROG_SUB_TYPE.ABN.ABN_EMPLOYEE
                    10: {
                        "PREVIOUS": 13
                    },
                    // CONFIG.PROG_SUB_TYPE.ABN.ABN_SIGN_DATE
                    11: {
                        "CONTINUE": 11
                    }
                }
            }
        };
        $scope.messageDispostion = {
            "5-10": {},
            "5-11": {}
        };

        $scope.init = function() {
            // $scope.enableBarcodeScanBroadcast(['SCANNED_DATA_FORM']);
            //AOB-10/ ABN-11
            if ($scope.messageKey === "5-10") {
                if (patientPresentMap[$scope.data.patientDetails.rxCPatientId]) {
                    if (patientPresentMap[$scope.data.patientDetails.rxCPatientId].present) {
                        $scope.dispositionMap.patientPresent = 1;
                    } else {
                        $scope.dispositionMap.patientPresent = 0;
                    }
                    $scope.goToNextMessage();
                } else {
                    var modalOptions = {
                        buttons: ['No', 'Yes'],
                        headerText: 'Patient Present',
                        bodyText: 'Is the patient present?'
                    };
                    DialogService.showDialog({}, modalOptions).then(function(result) {
                        var present = false;
                        if (result == 'Yes') {
                            present = true;
                            $scope.dispositionMap.patientPresent = 1;
                        } else {
                            $scope.dispositionMap.patientPresent = 0;
                        }
                        BasketFactory.updatePatientPresntMap($scope.data.patientDetails.rxCPatientId, {
                            present: present,
                            adult: true
                        });
                        $scope.goToNextMessage();
                    });
                }
            } else if ($scope.messageKey === "5-11") {
                $scope.goToNextMessage();
            }
        };

        $scope.goToNextMessage = function(bypassProgSubType) {
            $scope.commonData.continueActive = false;
            !bypassProgSubType && $scope.getNextProgSubType();
            $scope.messageConfig = $scope.data.messageData.messageConfigMap[$scope.nextProgSubType];
            $scope.dispositionMap[$scope.nextProgSubType] = $scope.dispositionMap[$scope.nextProgSubType] || {};
            $scope.isContinueActive();
            if ($scope.messageKey === "5-10") {
                $state.go("aob-" + $scope.nextProgSubType);
            } else if ($scope.messageKey === "5-11") {
                $state.go("abn-" + $scope.nextProgSubType);
            }
        };

        $scope.getNextProgSubType = function() {
            $scope.prevProgSubType = $scope.nextProgSubType;
            var currentDispostion = $scope.dispositionMap[$scope.nextProgSubType];
            if ($scope.messageKey === "5-10") {
                var handleRefuse = function() {
                    if (patientPresentMap[$scope.data.patientDetails.rxCPatientId].present) {
                        $scope.nextProgSubType = CONFIG.PROG_SUB_TYPE[$scope.messageType].AOB_REFUSE;
                    } else {
                        var aobFormDueDate = null;
                        var systemDate = new Date(appUtils.getCurrentTimestamp('yyyy-mm-dd'));
                        if ($scope.data.patientDetails.aobFormDueDate) {
                            aobFormDueDate = new Date($scope.data.patientDetails.aobFormDueDate);
                        }
                        if (aobFormDueDate) {
                            if (systemDate.getTime() > aobFormDueDate.getTime()) {
                                $scope.nextProgSubType = CONFIG.PROG_SUB_TYPE[$scope.messageType].AOB_REFUSE_MAXDAYS;
                            } else {
                                $scope.nextProgSubType = CONFIG.PROG_SUB_TYPE[$scope.messageType].AOB_REFUSE_THRESHOLD;
                            }
                        } else {
                            var aobThreshold = 1;
                            var soldDate = new Date();
                            aobFormDueDate = soldDate.setDate(soldDate.getDate() + aobThreshold);
                            $scope.nextProgSubType = CONFIG.PROG_SUB_TYPE[$scope.messageType].AOB_REFUSE_THRESHOLD;
                        }
                    }
                    $scope.messageDispostion[$scope.messageKey].refusalSignForm = true;
                };
                if ($scope.nextProgSubType === null) {
                    $scope.nextProgSubType = patientPresentMap[$scope.data.patientDetails.rxCPatientId].present ? CONFIG.PROG_SUB_TYPE[$scope.messageType].AOB_REQUIRED_PT : CONFIG.PROG_SUB_TYPE[$scope.messageType].AOB_REQUIRED_REP;
                    $scope.messageDispostion[$scope.messageKey].presentIndicator = $scope.dispositionMap.patientPresent;
                } else if ($scope.nextProgSubType === CONFIG.PROG_SUB_TYPE[$scope.messageType].AOB_REQUIRED_PT || $scope.nextProgSubType === CONFIG.PROG_SUB_TYPE[$scope.messageType].AOB_REQUIRED_REP) {
                    if (currentDispostion.action == '21') {
                        $scope.nextProgSubType = CONFIG.PROG_SUB_TYPE[$scope.messageType].AOB_SIGN_DATE;
                        $scope.messageDispostion[$scope.messageKey].formScanned = true;
                        $scope.messageDispostion[$scope.messageKey].posDateTimeScanned = appUtils.getCurrentTimestamp('yyyymmdd');
                    } else {
                        handleRefuse();
                    }
                } else if ($scope.nextProgSubType === CONFIG.PROG_SUB_TYPE[$scope.messageType].AOB_SIGN_DATE) {
                    if (currentDispostion.action == '21') {
                        $scope.nextProgSubType = CONFIG.PROG_SUB_TYPE[$scope.messageType].AOB_RETURN;
                    } else {
                        handleRefuse();
                    }
                } else if ($scope.nextProgSubType === CONFIG.PROG_SUB_TYPE[$scope.messageType].AOB_REFUSE || $scope.nextProgSubType === CONFIG.PROG_SUB_TYPE[$scope.messageType].AOB_REFUSE_MAXDAYS || $scope.nextProgSubType === CONFIG.PROG_SUB_TYPE[$scope.messageType].AOB_REFUSE_THRESHOLD) {
                    if (currentDispostion.action == '20') {
                        if (patientPresentMap[$scope.data.patientDetails.rxCPatientId].present) {
                            $scope.nextProgSubType = CONFIG.PROG_SUB_TYPE[$scope.messageType].AOB_REQUIRED_PT;
                        } else {
                            $scope.nextProgSubType = CONFIG.PROG_SUB_TYPE[$scope.messageType].AOB_REQUIRED_REP;
                        }
                    }
                }
            } else if ($scope.messageKey === "5-11") {
                var handleRefuse = function() {
                    if ($scope.data.basketItem.abnUnassignedInd === 'Y') {
                        $scope.nextProgSubType = CONFIG.PROG_SUB_TYPE[$scope.messageType].ABN_REFUSE_UNASSIGNED;
                    } else {
                        $scope.nextProgSubType = CONFIG.PROG_SUB_TYPE[$scope.messageType].ABN_REFUSE_ASSIGNED_ITEMS;
                    }
                };
                if ($scope.nextProgSubType === null) {
                    $scope.nextProgSubType = CONFIG.PROG_SUB_TYPE[$scope.messageType].ABN_REQUIRED;
                    $scope.commonData.continueActive = false;
                } else if ($scope.nextProgSubType === CONFIG.PROG_SUB_TYPE[$scope.messageType].ABN_REQUIRED) {
                    if (currentDispostion.action == '21') {
                        $scope.nextProgSubType = CONFIG.PROG_SUB_TYPE[$scope.messageType].ABN_OPTION;
                        $scope.commonData.continueActive = false;
                    } else {
                        handleRefuse();
                    }

                } else if ($scope.nextProgSubType === CONFIG.PROG_SUB_TYPE[$scope.messageType].ABN_OPTION) {
                    if (currentDispostion.action == '21') {
                        $scope.data.basketItem.rxCPayer = 1;
                        if (currentDispostion.sectionG == $scope.data.basketItem.rxCPayer) {
                            //Customer to Accept in Terminal
                            $scope.nextProgSubType = CONFIG.PROG_SUB_TYPE[$scope.messageType].ABN_SIGN_DATE;
                        } else {
                            $scope.nextProgSubType = $scope.masterData[$scope.messageKey].sectionGSubprogramTypeMap[$scope.data.basketItem.rxCPayer];
                        }
                    } else {
                        handleRefuse();
                    }
                } else if ($scope.nextProgSubType === CONFIG.PROG_SUB_TYPE[$scope.messageType].ABN_OPTION_MISMATCH_1 || $scope.nextProgSubType === CONFIG.PROG_SUB_TYPE[$scope.messageType].ABN_OPTION_MISMATCH_2 || $scope.nextProgSubType === CONFIG.PROG_SUB_TYPE[$scope.messageType].ABN_OPTION_MISMATCH_3) {
                    if (currentDispostion.action == '20') {
                        $scope.nextProgSubType = CONFIG.PROG_SUB_TYPE[$scope.messageType].ABN_OPTION;
                    }
                } else if ($scope.nextProgSubType === CONFIG.PROG_SUB_TYPE[$scope.messageType].ABN_REFUSE_UNASSIGNED || $scope.nextProgSubType === CONFIG.PROG_SUB_TYPE[$scope.messageType].ABN_REFUSE_ASSIGNED_ITEMS) {
                    if (currentDispostion.action == '20') {
                        $scope.nextProgSubType = CONFIG.PROG_SUB_TYPE[$scope.messageType].ABN_REQUIRED;
                    } else if (currentDispostion.action == '21') {
                        // Current Sub Program Type - 7
                        $scope.nextProgSubType = CONFIG.PROG_SUB_TYPE[$scope.messageType].ABN_EMPLOYEE;
                    }
                } else if ($scope.nextProgSubType === CONFIG.PROG_SUB_TYPE[$scope.messageType].ABN_EMPLOYEE) {
                    if (currentDispostion.action == '20') {
                        $scope.nextProgSubType = CONFIG.PROG_SUB_TYPE[$scope.messageType].ABN_REFUSE_ASSIGNED_ITEMS;
                    }
                } else if ($scope.nextProgSubType === CONFIG.PROG_SUB_TYPE[$scope.messageType].ABN_SIGN_DATE) {
                    $scope.nextProgSubType = CONFIG.PROG_SUB_TYPE[$scope.messageType].ABN_RETURN;
                }
            }
        };

        $scope.$on('SCANNED_DATA_FORM', function(evt, barcode) {
            $scope.dispositionMap.formBarcode = barcode;
            $scope.commonData.continueActive = true;
        });

        $scope.doAction = function(action, isContinue) {
            if (isContinue && !$scope.commonData.continueActive) {
                return;
            }
            $scope.dispositionMap[$scope.messageConfig.progSubType].action = action;
            $scope.goToNextMessage();
        };

        $scope.doSubAction = function(key, value) {
            $scope.dispositionMap[$scope.messageConfig.progSubType][key] = value;
            $scope.isContinueActive();
        };

        $scope.isContinueActive = function() {
            if (Object.keys($scope.dispositionMap[$scope.messageConfig.progSubType]).length >= $scope.masterData[$scope.messageKey].continueActiveThreshold[$scope.messageConfig.progSubType]) {
                $scope.commonData.continueActive = true;
            } else {
                $scope.commonData.continueActive = false;
            }
        };

        $scope.doComplete = function(actionId, continueCheck) {
            if (continueCheck && !$scope.commonData.continueActive) {
                return;
            }
            var dispositionId = $scope.masterData[$scope.messageKey].rxDispostion[$scope.nextProgSubType][actionId];
            var data = {
                dispositionId: dispositionId,
                dispositionMap: $scope.dispositionMap
            };
            $modalInstance.dismiss();
            $scope.deferred && $scope.deferred.resolve(data);
        };

        $scope.$on('SCANNED_DATA_IMAGE', function(evt, options) {
            var data = $scope.masterData[$scope.messageKey].verifyScanData[$scope.dispositionMap[$scope.messageConfig.progSubType].enableScan];
            data.image = options.scanDataPNG;
            var modalOptions = {
                templateUrl: 'views/messages/basket/med-b/verify-scan.html',
                controller: 'MedBVerifyScanModalCtrl',
                resolve: {
                    'data': function() {
                        return data;
                    }
                }
            };
            var customOptions = {
                promise: true
            };
            var verifyScanPromise = ModalService.showModal(modalOptions, customOptions);
            verifyScanPromise.then(function(result) {
                if (result) {
                    $scope.goToNextMessage();
                }
            }, function(result) {});
        });
    });

angular.module('weCarePlusApp')
    .controller('MedBVerifyScanModalCtrl', function($scope, $modalInstance, data, deferred) {
        $scope.data = data;

        $scope.doAction = function(action) {
            deferred && deferred.resolve(action);
            $modalInstance.dismiss();
        };
    });
