angular.module('weCarePlusApp')
    .controller('ABNModalCtrl', function($scope, DialogService, $socket, CONFIG) {
        $scope.inProgress = false;
        
        $scope.confirmABNOption = function(action) {
            if ($scope.commonData.continueActive) {
                $scope.dispositionMap[$scope.messageConfig.progSubType].action = action;
                !$scope.inProgress && $scope.getNextProgSubType();
                $scope.inProgress = true;
                if ($scope.nextProgSubType === 10) {
                    var confirmMessage = 'Rx' + $scope.data.basketItem.rxNum + ': Option ' + $scope.dispositionMap[$scope.prevProgSubType].sectionG + ', ' + $scope.dispositionMap[$scope.prevProgSubType].sectionH;
                    var modalOptions = {
                        buttons: [],
                        headerText: 'Customer Terminal Processing',
                        bodyText: 'WAITING FOR CUSTOMER RESPONSE',
                        blockUI: true
                    };
                    DialogService.showDialog({}, modalOptions);
                    $socket.send(JSON.stringify({
                        type: 'DISPLAY_QUESTION',
                        options: {
                            route: 'confirmABN',
                            payload: {
                                confirmMessage: confirmMessage
                            }
                        }
                    }), true).then(function(response) {
                        DialogService.closeDialog();
                        if (response.options.action) {
                            $scope.goToNextMessage(true);
                        }
                    });
                } else {
                    $scope.goToNextMessage(true);
                }
            }
        };

        $scope.doScanABN = function(section) {
            $scope.dispositionMap[$scope.messageConfig.progSubType].enableScan = section;
            $scope.dispositionMap[$scope.messageConfig.progSubType][section] = $scope.dispositionMap[$scope.messageConfig.progSubType][section] || {};
        };

        $scope.refuseEmpIdContinueWithSale = function(inputdata) {
            if (inputdata) {
                if (inputdata != CONFIG.loggedInUser.id) {
                    var modalOptions = {
                        buttons: ['Ok'],
                        headerText: 'Invalid LoggentIn UserId',
                        bodyText: 'Please provide correct logged in Agent ID'
                    };
                    DialogService.showDialog({}, modalOptions).then(function(type) {});
                    return;
                } else {
                    //SALE
                }
            } else {
                var modalOptions = {
                    buttons: ['OK'],
                    headerText: 'Warning',
                    bodyText: 'Data is required for this field'
                };
                DialogService.showDialog({}, modalOptions).then(function(result) {});
            }
        };
    });