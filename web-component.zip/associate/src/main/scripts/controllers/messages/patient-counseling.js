'use strict';

angular.module('weCarePlusApp')
    .controller('PatientCounselingMsgCtrl', function($scope, BasketService) {
        $scope.init = function() {
            $scope.patientCounselingMessage = $scope.patientMessageList[0];
            $scope.CONFIG.pageTitle = $scope.patientMessageConfig.dispTitle;
            $scope.headingText = $scope.patientCounselingMessage.reasnCounsl == '1' ? 'Pharmacist Counseling Required' : 'Pharmacist Force Counsel';
            $scope.patientFillInfo = BasketService.getFillInfoByMessageItem($scope.patientCounselingMessage);
            $scope.patientProfile = $scope.basketData[$scope.patientCounselingMessage.rxPatientId];
        };

        $scope.continue = function() {
            //Only for speciality drugs
            if ($scope.patientFillInfo.specialtyOrderNum) {
                $scope.patientCounselingMessage.specialtyOrderNum = $scope.patientFillInfo.specialtyOrderNum;
            }
            $scope.displayNextMessage();
        };
    });
