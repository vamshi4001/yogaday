'use strict';

angular.module('weCarePlusApp')
    .controller('RetailMsgCtrl', function($scope, $location,$modal, MessageFactory, DialogService, $socket) {
        $scope.CONFIG.pageTitle = $scope.patientMessage.messageConfig.dispTitle;

        $scope.loadCustomer=function(){
            $socket.send(JSON.stringify({
                type: 'DISPLAY_QUESTION',
                options: {
                    payload: {
                        displayText: "Is this the best phone number to reach you and is it a \"Mobile\" or a \"Landline\" ?",
                        contactNumber:$scope.basketData[$scope.patientMessage.rxPatientId].patientDetails.patientCntctInfo.phone
                    },
                    route: 'retailAuto'
                }
            }), true).then(function(response) {
               // processingModel.close();
                //$modalInstance.close();
                //$scope.$parent.completeHipaaForm();
            });
        };
      
        $scope.nextMessage = function() {
            MessageFactory.getNextMessage();
        };
    });
