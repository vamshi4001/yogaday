'use strict';

angular.module('weCarePlusApp')
    .controller('IsPatientPresentCtrl', function($scope, MessageService, MessageFactory,$location, $modal,$socket,DialogService,BasketService,PatientFactory) {
        
        $scope.CONFIG.pageTitle = $scope.patientMessageConfig.dispTitle;                
        $scope.dispositionMap = {};
        $scope.continueActive = false;        
        
        
        $scope.doActionLineBtn = function(patientId, actionId) {
        	
            angular.forEach($scope.patientMessageList, function(patientMessage){
                if (patientMessage.rxPatientId === patientId){
                    patientMessage.outcome = actionId;
                }
            });            
            $scope.dispositionMap[patientId] = actionId;                       
        };

        $scope.isContinueActive = function() {
            $scope.continueActive = false;
            if (Object.keys($scope.dispositionMap).length === $scope.patientMessageList.length) {
                $scope.continueActive = true;
            } else {
                $scope.continueActive = false;
            }
            return $scope.continueActive;
        };

        $scope.nextMessage = function() {
            $scope.continueActive && $scope.displayNextMessage();
        };
        
    });
