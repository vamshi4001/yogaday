'use strict';

angular.module('weCarePlusApp')
    .controller('TcpaMsgCtrl', function($scope, $location, $modal, MessageFactory, DialogService, $socket, BasketFactory, CONFIG, PrintService, EsignService, MessageService, BasketService) {
        $scope.CONFIG.pageTitle = $scope.patientMessageConfig.dispTitle;
        $scope.patientDemographicMsg = MessageFactory.getPatDemoMessage();
        $scope.tcpaMessage = $scope.patientMessageList[0];
        $scope.tcpaConfirmResolved = false;

        $scope.init = function() {
            if ($scope.patientDemographicMsg.contactPreference) {
                $scope.tcpaCustomerScreenConfirm();
            } else {
                if (MessageFactory.getTcpaEsignBack() && MessageFactory.getTcpaEsignBackInitFnc()) {
                    MessageFactory.setTcpaEsignBackInitFnc(false);
                    $location.url('/messages/patient-demographic');
                } else {
                    //As per CORE register functionality - PHANI
                    $scope.tcpaConfirmResolved = true;
                    $scope.nextMessage();
                }

            }
        };

        $scope.backToPatientDemographic = function() {
            MessageFactory.setTcpaBack(true);
            MessageFactory.setTcpaMessage($scope.tcpaMessage);
            MessageService.showPatientDemographicMessage();
            $socket.cancelDeferred('tcpaCF2');
            var options = {
                route: 'plsWaitForPharMem',
                payload: {}
            };
            $socket.send(JSON.stringify({
                type: 'DISPLAY_ONLY',
                options: options
            }), true).then(function(response) {
            });
        };

        $scope.tcpaCustomerScreenConfirm = function() {
            $scope.prefContactNumber = $scope.patientDemographicMsg[CONFIG.PATIENT_DETAILS[$scope.patientDemographicMsg.contactPreference] + 'Phone'];
            $scope.displayText = "Is this the best phone number to reach you<br/>and is it a \"Mobile\" or a \"Landline\" ?";
            $scope.phoneDataHtmlPageOne = appUtils.formatTel($scope.prefContactNumber);
            $scope.phoneDataHtmlPageTwo = appUtils.formatTel($scope.prefContactNumber);
            $scope.buttonsYesNo = false;
            $scope.prefContactType = 'AL';
            if ($scope.patientDemographicMsg.smsEnrolled === 'Y' && CONFIG.PATIENT_DETAILS[$scope.patientDemographicMsg.contactPreference] === 'mobile') {
                $scope.displayText = "Is this the best phone number to reach you?";
                $scope.phoneDataHtmlPageOne = "Mobile Phone: " + appUtils.formatTel($scope.prefContactNumber);
                $scope.phoneDataHtmlPageTwo = appUtils.formatTel($scope.prefContactNumber) + " - Mobile";
                $scope.buttonsYesNo = true;
                $scope.prefContactType = 'AM';
            } else if ($scope.patientDemographicMsg.smsEnrolled === 'Y' && CONFIG.PATIENT_DETAILS[$scope.patientDemographicMsg.contactPreference] !== 'mobile') {
                $scope.displayText = "Are these the best phone numbers to reach you?";
                $scope.phoneDataHtmlPageOne = "Mobile Phone: " + appUtils.formatTel($scope.patientDemographicMsg.mobilePhone);
                $scope.phoneDataHtmlPageOne += "<br/>" + CONFIG.PATIENT_DETAILS[$scope.patientDemographicMsg.contactPreference] + " phone: " + appUtils.formatTel($scope.prefContactNumber);
                $scope.phoneDataHtmlPageTwo = appUtils.formatTel($scope.patientDemographicMsg.mobilePhone) + " - Mobile";
                $scope.phoneDataHtmlPageTwo += "<br/>" + appUtils.formatTel($scope.prefContactNumber) + " - Landline";
                $scope.buttonsYesNo = true;
            }

            $socket.send(JSON.stringify({
                type: 'DISPLAY_QUESTION',
                options: {
                    route: 'retialActionConf',
                    payload: {
                        displayText: $scope.displayText,
                        phoneDataHtmlPageOne: $scope.phoneDataHtmlPageOne,
                        phoneDataHtmlPageTwo: $scope.phoneDataHtmlPageTwo,
                        buttonsYesNo: $scope.buttonsYesNo,
                        prefContactType: $scope.prefContactType
                    }
                }
            }), true, 'tcpaCF2').then(function(response) {
                DialogService.closeDialog();
                $scope.tcpaMessage.outcome = response.options.actionType;
                if (response.options.actionType === 'DM' || response.options.actionType === 'DL') {
                    PrintService.doPrint(appConfig.store.services.API.printService.tcpa, {});
                }
                $scope.tcpaConfirmResolved = true;
                $scope.nextMessage();
            });
        };

        $scope.nextMessage = function() {
            if ($scope.tcpaConfirmResolved) {
                MessageFactory.setTcpaMessage($scope.tcpaMessage);
                if(!MessageFactory.getTcpaEsignBack()) {
                    $scope.displayNextMessage();                                                
                } else {
                    //Form Esign Back Action
                    var patientMessageList = [];
                    patientMessageList.push($scope.patientDemographicMsg);
                    patientMessageList.push($scope.tcpaMessage);
                    BasketService.updatePatientMessageDispostion(patientMessageList);
                    EsignService.showEsign();
                }
            } else {
                var modalOptions = {
                    buttons: [],
                    headerText: 'Customer Terminal Processing',
                    bodyText: 'WAITING FOR CUSTOMER RESPONSE',
                    blockUI: true
                };
                DialogService.showDialog({}, modalOptions);
            }
        };
    });
