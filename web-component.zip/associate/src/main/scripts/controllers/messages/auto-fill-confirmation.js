'use strict';

angular.module('weCarePlusApp')
    .controller('AutoFillConfirmationCtrl', function($scope, MessageService, MessageFactory,$location, $modal,$socket,DialogService,BasketService,PayloadService,Request) {
        
        $scope.selectedScripts = {};
        $scope.patientFirstName = "";
        $scope.patientLastName = "";       
        $scope.patientIdRxInfoPatMsgListMap = MessageService.buildPatientIdRxInfoPatMsgListMap($scope.patientMessageList);       
        $scope.today = new Date();


       var patientIdPatientListMap = {};
        angular.forEach($scope.patientIdRxInfoPatMsgListMap, function(rxInfoPatMsg,patientId){ 
           $scope.patientFirstName = $scope.basketData[patientId].patientDetails.firstName;
           $scope.patientLastName = $scope.basketData[patientId].patientDetails.lastName;
            console.log('patientId');console.log(patientId);
            console.log('scope.patientFirstName');console.log($scope.patientFirstName);
            console.log('scope.patientLastName');console.log($scope.patientLastName);
            
            var patientIdPatientInfoList = patientIdPatientListMap[patientId];
            var patientName = {               
                firstName : $scope.patientFirstName,
                lastName : $scope.patientLastName               
            }
            if (patientIdPatientInfoList) {
                patientIdPatientInfoList.push(patientName);
            } else {
                patientIdPatientListMap[patientId] = patientName;
            }     

        });    
        
                
        $scope.nextMessage = function() {       
            var modalOptions = {
                buttons: [],
                headerText: 'Customer Terminal Processing',
                bodyText: 'WAITING FOR CUSTOMER RESPONSE',
                blockUI: true
            };                
            DialogService.showDialog({}, modalOptions);
            
            $socket.send(JSON.stringify({
                type: 'DISPLAY_QUESTION',
                options: {
                    route: 'driveReadyFillEnroll',
                    payload: {
                        selectedScripts: $scope.patientIdRxInfoPatMsgListMap,
                        patientName: patientIdPatientListMap
                    }
                }
            }), true).then(function(response) {               
                
                var selectedScripts = response.options.selectedScripts;                    
                    angular.forEach($scope.patientMessageList, function(patientMessage){
                        var partialBarcode = BasketService.buildPartialBarcode(patientMessage);
                        if(selectedScripts[partialBarcode]) {                       
                            if (patientMessage.outcome === 3 || patientMessage.outcome === 1) {
                                patientMessage.outcome = [partialBarcode].patientMessage.outcome
                            }                                        
                        }                                            
                    });         
                DialogService.closeDialog();
                $scope.displayNextMessage();
             });        
        };

    });
