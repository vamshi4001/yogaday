'use strict';

angular.module('weCarePlusApp')
.controller('Msg90daysCtrl', function($scope, $location, $modal, MessageFactory, DialogService, $socket, BasketFactory, 
    MessageService, BasketService) {
    $scope.CONFIG.pageTitle = $scope.patientMessageConfig.dispTitle;
    $scope.patientMessageRxInfoMap = MessageService.buildPatientIdRxInfoPatMsgListMap($scope.patientMessageList);
        
    $scope.fillInfo = {};
    $scope.patientStatusMap = {};
    $scope.continueActive = false;
    $scope.descText;
    $scope.dispositionMap = {};
    
    var patientDetailList = [];
    var patientIds = [];
    for(var i in $scope.basketData){
        if(i !== "0"){
            patientDetailList.push({patientId: $scope.basketData[i].patientDetails.rxCPatientId});
        }
    }
    if(DAILY_CONFIG.screenConfig.screenConfig && 
        DAILY_CONFIG.screenConfig.screenConfig.ninetyDayPrescriberAuthReq === 'N'){
        $scope.descText = $scope.patientMessageConfig.descTxt3;
    }else{
        $scope.descText = $scope.patientMessageConfig.descTxt;
    }
    $scope.doActionLineBtn = function(messageItem, actionId) {
        $scope.dispositionMap[messageItem.rxNum] = actionId;
        messageItem.outcome = actionId;
    };
    $scope.isContinueActive = function() {
        $scope.continueActive = false;
        var totalCount = 0;
        angular.forEach($scope.patientMessageRxInfoMap, function(messageRxInfoItemList, patientId) {
            totalCount += messageRxInfoItemList.length;
        });
        if (Object.keys($scope.dispositionMap).length === totalCount) {
            $scope.continueActive = true;
        } else {
            $scope.continueActive = false;
        }
        return $scope.continueActive;
    };

    $scope.nextMessage = function() {
        if ($scope.continueActive) {
            var confirmRxList90day = [];                    
            angular.forEach($scope.patientMessageRxInfoMap, function(messageRxInfoItemList, patientId) {
                var confirmRxInfo = {};
                confirmRxInfo.patient = {};
                confirmRxInfo.patient.firstName = $scope.basketData[patientId].patientDetails.firstName;
                confirmRxInfo.patient.lastName = $scope.basketData[patientId].patientDetails.lastName;
                confirmRxInfo.fillDescList = [];
                angular.forEach(messageRxInfoItemList, function(rxItem){
                    if($scope.dispositionMap[rxItem.patientMessage.rxNum] 
                        === $scope.patientMessageConfig.lnItmButton.button3.id){
                        confirmRxInfo.fillDescList.push(rxItem.rxInfo.drugDesc);
                    }
                });
                if(confirmRxInfo.fillDescList.length >0){
                    confirmRxList90day.push(confirmRxInfo);
                }
            });
                
            //if confirmRxList90days and attribute is on
            if(confirmRxList90day.length > 0 
                && DAILY_CONFIG.nintyDayPaymentTerminal && DAILY_CONFIG.nintyDayPaymentTerminal.value === 'Y'){
                    var modalOptions = {
                        buttons: ['Cancel'],
                        headerText: 'Customer Terminal Processing',
                        bodyText: 'WAITING FOR CUSTOMER RESPONSE',
                        blockUI: true
                    };
                    DialogService.showDialog({}, modalOptions).then(function(result){
                         $socket.cancelDeferred('90dayCF');
                         $scope.updateSecDispPriceList();
                    });
                    $socket.send(JSON.stringify({
                        type: 'DISPLAY_QUESTION',
                        options: {
                            route: '90dayConfirm',
                            payload: confirmRxList90day
                        }
                    }), true, '90dayCF').then(function(response) {
                        var action = response.options.action;
                        if (action === 'Y') {
                            BasketService.updatePatientMessageDispostion($scope.patientMessageList);                            
                        }
                        DialogService.closeDialog();
                        $scope.displayNextMessage();
                    });  
            }
            else{
                BasketService.updatePatientMessageDispostion($scope.patientMessageList);
                $scope.displayNextMessage();
            }
        }
    };
});