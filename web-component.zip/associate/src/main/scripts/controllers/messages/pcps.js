'use strict';

angular.module('weCarePlusApp')
    .controller('PcpsMsgCtrl', function($scope) {

        $scope.patientMessage = {
            "rxNum": 100002,
            "refilNum": 0,
            "pFillSeqNum": 0,
            "editVersionNum": 0,
            "rxPatientId": "123",
            "msgSeq": "1025129",
            "messageConfig": {
                "msgInd": "Y",
                "msgRank": 2,
                "displayOrder": 1,
                "promptIndicator": null,
                "dispTitle": "Prescription Schedule Counsel",
                "dispTitle2": null,
                "descTxt": "We can have your prescription(s) ready for you each time you need it, would this be helpful?&#10;&#10;We will also contact your prescriber when you are out of refills and let you know when it is ready.",
                "intrTxt": "Discuss each Rx with the patient only. The patient has the following prescriptions eligible for ReadyFill and is NOT ENROLLED. Ensure DRUG and STRENGTH are accurate and refer questions to pharmacist.",
                "intrTxt2": null,
                "usrEntryTool": {
                    "tool1": null,
                    "tool2": null,
                    "tool3": null,
                    "tool4": null
                },
                "scrButton": {
                    "button1": null,
                    "button2": null,
                    "button3": null,
                    "button4": null
                },
                "lnItmButton": {
                    "button1": null,
                    "button2": null,
                    "button3": null,
                    "button4": null
                },
                "descTxt2": null,
                "msgType": "5",
                "progType": "16"
            },
            "markDisplayed": true,
            "state": "RI",
            "dea": "C2",
            "pickupCaptureIndicator": "P",
            "patientCaptureIndicator": "P",
            "progType": "1",
            "messageType": 5,
            "pfillSeqNum": 14
        };


        $scope.messageConfig = $scope.patientMessage.messageConfig
        $scope.CONFIG.pageTitle = $scope.messageConfig.dispTitle;
        $scope.enterKeyActive = false;
        $scope.pharmacistInitials = '';
        $scope.pprItem = $scope.basketData[$scope.patientMessage.rxPatientId];
        $scope.dispositionMap = {};

        $scope.onScreenKeyClick = function(keyType, keyVal) {
            var tempValue = $scope.pharmacistInitials;
            if (keyType === 'normKey') {
                tempValue = tempValue ? (tempValue + keyVal) : keyVal;
            } else if (keyType === 'splKey') {
                switch (keyVal) {
                    case 'clear':
                        tempValue = '';
                        break;
                    case 'backspace':
                        tempValue = tempValue ? (tempValue.length > 0 ? tempValue.substr(0, tempValue.length - 1) : '') : '';
                        break;
                    case 'enter':
                        $scope.nextMessage();
                        break;
                    case 'cancel':
                        tempValue = '';
                        break;
                    default:
                        break;
                }
            } else {
                appUtils.log("Invalid type of key pressed.");
            }
            if (tempValue.length <= 3) {
                var alphaExp = /^[a-zA-Z]+$/;
                if (keyVal.match(alphaExp)) {
                    $scope.pharmacistInitials = tempValue;
                }
            } 
            $scope.enterKeyActive = tempValue.length >= 2 ? true : false;
        };

        $scope.nextMessage = function() {
            if (!$scope.enterKeyActive) {
                return;
            }
            $scope.dispositionMap[$scope.patientMessage.rxPatientId] = {
                pharmacistInitials: $scope.pharmacistInitials
            };
            BasketFactory.updateMsgDisp($scope.patientMessage, 'rxCentrMsg', $scope.dispositionMap);
            $scope.getNextMessage();
        };
    });