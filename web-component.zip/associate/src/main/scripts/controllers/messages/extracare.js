'use strict';

angular.module('weCarePlusApp')
    .controller('ExtraCareMessageCtrl', function($scope) {
        $scope.CONFIG.pageTitle = $scope.patientMessageConfig.dispTitle;
        $scope.dispostionMap = {};
        $scope.continueActive = false;

        $scope.doActionLineBtn = function(extracareMessage, actionId) {
            //Action need to taken on 1=Defer,3=Decline,5=Accept
             $scope.dispostionMap[extracareMessage.rxPatientId] = actionId;
             extracareMessage.outcome = actionId;
        };

        $scope.isContinueActive = function() {
            if (Object.keys($scope.dispostionMap).length == $scope.patientMessageList.length) {
                $scope.continueActive = true;
                return true;
            } else {
                $scope.continueActive = false;
                return false;
            }
        };

        $scope.nextMessage = function() {
            $scope.continueActive && $scope.displayNextMessage();
        };        
    });
