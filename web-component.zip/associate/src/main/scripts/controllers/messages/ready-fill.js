'use strict';

angular.module('weCarePlusApp')
    .controller('ReadyFillMsgCtrl', function($scope, MessageService) {
        $scope.CONFIG.pageTitle = $scope.patientMessageConfig.dispTitle;
        $scope.dispositionMap = {};
        $scope.continueActive = false;
        $scope.patientIdRxInfoPatMsgListMap = MessageService.buildPatientIdRxInfoPatMsgListMap($scope.patientMessageList);

        $scope.doActionLineBtn = function(rxInfoPatMsg, actionId) {
            rxInfoPatMsg.patientMessage.outcome = actionId;
            $scope.dispositionMap[rxInfoPatMsg.partialBarcode] = actionId;
        };

        $scope.isContinueActive = function() {
            $scope.continueActive = false;
            if (Object.keys($scope.dispositionMap).length === $scope.patientMessageList.length) {
                $scope.continueActive = true;
            } else {
                $scope.continueActive = false;
            }
            return $scope.continueActive;
        };

        $scope.nextMessage = function() {
            $scope.continueActive && $scope.displayNextMessage();
        };
    });
