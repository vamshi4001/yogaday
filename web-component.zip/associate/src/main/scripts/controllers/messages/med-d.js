'use strict';

//MedD Second Level Message Controller
angular.module('weCarePlusApp')
    .controller('MedDMsgCtrl', function($scope, $location, $modal, MessageFactory, DialogService, $socket, BasketFactory) {
        $scope.CONFIG.pageTitle = $scope.patientMessage.messageConfig.dispTitle;
        $scope.fillInfo = MessageFactory.getCurrentFillInfo() || {};
        $scope.dispositionMap = MessageFactory.getDispositionMap() || {};
        $scope.continueActive = false;

        //Line Item Action Handler 
        $scope.doActionLineBtn = function(patientId, actionId, partialBarcode) {
            MessageFactory.setDispositionMap(partialBarcode, actionId);
            $scope.dispositionMap = MessageFactory.getDispositionMap();
        };

        //Screen Level Continue Activates on Selecting all the Line Items
        $scope.isContinueActive = function() {
            $scope.continueActive = false;
            var totalCount = 0;
            angular.forEach($scope.patientMessageRxInfoMap, function(messageRxInfoItemList, patientId) {
                totalCount += messageRxInfoItemList.length;
            });
            if (Object.keys($scope.dispositionMap).length === totalCount) {
                $scope.continueActive = true;
            } else {
                $scope.continueActive = false;
            }
            return $scope.continueActive;
        };

        //Get Next Message
        $scope.nextMessage = function() {
            if ($scope.continueActive) {
                BasketFactory.updateMsgDisp($scope.patientMessage, 'rxCentrMsg', {
                    dispositionMap: $scope.dispositionMap,
                    patientMessageRxInfoMap: $scope.patientMessageRxInfoMap,
                    patientMessageList: $scope.patientMessageList
                });
                MessageFactory.getNextMessage();
            }
        };
    });
