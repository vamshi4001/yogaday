'use strict';

angular.module('weCarePlusApp')
    .controller('PatDemographicMsgCtrl', function($scope, $location, $modal, MessageFactory, DialogService, $socket, BasketFactory, ModalService, CONFIG, MessageService, BasketService) {
        $scope.patientDemographicMsg = !MessageFactory.getHasTcpaMessage() ? $scope.patientMessageList[0] : MessageFactory.getPatDemoMessage();
        $scope.patientProfile = angular.copy($scope.basketData[$scope.patientDemographicMsg.rxPatientId]);

        //For TCPA - Patient Demographic
        $scope.init = function() {
            if (MessageFactory.getHasTcpaMessage()) {
                $scope.patientMessageConfig = $scope.patientDemographicMsg.messageConfig;
                $scope.CONFIG.pageTitle = $scope.patientMessageConfig.dispTitle;
                var templateData = TEMPLATE_MAP.alertMessages['A-A'];//Replace Hardcoded Template Key later - PHANI
                if ($scope.patientMessageList.length > 1) {
                    var modalOptions = {
                        templateUrl: templateData.templateUrl,
                        windowClass: templateData.windowClass || 'modal-dialog-full',
                        controller: templateData.modalCtrl,
                        resolve: {
                            'data': function() {
                                return {
                                    isPatientPresentMessage: {
                                        dispTitle: 'Info',
                                        intrTxt: '<div>Is the patient present for<br/><span style="text-align: center;">' + $scope.patientProfile.patientDetails.lastName + ', ' + $scope.patientProfile.patientDetails.firstName + '?</span></div>'
                                    }
                                };
                            }
                        }
                    };
                    var customOptions = {
                        promise: true
                    };
                    var isPatientPresentModalPromise = ModalService.showModal(modalOptions, customOptions);
                    isPatientPresentModalPromise.then(function(present) {
                        $scope.patientMessageList[0].outcome = present;
                        if (present == 'Y') {
                            if ($scope.patientProfile.patientDetails.patientCntctInfo.prefContact) {
                                $scope.tcpaCustomerScreen();
                            } else {
                                //As per CORE register functionality - PHANI   
                                DialogService.closeDialog();
                            }
                        } else if (present == 'N') {
                            $scope.displayNextMessage();
                            //Resetting it to false to make sure rpaocMessage indicator is false in the
                            //posSignatureRequest disposition object
                            MessageFactory.setHasTcpaMessage(false);
                        }
                    });
                } else {
                    MessageFactory.getTcpaBack() && $scope.tcpaCustomerScreen();
                }
            } else {
                $scope.CONFIG.pageTitle = $scope.patientMessageConfig.dispTitle;
            }
        };

        $scope.addOrUpdate = function(key) {
            var modalOptions = {
                templateUrl: 'views/modals/contact-update.html',
                keyboard: false,
                backdrop: false,
                windowClass: 'over-containerwidth',
                controller: 'ContactUpdateModalCtrl',
                resolve: {
                    'data': function() {
                        return {
                            patientId: $scope.patientDemographicMsg.rxPatientId,
                            phoneNumber: $scope.patientProfile.patientDetails.patientCntctInfo.phone[key],
                            parent: 'PATIENT_DEMOGRAPHIC',
                            key: key
                        };
                    }
                }
            };

            var customOptions = {
                promise: true
            };

            ModalService.showModal(modalOptions, customOptions).then(function(result) {

                //If the number is changed for mobile remove the text enrollment status if previously enrolled
                if (result !== $scope.patientProfile.patientDetails.patientCntctInfo.phone[key] && key === 'mobile') {
                    $scope.patientProfile.patientDetails.textMessagingEnrollmentIndicator = 'No';
                }

                $scope.patientProfile.patientDetails.patientCntctInfo.phone[key] = result;

                //If preffered is not selected make the first number added as preffered
                if (!$scope.patientProfile.patientDetails.patientCntctInfo.prefContact) {
                    $scope.patientProfile.patientDetails.patientCntctInfo.prefContact = CONFIG.PATIENT_DETAILS[key];
                }

                //When the number is deleted remove the preference if any selcted for that number
                if (!result) {
                    if ($scope.patientProfile.patientDetails.patientCntctInfo.prefContact == CONFIG.PATIENT_DETAILS[key]) {
                        $scope.patientProfile.patientDetails.patientCntctInfo.prefContact = null;
                        if ($scope.patientProfile.patientDetails.patientCntctInfo.phone.home) {
                            $scope.patientProfile.patientDetails.patientCntctInfo.prefContact = CONFIG.PATIENT_DETAILS.PREFERRED_CONTACT_HOME;
                            return;
                        } else if ($scope.patientProfile.patientDetails.patientCntctInfo.phone.mobile) {
                            $scope.patientProfile.patientDetails.patientCntctInfo.prefContact = CONFIG.PATIENT_DETAILS.PREFERRED_CONTACT_MOBILE;
                            return;
                        } else if ($scope.patientProfile.patientDetails.patientCntctInfo.phone.work) {
                            $scope.patientProfile.patientDetails.patientCntctInfo.prefContact = CONFIG.PATIENT_DETAILS.PREFERRED_CONTACT_OFFICE;
                            return;
                        }
                    }
                }
            });
        };

        $scope.makePreferred = function(phone, prefContactID) {
            if (phone) {
                $scope.patientProfile.patientDetails.patientCntctInfo.prefContact = prefContactID;
            }
        };

        $scope.enrollText = function(patientId) {
            if ($scope.patientProfile.patientDetails.textMessagingEnrollmentIndicator === 'Yes') {
                return;
            }
            if ($scope.patientProfile.patientDetails.textMessagingEnrollmentIndicator && $scope.patientProfile.patientDetails.patientCntctInfo.phone.mobile) {
                var modalOptions = {
                    buttons: [],
                    headerText: 'Customer Terminal Processing',
                    bodyText: 'WAITING FOR CUSTOMER RESPONSE',
                    blockUI: true
                };
                DialogService.showDialog({}, modalOptions);
                $socket.send(JSON.stringify({
                    type: 'DISPLAY_QUESTION',
                    options: {
                        route: 'smsEnrollConfirm',
                        payload: {
                            mobile: $scope.patientProfile.patientDetails.patientCntctInfo.phone.mobile
                        }
                    }
                }), true).then(function(response) {
                    DialogService.closeDialog();
                    if (response.options.accepted) {
                        $scope.patientProfile.patientDetails.textMessagingEnrollmentIndicator = 'Yes';
                    } else {
                        var modalOptions = {
                            templateUrl: 'views/modals/contact-update.html',
                            keyboard: false,
                            backdrop: false,
                            windowClass: 'over-containerwidth',
                            controller: 'ContactUpdateModalCtrl',
                            resolve: {
                                'data': function() {
                                    return {
                                        patientId: $scope.patientDemographicMsg.rxPatientId,
                                        phoneNumber: $scope.patientProfile.patientDetails.patientCntctInfo.phone.mobile,
                                        parent: 'PATIENT_DEMOGRAPHIC',
                                        key: 'mobile'
                                    };
                                }
                            }
                        };

                        var customOptions = {
                            promise: true
                        };

                        ModalService.showModal(modalOptions, customOptions).then(function(result) {
                            if (result) {
                                $scope.patientProfile.patientDetails.textMessagingEnrollmentIndicator = 'Yes';
                            }
                            $scope.patientProfile.patientDetails.patientCntctInfo.phone.mobile = result;
                        })
                    }
                });
            }
        };

        $scope.nextMessage = function() {
            $scope.patientDemographicMsg.homePhone = $scope.patientProfile.patientDetails.patientCntctInfo.phone.home;
            $scope.patientDemographicMsg.workPhone = $scope.patientProfile.patientDetails.patientCntctInfo.phone.work;
            $scope.patientDemographicMsg.mobilePhone = $scope.patientProfile.patientDetails.patientCntctInfo.phone.mobile;
            $scope.patientDemographicMsg.contactPreference = $scope.patientProfile.patientDetails.patientCntctInfo.prefContact;
            $scope.patientDemographicMsg.smsEnrolled = $scope.patientProfile.patientDetails.textMessagingEnrollmentIndicator === 'Yes' ? 'Y' : 'A';
            $scope.patientDemographicMsg.outcome = 'Y';
            MessageFactory.getHasTcpaMessage() && MessageFactory.setPatDemoMessage($scope.patientDemographicMsg);
            if (!$scope.patientProfile.patientDetails.patientCntctInfo.prefContact) {
                if ($scope.patientProfile.patientDetails.patientCntctInfo.phone.home || $scope.patientProfile.patientDetails.patientCntctInfo.phone.mobile || $scope.patientProfile.patientDetails.patientCntctInfo.phone.work) {
                    var modalOptions = {
                        buttons: ['OK'],
                        headerText: 'Error',
                        bodyText: 'Please select a Preferred Number'
                    };
                    DialogService.showDialog({}, modalOptions).then(function(result) {});
                    return;
                }
            }
            if (MessageFactory.getHasTcpaMessage() && $scope.patientProfile.patientDetails.patientCntctInfo.prefContact && !$scope.tcpaResolved) {
                $scope.tcpaCustomerScreen();
                return;
            }
            if (MessageFactory.getTcpaBack()) {
                BasketService.updatePatientMessageDispostion($scope.patientMessageList);
                MessageService.showTcpaMessage();
            } else {                
                $scope.displayNextMessage();
            }
        };

        //Patient Demographic Changes for TCPA
        $scope.tcpaCustomerScreen = function() {
            $scope.displayText = "Is this the best phone number to reach you<br/>and is it a \"Mobile\" or a \"Landline\" ?";
            $scope.phoneDataHtmlPageOne = appUtils.formatTel($scope.patientProfile.patientDetails.patientCntctInfo.phone[CONFIG.PATIENT_DETAILS[$scope.patientProfile.patientDetails.patientCntctInfo.prefContact]]);
            $scope.phoneDataHtmlPageTwo = appUtils.formatTel($scope.patientProfile.patientDetails.patientCntctInfo.phone[CONFIG.PATIENT_DETAILS[$scope.patientProfile.patientDetails.patientCntctInfo.prefContact]]);
            $scope.buttonsYesNo = false;
            $scope.prefContactType = 'AL';
            if ($scope.patientProfile.patientDetails.textMessagingEnrollmentIndicator == 'Yes' && CONFIG.PATIENT_DETAILS[$scope.patientProfile.patientDetails.patientCntctInfo.prefContact] === 'mobile') {
                $scope.displayText = "Is this the best phone number to reach you?";
                $scope.phoneDataHtmlPageOne = "Mobile Phone: " + appUtils.formatTel($scope.patientProfile.patientDetails.patientCntctInfo.phone[CONFIG.PATIENT_DETAILS[$scope.patientProfile.patientDetails.patientCntctInfo.prefContact]]);
                $scope.phoneDataHtmlPageTwo = appUtils.formatTel($scope.patientProfile.patientDetails.patientCntctInfo.phone[CONFIG.PATIENT_DETAILS[$scope.patientProfile.patientDetails.patientCntctInfo.prefContact]]) + " - Mobile";
                $scope.buttonsYesNo = true;
                $scope.prefContactType = 'AM';
            } else if ($scope.patientProfile.patientDetails.textMessagingEnrollmentIndicator == 'Yes' && CONFIG.PATIENT_DETAILS[$scope.patientProfile.patientDetails.patientCntctInfo.prefContact] !== 'mobile') {
                $scope.displayText = "Are these the best phone numbers to reach you?";
                $scope.phoneDataHtmlPageOne = "Mobile Phone: " + appUtils.formatTel($scope.patientProfile.patientDetails.patientCntctInfo.phone.mobile);
                $scope.phoneDataHtmlPageOne += "<br/>" + CONFIG.PATIENT_DETAILS.LABELS[$scope.patientProfile.patientDetails.patientCntctInfo.prefContact] + " Phone: " + appUtils.formatTel($scope.patientProfile.patientDetails.patientCntctInfo.phone[CONFIG.PATIENT_DETAILS[$scope.patientProfile.patientDetails.patientCntctInfo.prefContact]]);
                $scope.phoneDataHtmlPageTwo = appUtils.formatTel($scope.patientProfile.patientDetails.patientCntctInfo.phone.mobile) + " - Mobile";
                $scope.phoneDataHtmlPageTwo += "<br/>" + appUtils.formatTel($scope.patientProfile.patientDetails.patientCntctInfo.phone[CONFIG.PATIENT_DETAILS[$scope.patientProfile.patientDetails.patientCntctInfo.prefContact]]) + " - Landline";
                $scope.buttonsYesNo = true;
            }
            var modalOptions = {
                buttons: [],
                headerText: 'Customer Terminal Processing',
                bodyText: 'WAITING FOR CUSTOMER RESPONSE',
                blockUI: true
            };
            DialogService.showDialog({}, modalOptions);
            $socket.send(JSON.stringify({
                type: 'DISPLAY_QUESTION',
                options: {
                    route: 'retailAuto',
                    payload: {
                        displayText: $scope.displayText,
                        phoneDataHtmlPageOne: $scope.phoneDataHtmlPageOne,
                        phoneDataHtmlPageTwo: $scope.phoneDataHtmlPageTwo,
                        buttonsYesNo: $scope.buttonsYesNo,
                        prefContactType: $scope.prefContactType
                    }
                }
            }), true, 'tcpaCF1').then(function(response) {
                DialogService.closeDialog();
                if (response.options.action == 'N') {
                    $scope.tcpaResolved = false;
                } else {
                    $scope.tcpaResolved = true;
                    $scope.nextMessage();
                }
            });
        };
    });
