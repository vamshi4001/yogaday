'use strict';

angular.module('weCarePlusApp')
    .controller('SrdMsgCtrl', function($scope, $modal, MessageFactory, CONFIG, DialogService, base64, FormValidationService, ManagerOverrideService, $location, Request, BasketFactory) {
        $scope.CONFIG.pageTitle = $scope.patientMessageConfig.dispTitle;
        $scope.state = $scope.patientMessageList[0].state;
        $scope.managerOverride = false;
        $scope.isFormValid = true;
        $scope.fieldGenericMaxLength = 22;
        $scope.patientDetails = {};
        $scope.optionalResetFlag = false;
        $scope.requiredFieldMessageMap = {
            'ID_VALUE': 'ID not entered.',
            'JURISDICTION_ID': 'Invalid Jurisdiction ID.',
            'EXPIRATION_DATE': 'Invalid Expiration Date.',
            'RELATIONSHIP_CODE': 'Invalid Relationship Code',
            'FIRST_NAME': 'Invalid First Name',
            'LAST_NAME': 'Invalid Last Name',
            'STREET_ADDRESS': 'Invalid Street Address',
            'STATE': 'Invalid state.',
            'CITY': 'Invalid city.',
            'ZIPCODE': 'Invalid Zipcode',
            'DATE_OF_BIRTH': 'Invalid Date of Birth.'
        };
        $scope.fieldRuleMap = {
            'ID_TYPE': {
                allowAlphaNumeric: 'N', //A - alphabet, N - number, AN - alphanumeric
                readOnly: true
            },
            'RELATIONSHIP_CODE': {
                readOnly: true
            },
            'EXPIRATION_DATE': {
                dateFormat: true,
                maxLength: 10,
                allowAlphaNumeric: 'N' //A - alphabet, N - number, AN - alphanumeric
            },
            'DATE_OF_BIRTH': {
                dateFormat: true,
                maxLength: 10,
                allowAlphaNumeric: 'N' //A - alphabet, N - number, AN - alphanumeric
            },
            'STATE': {
                maxLength: 2,
                allowAlphaNumeric: 'A' //A - alphabet, N - number, AN - alphanumeric
            },
            'CITY': {
                maxLength: 20
            },
            'ZIPCODE': {
                maxLength: 5
            }
        };
        $scope.idTypesMap = {};
        $scope.orderedFieldMap = {};
        $scope.orderedFieldKeyList = [];
        $scope.currentFieldKey = 'ID_TYPE';
        $scope.selectedDropdownDataMap = {};
        $scope.popupSelectDropdownFieldKeyMap = {
            'ID_TYPE': true,
            'RELATIONSHIP_CODE': true
        };
        $scope.idTypeFieldValid = false;

        $scope.init = function() {
            $scope.srdConfigRule = $scope.patientMessageList[0].srdConfigRule;
            if ($scope.srdConfigRule && $scope.srdConfigRule.promptAtPos && $scope.srdConfigRule.promptAtPos.length) {
                $scope.promptName = $scope.srdConfigRule.promptAtPos[0].promptName;
                $scope.allFieldsRequired = $scope.srdConfigRule.promptAtPos[0].code == 'P' ? true : false;
                $scope.allowIDRefusedOption = $scope.srdConfigRule.promptAtPos[0].allowIDRefusedOption;
                $scope.allowIDOverride = $scope.srdConfigRule.promptAtPos[0].allowIDOverride;
                $scope.CONFIG.pageTitle = $scope.promptName === 'PICKUP_ID' ? 'State Regulatory - Pickup Information' : 'State Regulatory - Patient Information';
                $scope.fieldLabelPickupOrPatient = $scope.promptName === 'PICKUP_ID' ? 'Pickup' : 'Patient';
                $scope.intrText = $scope.promptName === 'PICKUP_ID' ? 'State regulation requires we capture this information from the person picking up this prescription for the patient.' : 'State regulation requires we capture patient information for this prescription!';
                $scope.fieldLabelMap = {
                    'ID_TYPE': $scope.fieldLabelPickupOrPatient + ' ID Type',
                    'ID_VALUE': $scope.fieldLabelPickupOrPatient + ' ID',
                    'JURISDICTION_ID': 'Jurisdiction Type',
                    'EXPIRATION_DATE': 'Expiration Date',
                    'RELATIONSHIP_CODE': 'Relationship',
                    'FIRST_NAME': $scope.fieldLabelPickupOrPatient + ' First Name',
                    'LAST_NAME': $scope.fieldLabelPickupOrPatient + ' Last Name',
                    'STREET_ADDRESS': 'Pickup Street Address',
                    'STATE': 'Pickup State',
                    'CITY': 'Pickup City',
                    'ZIPCODE': 'Pickup Zip Code',
                    'DATE_OF_BIRTH': 'Pickup Date of Birth'
                };
                $scope.idRefuseHelpText = $scope.srdConfigRule.promptAtPos[0].idrefuseHelpText;
                $scope.orderedFieldHelpTextMap = {
                    'ID_TYPE': $scope.srdConfigRule.promptAtPos[0].idTypeHelpText,
                    'ID_VALUE': $scope.srdConfigRule.promptAtPos[0].idValueHelpText
                };
                $scope.orderedFieldValueMap = $scope.promptName === 'PICKUP_ID' ? MessageFactory.getPickUpDataObj() : {};
                FormValidationService.setState($scope.state);
                var idTypeDropdownData = [];
                angular.forEach($scope.srdConfigRule.promptAtPos[0].idTypes, function(idType) {
                    var typeKey = idType.type.split('-')[0];
                    $scope.idTypesMap[typeKey] = idType;
                    idTypeDropdownData.push({
                        code: typeKey,
                        description: idType.type.split('-')[1]
                    });
                });
                $scope.selectedDropdownDataMap['ID_TYPE'] = idTypeDropdownData;
                //If manager override is done in case of first pickup id we shouldn't auto populate the fields
                if ($scope.orderedFieldValueMap['ID_TYPE'] && $scope.orderedFieldValueMap['ID_TYPE'] == '98') {
                    // $scope.managerOverride = true;
                    // $scope.orderedFieldHelpTextMap['ID_TYPE'] = $scope.idRefuseHelpText;
                    $scope.orderedFieldValueMap = {};
                }
                if ($scope.promptName === 'PATIENT_ID') {
                    $scope.patientDetails = $scope.basketData[$scope.patientMessageList[0].rxPatientId].patientDetails || {};
                }
            } else {
                //Skip Message
            }
        };

        $scope.showPopupSelectDropdown = function() {
            if ($scope.selectedDropdownDataMap[$scope.currentFieldKey].length) {
                $modal.open({
                    templateUrl: 'views/messages/modals/popup-select-dropdown.html',
                    keyboard: false,
                    backdrop: false,
                    scope: $scope.$new(),
                    controller: 'PopupSelectDropdown',
                    resolve: {
                        'data': function() {
                            return {
                                optKeyCode: 'code',
                                optValCode: 'description',
                                helpText: $scope.currentFieldKey == 'ID_TYPE' ? 'Please select an ID Type' : 'Please select a relationship.',
                                callback: $scope.idTypeSelectDropdownCallback,
                                selectDropdownValues: $scope.selectedDropdownDataMap[$scope.currentFieldKey],
                                callbackData: $scope.currentFieldKey == 'ID_TYPE' ? 'K' : 'B'
                            }
                        }
                    }
                });
            }
        };

        $scope.idTypeSelectDropdownCallback = function(selectedKey) {
            if ($scope.currentFieldKey == 'ID_TYPE') {
                if ($scope.orderedFieldValueMap['ID_TYPE'] !== selectedKey || !$scope.idTypeFieldValid) {
                    $scope.resetFieldData();
                }
                $scope.orderedFieldValueMap['ID_TYPE'] = selectedKey;
                var fieldList = $scope.idTypesMap[selectedKey].otherSRDAttributes;
                appUtils.sortArray(fieldList, 'order', false, true);
                angular.forEach(fieldList, function(fieldObj) {
                    if (fieldObj.name !== 'ID_TYPE' && !$scope.orderedFieldValueMap[fieldObj.name]) {
                        $scope.orderedFieldValueMap[fieldObj.name] = null;
                    }
                    if (fieldObj.name === 'RELATIONSHIP_CODE') {
                        $scope.selectedDropdownDataMap[fieldObj.name] = fieldObj.relationshipValues;
                        var relationShipDetailsList = []
                        angular.forEach(fieldObj.relationshipValues, function(relationshipItem) {
                            relationShipDetailsList.push(relationshipItem.code + "-" + relationshipItem.description);
                        });
                        FormValidationService.setRelationShipRules(relationShipDetailsList);
                    }
                    $scope.orderedFieldMap[fieldObj.name] = fieldObj;
                    $scope.orderedFieldKeyList.push(fieldObj.name);
                    if (fieldObj.fieldLevelHelp !== null) {
                        $scope.orderedFieldHelpTextMap[fieldObj.name] = fieldObj.fieldLevelHelp;
                    }
                });
            } else if ($scope.currentFieldKey == 'RELATIONSHIP_CODE') {
                $scope.orderedFieldValueMap[$scope.currentFieldKey] = selectedKey;
            }
        };

        $scope.resetFieldData = function() {
            $scope.orderedFieldHelpTextMap = {
                'ID_TYPE': $scope.srdConfigRule.promptAtPos[0].idTypeHelpText,
                'ID_VALUE': $scope.srdConfigRule.promptAtPos[0].idValueHelpText
            };
            $scope.idTypeFieldValid = true;
            $scope.orderedFieldKeyList = [];
            $scope.orderedFieldMap = {};
            $scope.orderedFieldValueMap = {};
            if ($scope.promptName === 'PATIENT_ID' && ($scope.orderedFieldValueMap['FIRST_NAME'] === null || $scope.orderedFieldValueMap['LAST_NAME'] === null)) {
                $scope.orderedFieldValueMap['FIRST_NAME'] = $scope.patientDetails.firstName;
                $scope.orderedFieldValueMap['LAST_NAME'] = $scope.patientDetails.lastName;
            }
        };

        $scope.selectFieldClickHandler = function(fieldKey) {
            if (fieldKey === 'ID_TYPE' || $scope.isCurrentFieldDataValid()) {
                $scope.currentFieldKey = fieldKey;
                if ($scope.popupSelectDropdownFieldKeyMap[$scope.currentFieldKey]) {
                    $scope.showPopupSelectDropdown();
                }
            }
        };

        $scope.isCurrentFieldDataValid = function(fromNavKey) {
            // if ($scope.allFieldsRequired && !$scope.orderedFieldValueMap[$scope.currentFieldKey] && $scope.currentFieldKey !== 'ID_TYPE') {
            //     var modalOptions = {
            //         buttons: ['OK'],
            //         headerText: 'Error',
            //         bodyText: 'The value cannot be empty, Please give valid input.'
            //     };
            //     DialogService.showDialog({}, modalOptions).then(function(result) {
            //         //Close window
            //     });
            //     return false;
            // }
            if ($scope.currentFieldKey === 'ID_TYPE') {
                if (fromNavKey && $scope.idTypesMap[$scope.orderedFieldValueMap[$scope.currentFieldKey]]) {
                    if (!$scope.idTypeFieldValid) {
                        $scope.idTypeSelectDropdownCallback($scope.orderedFieldValueMap[$scope.currentFieldKey]);
                    }
                    return true;
                }
                if (!$scope.idTypeFieldValid) {
                    if ((!$scope.orderedFieldValueMap[$scope.currentFieldKey] || $scope.orderedFieldValueMap[$scope.currentFieldKey] === '') && !fromNavKey) {
                        return true;
                    }
                    var modalOptions = {
                        buttons: ['Continue'],
                        headerText: 'Field Validation Error',
                        bodyText: 'Action Not Allowed<br/>ID Type not entered.'
                    };
                    DialogService.showDialog({}, modalOptions).then(function(result) {
                        //Close window
                    });
                    return false;
                }
            } else if ($scope.currentFieldKey === 'ID_VALUE') {
                FormValidationService.setIdFieldRules($scope.idTypesMap[$scope.orderedFieldValueMap['ID_TYPE']]);
            }
            var errorMessageList = FormValidationService.doValidate($scope.currentFieldKey, $scope.orderedFieldValueMap[$scope.currentFieldKey]);
            if (errorMessageList.length) {
                $scope.handleErrorMessages(errorMessageList);
                return false;
            }
            return true;
        };

        $scope.handleErrorMessages = function(errorMessageList) {
            if (errorMessageList.length) {
                var errorMessageBodyHtml = '';
                angular.forEach(errorMessageList, function(errorMessage) {
                    errorMessageBodyHtml += errorMessage + '<br/>';
                });
                var modalOptions = {
                    buttons: ['OK'],
                    headerText: 'Error',
                    bodyText: errorMessageBodyHtml
                };
                DialogService.showDialog({}, modalOptions).then(function(result) {});
            }
        };

        $scope.fieldMaskFilter = function(item) {
            switch (item) {
                case 'clear':
                    tempValue = '';
                    delete $scope.orderedFieldValueMap[$scope.currentFieldKey];
                    break;
                case 'backspace':
                    tempValue = tempValue ? (tempValue.length > 0 ? tempValue.substr(0, tempValue.length - 1) : '') : null;
                    $scope.orderedFieldValueMap[$scope.currentFieldKey] = tempValue;
                    break;
                case 'enter':
                    break;
                case 'cancel':
                    break;

                default:
                    break;
            }
        };

        $scope.idTypeFieldValueHandler = function() {
            if (!$scope.idTypesMap[$scope.orderedFieldValueMap['ID_TYPE']]) {
                $scope.idTypeFieldValid = false;
            } else if (!$scope.idTypeFieldValid) {
                $scope.idTypeSelectDropdownCallback($scope.orderedFieldValueMap[$scope.currentFieldKey]);
            }
        };

        //Driving License - 06/ Sate ID - 02 (Allowed only for scanning) 
        $scope.$on('SCANNED_DATA_GENERIC', function(evt, barcode) {
            if ($scope.orderedFieldValueMap['ID_TYPE'] && ($scope.orderedFieldValueMap['ID_TYPE'] === '06' || $scope.orderedFieldValueMap['ID_TYPE'] === '02')) {
                if (CONFIG.srdIdscanDisallowedStates.indexOf($scope.state) !== -1) {
                    $scope.identityScan(base64.encode(barcode));
                } else {
                    var modalOptions = {
                        buttons: ['OK'],
                        headerText: 'Error',
                        bodyText: 'This store is not authorized to scan IDs.<br/>Please enter manually'
                    };
                    DialogService.showDialog({}, modalOptions).then(function(result) {});
                }
            } else if ($scope.orderedFieldValueMap['ID_TYPE'] && ($scope.orderedFieldValueMap['ID_TYPE'] !== '06' || $scope.orderedFieldValueMap['ID_TYPE'] !== '02')) {
                var modalOptions = {
                    buttons: ['OK'],
                    headerText: 'Error',
                    bodyText: 'The selected ID type cannot be scanned.<br/>Please enter data manually'
                };
                DialogService.showDialog({}, modalOptions).then(function(result) {});
            } else {
                var modalOptions = {
                    buttons: ['OK'],
                    headerText: 'Error',
                    bodyText: 'Not a valid scan, please rescan ID'
                };
                DialogService.showDialog({}, modalOptions).then(function(result) {});
            }
        });

        $scope.identityScan = function(identityData) {
            var purposeCode = $scope.orderedFieldValueMap['ID_TYPE'] === '06' ? 'DL' : 'ST';
            var identityPayload = {
                "SrdParseRequest": {
                    "parseRequest": {
                        "purposeCode": purposeCode,
                        "scanData": identityData,
                        "clerkId": CONFIG.loggedInUser.id
                    }
                }
            };
            var identityScanPromise = Request.invoke({
                url: appConfig.store.services.API.pseLicense,
                method: 'POST',
                data: identityPayload
            });
            identityScanPromise.then(function(result) {
                if (result.driversLicense) {
                    if (result.driversLicense.documentNumber) {
                        $scope.orderedFieldValueMap['ID_VALUE'] = result.driversLicense.documentNumber;
                    }
                    if (result.driversLicense.jurisdiction) {
                        $scope.orderedFieldValueMap['JURISDICTION_ID'] = result.driversLicense.jurisdiction;
                    }
                    if (result.driversLicense.lastName) {
                        $scope.orderedFieldValueMap['LAST_NAME'] = result.driversLicense.lastName;
                    }
                    if (result.driversLicense.firstName) {
                        $scope.orderedFieldValueMap['FIRST_NAME'] = result.driversLicense.firstName;
                    }
                    if (result.driversLicense.residenceAddress) {
                        $scope.orderedFieldValueMap['STREET_ADDRESS'] = result.driversLicense.residenceAddress.address1;
                        if (result.driversLicense.residenceAddress.postalCode) {
                            $scope.orderedFieldValueMap['ZIPCODE'] = (result.driversLicense.residenceAddress.postalCode.split('-')[0]).trim()
                        }
                        $scope.orderedFieldValueMap['CITY'] = result.driversLicense.residenceAddress.city;
                        $scope.orderedFieldValueMap['STATE'] = result.driversLicense.residenceAddress.stateCode;
                    }
                    if (result.driversLicense.birthDate) {
                        $scope.orderedFieldValueMap['DATE_OF_BIRTH'] = result.driversLicense.birthDate.replace("-", "/");
                    }
                    if (result.driversLicense.expirationDate) {
                        $scope.orderedFieldValueMap['EXPIRATION_DATE'] = result.driversLicense.expirationDate.replace("-", "/");
                    }
                } else {
                    var modalOptions = {
                        buttons: ['OK'],
                        headerText: 'Error',
                        bodyText: 'Error scanning ID, please try again or enter data manually'
                    };
                    DialogService.showDialog({}, modalOptions).then(function(result) {});
                }
            }, function(identityResult) {
                var modalOptions = {
                    buttons: ['OK'],
                    headerText: 'Error',
                    bodyText: 'Unable to process at this time, please enter data manually'
                };
                DialogService.showDialog({}, modalOptions).then(function(result) {});
            });
        };

        $scope.nextMessage = function() {
            if ($scope.optionalResetFlag) {
                //Disposition to checked when optional
                // $scope.orderedFieldValueMap = {};                    
            }
            if ($scope.isCurrentFieldDataValid(true)) {
                angular.forEach($scope.patientMessageList, function(patientMessage) {
                    if ($scope.promptName === 'PICKUP_ID') {
                        patientMessage.pickupDisplayed = true;
                        patientMessage.pickupIDType = $scope.orderedFieldValueMap['ID_TYPE'];
                        patientMessage.pickupID = $scope.orderedFieldValueMap['ID_VALUE'];
                        patientMessage.pickupJurisdictionCode = $scope.orderedFieldValueMap['JURISDICTION_ID'];
                        patientMessage.pickupFName = $scope.orderedFieldValueMap['FIRST_NAME'];
                        patientMessage.pickupLName = $scope.orderedFieldValueMap['LAST_NAME'];
                        patientMessage.pickupStreetAddress = $scope.orderedFieldValueMap['STREET_ADDRESS'];
                        patientMessage.pickupCity = $scope.orderedFieldValueMap['CITY'];
                        patientMessage.pickupState = $scope.orderedFieldValueMap['STATE'];
                        patientMessage.pickupZipCode = $scope.orderedFieldValueMap['ZIPCODE'];
                        if ($scope.orderedFieldValueMap['DATE_OF_BIRTH']) {
                            patientMessage.pickupDateOfBirth = Date.parse($scope.orderedFieldValueMap['DATE_OF_BIRTH']);
                        }
                    } else {
                        patientMessage.patientDisplayed = true;
                        patientMessage.patientIDType = $scope.orderedFieldValueMap['ID_TYPE'];
                        patientMessage.patientID = $scope.orderedFieldValueMap['ID_VALUE'];
                        patientMessage.patientJurisdictionCode = $scope.orderedFieldValueMap['JURISDICTION_ID'];
                        patientMessage.patientFName = $scope.orderedFieldValueMap['FIRST_NAME'];
                        patientMessage.patientLName = $scope.orderedFieldValueMap['LAST_NAME'];
                    }
                    if ($scope.orderedFieldValueMap['RELATIONSHIP_CODE']) {
                        patientMessage.relationshipCode = $scope.orderedFieldValueMap['RELATIONSHIP_CODE'].split('-')[0];
                    }
                    if ($scope.orderedFieldValueMap['EXPIRATION_DATE']) {
                        patientMessage.expirationDate = Date.parse($scope.orderedFieldValueMap['EXPIRATION_DATE']);
                    }
                });
                if ($scope.promptName === 'PICKUP_ID') {
                    MessageFactory.setPickUpDataObj($scope.orderedFieldValueMap);
                }
                $scope.displayNextMessage();
            }
        };

        $scope.onScreenKeyClick = function(keyType, keyVal) {
            var tempValue = $scope.orderedFieldValueMap[$scope.currentFieldKey];
            if (keyType === 'normKey') {
                if ($scope.managerOverride) {
                    return;
                }
                tempValue = tempValue ? (tempValue + keyVal) : keyVal;
                if (tempValue.length > $scope.fieldGenericMaxLength) {
                    return;
                }
                if ($scope.fieldRuleMap[$scope.currentFieldKey] && $scope.fieldRuleMap[$scope.currentFieldKey].readOnly) {
                    return;
                }
                if ($scope.fieldRuleMap[$scope.currentFieldKey] && $scope.fieldRuleMap[$scope.currentFieldKey].maxLength && (tempValue.length > $scope.fieldRuleMap[$scope.currentFieldKey].maxLength)) {
                    return;
                }
                if ($scope.fieldRuleMap[$scope.currentFieldKey]) {
                    if ($scope.fieldRuleMap[$scope.currentFieldKey].allowAlphaNumeric) {
                        if ($scope.fieldRuleMap[$scope.currentFieldKey].allowAlphaNumeric === 'A') {
                            var alphaExp = /^[a-zA-Z]+$/;
                            if (!keyVal.match(alphaExp)) {
                                return;
                            }
                        } else if ($scope.fieldRuleMap[$scope.currentFieldKey].allowAlphaNumeric === 'N') {
                            var numericExp = /^[0-9]+$/;
                            if (!keyVal.match(numericExp)) {
                                return;
                            }
                        } else if ($scope.fieldRuleMap[$scope.currentFieldKey].allowAlphaNumeric === 'AN') {
                            var alphaNumericExp = /^[0-9a-zA-Z]+$/;
                            if (!keyVal.match(alphaNumericExp)) {
                                return;
                            }
                        }
                    }
                    if ($scope.fieldRuleMap[$scope.currentFieldKey].dateFormat) {
                        if ((!$scope.orderedFieldValueMap[$scope.currentFieldKey] || $scope.orderedFieldValueMap[$scope.currentFieldKey].length === 0) && parseInt(keyVal) > 1) {
                            return;
                        }
                        if ($scope.orderedFieldValueMap[$scope.currentFieldKey] && $scope.orderedFieldValueMap[$scope.currentFieldKey].length === 1) {
                            var monthFirstChar = $scope.orderedFieldValueMap[$scope.currentFieldKey].charAt(0);
                            if (parseInt(monthFirstChar) === 1 && parseInt(keyVal) > 2) {
                                return;
                            } else if (parseInt(monthFirstChar) === 0 && parseInt(keyVal) === 0) {
                                return;
                            }
                            tempValue += "/";
                        } else if ($scope.orderedFieldValueMap[$scope.currentFieldKey] && $scope.orderedFieldValueMap[$scope.currentFieldKey].length === 3 && parseInt(keyVal) > 3) {
                            return;
                        } else if ($scope.orderedFieldValueMap[$scope.currentFieldKey] && $scope.orderedFieldValueMap[$scope.currentFieldKey].length === 4) {
                            var dayFirstChar = $scope.orderedFieldValueMap[$scope.currentFieldKey].charAt(3);
                            if (parseInt(dayFirstChar) === 3 && parseInt(keyVal) > 1) {
                                return;
                            } else {
                                tempValue += "/";
                            }
                        } else if ($scope.orderedFieldValueMap[$scope.currentFieldKey] && $scope.orderedFieldValueMap[$scope.currentFieldKey].length === 6 && parseInt(keyVal) > 2) {
                            return;
                        }
                    }
                }
                if ($scope.idTypeFieldValid && $scope.currentFieldKey == 'ID_TYPE') {
                    return;
                } else if (!$scope.idTypeFieldValid && $scope.currentFieldKey == 'ID_TYPE') {
                    $scope.orderedFieldValueMap[$scope.currentFieldKey] = tempValue;
                    $scope.idTypeFieldValueHandler();
                } else {
                    $scope.orderedFieldValueMap[$scope.currentFieldKey] = tempValue;
                }
            } else if (keyType === 'splKey') {
                if ((keyVal === 'previous' || keyVal === 'next')) {
                    if ($scope.managerOverride) {
                        return;
                    }
                    if ($scope.isCurrentFieldDataValid(true)) {
                        var currentFieldIndex = $scope.orderedFieldKeyList.indexOf($scope.currentFieldKey);
                        var orderedFieldKeyListLength = $scope.orderedFieldKeyList.length;
                        if (keyVal === 'next') {
                            if ((currentFieldIndex + 1) < orderedFieldKeyListLength) {
                                $scope.currentFieldKey = $scope.orderedFieldKeyList[(currentFieldIndex + 1)];
                            } else {
                                $scope.currentFieldKey = $scope.orderedFieldKeyList[0];
                            }
                        } else {
                            if (currentFieldIndex === 0) {
                                $scope.currentFieldKey = $scope.orderedFieldKeyList[orderedFieldKeyListLength - 1];
                            } else {
                                $scope.currentFieldKey = $scope.orderedFieldKeyList[(currentFieldIndex - 1)];
                            }
                        }
                        // $('#srd-form-left-container').mCustomScrollbar("scrollTo", "#" + $scope.currentFieldKey);
                        $scope.idTypeFieldValueHandler();
                        if ($scope.popupSelectDropdownFieldKeyMap[$scope.currentFieldKey]) {
                            $scope.showPopupSelectDropdown();
                        }
                    }
                }
                switch (keyVal) {
                    case 'clear':
                        if ($scope.managerOverride) {
                            return;
                        }
                        tempValue = '';
                        delete $scope.orderedFieldValueMap[$scope.currentFieldKey];
                        $scope.idTypeFieldValueHandler();
                        break;
                    case 'backspace':
                        if ($scope.managerOverride) {
                            return;
                        }
                        tempValue = tempValue ? (tempValue.length > 0 ? tempValue.substr(0, tempValue.length - 1) : '') : null;
                        $scope.orderedFieldValueMap[$scope.currentFieldKey] = tempValue;
                        $scope.idTypeFieldValueHandler();
                        break;
                    case 'enter':
                        errorMessageList = [];
                        var breakValidationLoop = false;
                        if ($scope.managerOverride) {
                            $scope.isFormValid = true;
                        } else {
                            $scope.isFormValid = true;
                            var errorMessageList = [];
                            if (!$scope.idTypeFieldValid) {
                                if (!$scope.isCurrentFieldDataValid(true)) {
                                    return;
                                }
                            }
                            if (!$scope.allFieldsRequired) {
                                $scope.optionalResetFlag = false;
                            }
                            if ($scope.allFieldsRequired && !$scope.orderedFieldValueMap[$scope.currentFieldKey]) {
                                $scope.isFormValid = false;
                                var modalOptions = {
                                    buttons: ['OK'],
                                    headerText: 'Error',
                                    bodyText: $scope.requiredFieldMessageMap[$scope.currentFieldKey] || 'Invalid data.'
                                };
                                DialogService.showDialog({}, modalOptions).then(function(result) {
                                    //Close window
                                });
                                return;
                            }
                            angular.forEach($scope.orderedFieldValueMap, function(fieldValue, fieldKey) {
                                if (!breakValidationLoop) {
                                    if ($scope.allFieldsRequired && !fieldValue) {
                                        $scope.isFormValid = false;
                                        breakValidationLoop = true;
                                        var modalOptions = {
                                            buttons: ['OK'],
                                            headerText: 'Error',
                                            bodyText: $scope.requiredFieldMessageMap[fieldKey] || 'Invalid data.'
                                        };
                                        DialogService.showDialog({}, modalOptions).then(function(result) {
                                            //Close window
                                        });
                                        return;
                                    } else if (!$scope.allFieldsRequired && !fieldValue) {
                                        $scope.optionalResetFlag = true;
                                    }
                                    errorMessageList = FormValidationService.doValidate(fieldKey, fieldValue);
                                    if (errorMessageList.length) {
                                        $scope.isFormValid = false;
                                        breakValidationLoop = true;
                                        return;
                                    }
                                }
                            });
                            if (!$scope.isFormValid) {
                                $scope.handleErrorMessages(errorMessageList);
                                return;
                            }
                        }
                        if ($scope.isFormValid) {
                            $scope.nextMessage();
                        }
                        break;
                    case 'cancel':
                        var modalOptions = {
                            buttons: ['OK'],
                            headerText: 'Error',
                            bodyText: 'A valid form of identification is required for the sale of controlled substances.<br/>If unable to obtain a valid ID, remove the prescription transaction and return it to waiting bin.'
                        };
                        DialogService.showDialog({}, modalOptions).then(function(result) {
                            if (CONFIG.storeData.isOffline) {
                                $location.url('/home');
                            } else {
                                MessageFactory.setPickUpDataObj({});
                                $location.url('/basket');
                            }
                        });
                        break;
                    case 'refused':
                        if ($scope.allowIDOverride) {
                            var modalOptions = {
                                buttons: ['OK'],
                                headerText: 'Alert',
                                bodyText: 'Manager override is required to bypass Sate Regulatory Prompt'
                            };
                            DialogService.showDialog({}, modalOptions).then(function(type) {
                                var managerOverridePromise = ManagerOverrideService.doManagerOverride({
                                    usernameHeaderText: 'Manager Override',
                                    usernameInputTextHelp: 'Enter Manager ID Number',
                                    passwordHeaderText: 'Manager Override',
                                    passwordInputTextHelp: 'Password',
                                    usernameCancelConfirm: true,
                                    passwordCancelConfirm: true
                                });
                                managerOverridePromise.then(function(result) {
                                    $scope.refusedCallback();
                                }, function(result, statusCode) {
                                    $scope.managerOverride = false;
                                });
                            });
                        } else {
                            $scope.refusedCallback();
                        }
                        break;
                    default:
                        break;
                }
            }
        };

        $scope.refusedCallback = function() {
            $scope.allowIDRefusedOption = false;
            $scope.managerOverride = true;
            $scope.currentFieldKey = 'ID_TYPE';
            $scope.resetFieldData();
            $scope.orderedFieldHelpTextMap['ID_TYPE'] = $scope.idRefuseHelpText;
            $scope.orderedFieldValueMap['ID_TYPE'] = 98;
        };
    });

angular.module('weCarePlusApp')
    .controller('PopupSelectDropdown', function($scope, $modal, $modalInstance, data, CONFIG) {
        $scope.optKeyCode = data.optKeyCode;
        $scope.optValCode = data.optValCode;
        $scope.helpText = data.helpText;
        $scope.selectDropdownValues = data.selectDropdownValues;

        $scope.dismiss = function() {
            $modalInstance.dismiss();
        };
        $scope.selectOption = function(selected) {
            var dataSelected = '';
            if (data.callbackData) {
                if (data.callbackData == 'B') {
                    dataSelected = selected[data.optKeyCode] + '-' + selected[data.optValCode];
                } else if (data.callbackData == 'K') {
                    dataSelected = selected[data.optKeyCode];
                }
            } else {
                dataSelected = selected;
            }
            data.callback && data.callback(dataSelected);
            $modalInstance.dismiss();
        };
    });
