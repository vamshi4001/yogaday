'use strict';

angular.module('weCarePlusApp')
    .controller('ReadyFillUnenrollMsgCtrl', function($scope, MessageService) {
        $scope.CONFIG.pageTitle = $scope.patientMessageConfig.dispTitle;
        $scope.patientIdRxInfoPatMsgListMap = MessageService.buildPatientIdRxInfoPatMsgListMap($scope.patientMessageList);
        
        $scope.nextMessage = function(actionId) {
        	$scope.patientMessageList.map(function(patientMessage){
        		patientMessage.outcome = actionId;
        	});
            $scope.displayNextMessage();
        };
    });
