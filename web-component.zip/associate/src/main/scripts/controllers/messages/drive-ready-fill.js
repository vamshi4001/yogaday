'use strict';

angular.module('weCarePlusApp')
.controller('DriveReadyFillMsgCtrl', function($scope, MessageService, MessageFactory, $modal, DialogService, BasketService) {

    $scope.CONFIG.pageTitle = $scope.patientMessageConfig.dispTitle;
    $scope.patientIdRxInfoPatMsgListMap = MessageService.buildPatientIdToSoldUnSoldToRxInfoPatMsgListMap($scope.patientMessageList);
    var selectedScriptsCount = 0;
    $scope.currentIndex = 0;        
    $scope.continueActive = false;

    $scope.dispositionMapInBasket = {};
    $scope.dispositionMapNotInBasket = {};          
    $scope.selectedScripts = {};
    $scope.patientIdSoldDisposition = {};

    angular.forEach($scope.patientIdRxInfoPatMsgListMap, function(patientIdRxInfoPatMsg){
        angular.forEach(patientIdRxInfoPatMsg, function(patientMessage){ 
            angular.forEach(patientMessage, function(patientMessageItem){ 
                if (patientMessageItem.rxInfo.fillDisposition.dispositionKey =='SLD') {
                    selectedScriptsCount++;
                }
                if (selectedScriptsCount != 0) {
                    MessageFactory.setPatientIdSoldDispositionMap(patientMessageItem.rxInfo.patientID, selectedScriptsCount);
                    $scope.patientIdSoldDisposition = MessageFactory.getPatientIdSoldDispositionMap();  
                }
            });
            selectedScriptsCount = 0;
        });
    });

    $scope.doActionLineBtn = function(rxInfoPatMsg, actionId) {
        rxInfoPatMsg.patientMessage.outcome = actionId;            
        MessageFactory.setDispositionMap(rxInfoPatMsg.partialBarcode, actionId);
        $scope.dispositionMapInBasket = MessageFactory.getDispositionMap();

        if (rxInfoPatMsg.patientMessage.outcome != 3){
            $scope.selectedScripts[rxInfoPatMsg.partialBarcode] = rxInfoPatMsg;
        } 
        else {
            delete $scope.selectedScripts[rxInfoPatMsg.partialBarcode];
        }
    };

    $scope.doActionLineBtnNotInBasket = function(rxInfoPatMsg, actionId) {
        rxInfoPatMsg.patientMessage.outcome = actionId;            
        MessageFactory.setDispositionMapNotInBasket(rxInfoPatMsg.partialBarcode, actionId);
        $scope.dispositionMapNotInBasket = MessageFactory.getDispositionMapNotInBasket();       
        if (rxInfoPatMsg.patientMessage.outcome != 3){
            $scope.selectedScripts[rxInfoPatMsg.partialBarcode] = rxInfoPatMsg;             

        } else {            
            delete $scope.selectedScripts[rxInfoPatMsg.partialBarcode];
        }
    };

    $scope.isContinueActive = function(patientID) {
        $scope.continueActive = false;
        if (Object.keys($scope.dispositionMapInBasket).length === $scope.patientIdSoldDisposition[patientID]) {
            $scope.continueActive = true;
        } else {
            $scope.continueActive = false;
        }                               
        return $scope.continueActive;
    };

    $scope.viewMore = function() {

    };

    $scope.printProfile = function() {
        var modalOptions = {
            buttons: ['OK'],
            headerText: 'Print ReadyFill Profile',
            bodyText: 'Report will be printed at the end of sale'
        };
        DialogService.showDialog({}, modalOptions).then(function(result) {});
        return;        
    };

    $scope.displayNextPatient = function(isLast,patientID){  
        if  ($scope.isContinueActive(patientID)){

            $scope.dispositionMapInBasket = MessageFactory.resetDispositionMap();
            $scope.dispositionMapNotInBasket = MessageFactory.resetDispositionMapNotInBasket();         
            $scope.selectedScripts = {};

            if(isLast){             
                $scope.continueActive = false;              
                $scope.displayNextMessage();
            } else {
                $scope.currentIndex++;
            }
        }
    };
});
