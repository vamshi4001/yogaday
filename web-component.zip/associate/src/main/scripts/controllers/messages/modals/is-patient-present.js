angular.module('weCarePlusApp')
    .controller('IsPatientPresentModalCtrl', function($scope, $modalInstance, MessageFactory, deferred, data) {
        $scope.isPatientPresentMessage = data.isPatientPresentMessage;
        
        $scope.doAction = function(present) {
        	$modalInstance.dismiss();
            deferred.resolve(present);
        }
    });
