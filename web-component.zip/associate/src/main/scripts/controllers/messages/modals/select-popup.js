angular.module('weCarePlusApp')
    .controller('SelectPopupCtrl', function($scope, $modal, $modalInstance, $location, data, CONFIG) {
        $scope.data = data;
        $scope.CONFIG = CONFIG;
        $scope.dismiss = function() {
            $modalInstance.dismiss();
        };
        $scope.selectOption = function(selected) {
            $scope.data.selectedOption[$scope.data.selectType] = selected;
            $modalInstance.dismiss();
        };
    });