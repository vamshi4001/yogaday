angular.module('weCarePlusApp')
    .controller('tpComplianceController', function($scope, deferred, $modal, $modalInstance, $location, CONFIG, MessageFactory, BasketService, BasketFactory, ModalService) {
          	
          	$scope.data = MessageFactory.getPatientMessageList()[0];
        	$scope.basketData = BasketFactory.getBasketData();
        	
	        $scope.CONFIG = CONFIG;
	        $scope.messageType = null;
	        $scope.tpComplianceMsgOk = false;
	        $scope.continueActive = false;
	        $scope.sigNotSignSelected = false;
	        $scope.sigNotSignSelectedAction;
	        $scope.relationshipToPatient;
          	if ($scope.data.patSigReq == 'Y' && $scope.data.prntdNameReq == 'Y' && !BasketFactory.getTpCompliancePatESign()) {
                BasketFactory.setTpCompliancePatESign(true);
            }
            $scope.doTpComplianceAction = function() {
            	$scope.tpComplianceMsgOk = true;
            	BasketFactory.setTpComplianceMessageFormSigned('SS');
        	};
        	$scope.doSignedAction = function(formType, actionId) {
	            $scope.sigNotSignSelected = true;
	            $scope.sigNotSignSelectedAction = actionId;
	            if (actionId && parseInt(actionId) == 6) {
	                BasketFactory.setTpComplianceMessageFormSigned(formType);
	            }
	        };
	        $scope.dismiss = function() {
	            $modalInstance.dismiss();
	        };
	        $scope.doPatientRelationShipAction = function(relKey, relVal) {
	            $scope.relationshipToPatient = relKey;
	        };
	        $scope.continueAction = function(messageData) {
	            if (messageData.rltnToBenfcryReq == 'Y') {
	                if ($scope.relationshipToPatient && parseInt($scope.relationshipToPatient) > 0) {
	                    BasketFactory.updateBasketMsgDisp(messageData.rxPatientId, 'tpComplianceMsg', messageData.rxNum);
	                    messageData.disposition = 1;
	                    messageData.markDisplayed = true;
	                    $modalInstance.dismiss();
	                }
	            } else {
	                BasketFactory.updateBasketMsgDisp(messageData.rxPatientId, 'tpComplianceMsg', messageData.rxNum);
	                messageData.disposition = 1;
	                messageData.markDisplayed = true;
	                $modalInstance.dismiss();
	            }
	            deferred.resolve([messageData]);
	            // data && data.callback && data.callback(true);
	        };
	        $scope.setMessageStatus = function(messageData) {
	            if (!$scope.continueActive) {
	                return;
	            }
	            if (messageData.rltnToBenfcryReq == 'Y') {
	                $modalInstance.dismiss();
	                var modalOptions = {
                        templateUrl: 'views/modals/relationship_to_patient.html',
                        windowClass: 'counseling-popup',
                        controller: 'tpComplianceController',
                        keyboard: false,
                        backdrop: false
                    };
                    var customOptions = {
                        promise: true
                    };
                    var setStatusPromise = ModalService.showModal(modalOptions, customOptions);
                    setStatusPromise.then(function(response){
                    	deferred.resolve();
                    })
	            } else {
	                $scope.continueAction(messageData);
	            }
	        };
	        $scope.isMedicareFormContinueActive = function() {
	            if (($scope.data.formsProvided && $scope.data.formsProvided != 'NIL') && $scope.data.formsSigned.formType[0] != 'NIL') {
	                if ($scope.sigNotSignSelected && $scope.tpComplianceMsgOk) {
	                    $scope.continueActive = true;
	                    return true;
	                } else {
	                    return false;
	                }
	            } else if ($scope.data.formsProvided && $scope.data.formsProvided != 'NIL') {
	                if ($scope.tpComplianceMsgOk) {
	                    $scope.continueActive = true;
	                    return true;
	                } else {
	                    return false;
	                }
	            } else if ($scope.data.formsSigned.formType[0] != 'NIL') {
	                if ($scope.sigNotSignSelected) {
	                    $scope.continueActive = true;
	                    return true;
	                } else {
	                    return false;
	                }
	            }
	        };

    });