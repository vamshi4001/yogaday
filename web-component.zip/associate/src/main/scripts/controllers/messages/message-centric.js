angular.module('weCarePlusApp')
    .controller('MessageCentricCtrl', function($scope, $modalInstance, BasketFactory, MessageFactory, BasketService, MessageService) {
        $scope.patientMessageList = MessageFactory.getPatientMessageList();
        $scope.messageCentricMessage = $scope.patientMessageList[0];

        $scope.doAction = function() {
        	BasketFactory.setBasketPageMsgAlert(false);
        	$modalInstance.dismiss();
            BasketService.updatePatientMessageDispostion($scope.patientMessageList);
            MessageService.displayMessage();
        };
    });