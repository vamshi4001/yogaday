'use strict';

angular.module('weCarePlusApp')
.controller('ReadyFillLiteMsgCtrl', function($scope, MessageService, MessageFactory,$location, $modal,$socket,DialogService,BasketService,PayloadService,Request,CONFIG) {

    $scope.CONFIG.pageTitle = $scope.patientMessageConfig.dispTitle;
    $scope.patientIdRxInfoPatMsgListMap = MessageService.buildPatientIdRxInfoPatMsgListMap($scope.patientMessageList);
    $scope.dispositionMap = {};
    $scope.continueActive = false;        
    $scope.acceptedData = {};       
    
    $scope.doActionLineBtn = function(rxInfoPatMsg, actionId) {
        rxInfoPatMsg.patientMessage.outcome = actionId;            
        MessageFactory.setDispositionMap(rxInfoPatMsg.partialBarcode, actionId);
        $scope.dispositionMap = MessageFactory.getDispositionMap();            
        if (rxInfoPatMsg.patientMessage.outcome != 3){
            $scope.acceptedData[rxInfoPatMsg.partialBarcode] = rxInfoPatMsg;
        } else {
            rxInfoPatMsg.patientMessage.patientConfirmation = 3;
            delete $scope.acceptedData[rxInfoPatMsg.partialBarcode];
        }
    };

    $scope.isContinueActive = function() {            
        $scope.continueActive = false;
        if (Object.keys($scope.dispositionMap).length === $scope.patientMessageList.length) {           
            $scope.continueActive = true;
        } else {
           $scope.continueActive = false;
       }
       return $scope.continueActive;
   };

   $scope.nextMessage = function() {
    if ($scope.isContinueActive()) {
        if(!$scope.isContinueActive) {
            return;
        }            
        if((Object.keys($scope.acceptedData).length) && (CONFIG.storeData.rdyFillLiteConfirmationFlagCheck != 'off')){
                //Begining             
                var modalOptions = {
                    buttons: [],
                    headerText: 'Customer Terminal Processing',
                    bodyText: 'WAITING FOR CUSTOMER RESPONSE',
                    blockUI: true
                };                
                DialogService.showDialog({}, modalOptions);
                
                $socket.send(JSON.stringify({
                    type: 'DISPLAY_QUESTION',
                    options: {
                        route: 'readyFillLiteEnroll',
                        payload: {
                            acceptedData: $scope.acceptedData                                                 
                        }
                    }
                }), true).then(function(response) { 
                    var acceptedData = response.options.acceptedData;
                    
                    angular.forEach($scope.patientMessageList, function(patientMessage){
                        var partialBarcode = BasketService.buildPartialBarcode(patientMessage);
                        
                        if(acceptedData[partialBarcode]) {
                            patientMessage.patientConfirmation = acceptedData[partialBarcode].patientMessage.patientConfirmation;                     
                        }                                            
                    });
                    DialogService.closeDialog();
                    $scope.acceptedData = {};                    
                    //$scope.displayNextMessage();
                });          
            } else{                           
                $scope.displayNextMessage();
            }
        }                   
    };
});