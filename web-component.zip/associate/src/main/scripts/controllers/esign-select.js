'use strict';
angular.module('weCarePlusApp')
    .controller('EsigSelectCtrl', function($scope, $modal, $location, $socket, EsignService,
        CONFIG, DialogService, BasketFactory) {
        $scope.patientProfile = BasketFactory.getOfflineProfile();
        $scope.selectionMap = {};
        
        angular.forEach($scope.patientProfile.patientFillInfoList, function(value, index) {
            var status = {
                nonSafety: false,
                hipaa: false,
                thirdParty: false
            };
            $scope.selectionMap[value.rxNum + ',' + value.refillNum] = status;
        });
        
        $scope.continue = function() {
            angular.forEach($scope.selectionMap, function (value, rxNumber) {
                var rxNum = rxNumber.split(/,/)[0];
                $scope.patientProfile.patientFillInfoList.map(function(fillInfo){
                    if (value.hipaa) {
                        fillInfo.hipaaNoticePrintedIndicator = 'Y';
                    }
                    if (value.nonSafety) {
                        fillInfo.nonSafetyCap = 'Y';
                    }
                    if (value.thirdParty) {
                        fillInfo.cashPrescriptionIndicator = 'N';
                    }
                    if (!value.thirdParty && !value.nonSafety && !value.hipaa) {
                        fillInfo.hipaaNoticePrintedIndicator = 'N';
                        fillInfo.nonSafetyCap = 'N';
                        fillInfo.cashPrescriptionIndicator = 'Y';
                    }
                });
            });
            var patientProfileList = [];
            patientProfileList[0] = $scope.patientProfile;
            EsignService.showEsign(patientProfileList);
        	return;
        }
    });
