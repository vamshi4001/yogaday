'use strict';
angular.module('weCarePlusApp')
    .controller('EsigLogCtrl', function($scope, $modal, $location, $socket, ESignFactory, CONFIG, Request, DialogService, BasketFactory, PrintService, OrderFactory, base64, $timeout, MessageFactory, EsignService, MessageService) {
        $scope.eSignAssocData = ESignFactory.getESCAssocData();
        $scope.eSignConfigData = ESignFactory.getESignConfigData();
        $scope.eSignConfigDataMap = ESignFactory.getESignConfigDataMap();
        $scope.dispostion = "";
        $scope.signCollected = false;
        $scope.fastpassRetryCount = 1;
        $scope.isFastpass = OrderFactory.getFastpass() && OrderFactory.getFastpassData();
        $scope.customerSignedOnCF = false;
        $scope.customerSignedOnMobile = false;
        $scope.outcomeDisposition = {};

        $scope.esignAgentConfigData = ESignFactory.getEsignAgentConfigData();
        $scope.esignCustomerConfigData = ESignFactory.getEsignCustomerConfigData();
        $scope.hasTcpaMessage = MessageFactory.getHasTcpaMessage();

        $scope.goToTcpa = function() {
            MessageFactory.setTcpaEsignBack(true);
            MessageService.showTcpaMessage();
        };

        $scope.fastpassSignPoll = function() {
            if (!$scope.fastpassRetryCount) {
                return;
            }
            if ($scope.fastpassRetryCount > 4) {
                // var modalOptions = {
                //     buttons: ['OK'],
                //     headerText: 'Error',
                //     bodyText: 'Customer Phone Signature Timeout',
                //     blockUI: true
                // };
                // DialogService.showDialog({}, modalOptions).then(function(result) {
                ESignFactory.doFastpassCompleteCancel({
                    statusCode: "-1",
                    statusMessage: "Cancelled"
                });
                // });
                return;
            }
            $scope.fastpassRetryCount++;
            var fastpassSignPromise = Request.invoke({
                url: '/service/bsl/fastpass/transaction/signature?version=02&transId=' + OrderFactory.getFastpassData().transactionID,
                method: 'GET',
                timeout: 200500,
                timeoutByPromise: true,
                loadMessage: 'WAITING FOR CUSTOMER RESPONSE FROM MOBILE',
                hideLoading: true,
                module: 'FastPass'
            }, 'fastpassSign');
            fastpassSignPromise.then(function(result) {
                if (result) {
                    //Set Only for Cancel Window Close Trigger
                    $scope.customerSignedOnMobile = true;
                    $scope.fastpassRetryCount = 0;
                    ESignFactory.doFastpassCompleteCancel();                    
                    $socket.cancelDeferred('esignCF');
                    //Reset After Cancel Window is Closed
                    $scope.customerSignedOnMobile = false;
                    $scope.updateSecDispPriceList();
                    $scope.signCollected = true;
                    DialogService.closeDialog();
                    var esigModel = $modal.open({
                        templateUrl: 'views/modals/esig-confirm.html',
                        keyboard: false,
                        backdrop: 'static',
                        size: 'md',
                        resolve: {
                            image: function() {
                                return {
                                    originalImg: 'data:image/png;base64,' + result.base64PNGEsig,
                                    compressedImg: result.base64TIFFEsig
                                };
                            }
                        },
                        controller: 'EsigPopupCtrl'
                    });
                }
            }, function(result) {
                $scope.fastpassRetryCount = 0;
                return;
            });
            $timeout(function() {
                Request.cancelInvoke('fastpassSign');
                $scope.fastpassSignPoll();
            }, 49000);
        };

        // if ($scope.isLocalTesting) {
        $scope.popUp = function() {

            var doNext = true;
            if ($scope.esignAgentConfigData['COUNSELING'] && $scope.esignAgentConfigData['COUNSELING'].showAcceptDecline) {
                doNext = $scope.accepted ? $scope.accepted : false;
                if (!doNext && !$scope.dispostion) {
                    return;
                }
            }

            ESignFactory.updateEsignDisposition($scope.outcomeDisposition);

            var esignCustomerConfigDataHTML = '';

            EsignService.getPaymentTerminalData().then(function(result){
                ESignFactory.builPaymentConfigData(result);
                esignCustomerConfigDataHTML = ESignFactory.getEsignCustomerConfigDataHTML();

                if (OrderFactory.getFastpass() && OrderFactory.getFastpassData()) {
                    var modalOptions = {
                        buttons: ['Cancel'],
                        headerText: 'Mobile App Prescription Pickup',
                        bodyText: 'Ask customer to sign on their phone',
                        blockUI: true
                    };
                    DialogService.showDialog({}, modalOptions).then(function(result) {
                        Request.cancelInvoke('fastpassSign');
                        $socket.cancelDeferred('esignCF');
                        $scope.fastpassRetryCount = 0;
                        if (!$scope.customerSignedOnCF && !$scope.customerSignedOnMobile)
                            ESignFactory.doFastpassCompleteCancel({
                                statusCode: "-1",
                                statusMessage: "Cancelled"
                            });
                        $scope.updateSecDispPriceList();
                    });

                    var pattern = /<br>/ig;
                    var assentText = esignCustomerConfigDataHTML.replace(pattern, "\n") + "\n";
                    var rxDataList = "Rx";
                    var rxNumList = ESignFactory.getEsingConfigRxList();
                    rxDataList += rxNumList.join(", ");
                    assentText += rxDataList;

                    $socket.send(JSON.stringify({
                        type: 'ESIG',
                        options: {
                            route: 'esig',
                            payload: {
                                displayText: "I am signing below to indicate that I: " + esignCustomerConfigDataHTML,
                                rxNumberList: ESignFactory.getEsingConfigRxList(),
                                tpCompliancePatESign: BasketFactory.getTpCompliancePatESign(),
                                customPaymentData: ESignFactory.getEsignCustomPaymentData()
                            }
                        }
                    }), true, 'esignCF').then(function(response) {
                        $scope.customerSignedOnCF = true;
                        Request.cancelInvoke('fastpassSign');
                        DialogService.closeDialog();
                        var payload = {
                            "eSigCompressionRequest": {
                                "base64PNGESig": response.options.image.replace('data:image/png;base64,', '')
                            }
                        };
                        var eSigCompPromise = Request.invoke({
                            url: appConfig.store.services.API.esigCompression,
                            method: 'POST',
                            data: payload
                        });
                        eSigCompPromise.then(
                            function(result) {
                                ESignFactory.doFastpassCompleteCancel();
                                var esigModel = $modal.open({
                                    templateUrl: 'views/modals/esig-confirm.html',
                                    keyboard: false,
                                    backdrop: 'static',
                                    size: 'md',
                                    resolve: {
                                        image: function() {
                                            return {
                                                originalImg: response.options.image,
                                                compressedImg: result.base64TIFFEsig
                                            };
                                        }
                                    },
                                    controller: 'EsigPopupCtrl'
                                });
                            },
                            function(result) {
                                var modalOptions = {
                                    buttons: ['Okay'],
                                    headerText: 'ERROR',
                                    bodyText: 'Esign Compression Failed, Please ask customer to Resign'
                                };
                                DialogService.showDialog({}, modalOptions).then(function(result) {
                                    $scope.popUp();
                                });
                            });



                        // var esigModel = $modal.open({
                        //     templateUrl: 'views/modals/esig-confirm.html',
                        //     keyboard: false,
                        //     backdrop: 'static',
                        //     size: 'md',
                        //     resolve: {
                        //         image: function() {
                        //             return response.options.image;
                        //         }
                        //     },
                        //     controller: 'EsigPopupCtrl'
                        // });
                    });
                    var mobileEsignPromise = Request.invoke({
                        url: '/service/bsl/fastpass/transaction/signaturetext/02',
                        method: 'POST',
                        data: {
                            "eSignature": {
                                "requestAccept": "Y",
                                "userID": OrderFactory.getFastpassData().userID,
                                "transactionId": OrderFactory.getFastpassData().transactionID,
                                "assentText": base64.encode("I am signing below to indicate that I: " + assentText),
                                "signatureNeeded": true,
                                "printedNameNeeded": BasketFactory.getTpCompliancePatESign()
                            }
                        }
                    });
                    mobileEsignPromise.then(function(result) {
                        $scope.fastpassSignPoll();
                    }, function(result) {
                        $scope.fastpassSignPoll();
                    });

                } else {
                    var modalOptions = {
                        buttons: ['Cancel'],
                        headerText: 'Customer Terminal Processing',
                        bodyText: 'WAITING FOR CUSTOMER RESPONSE',
                        blockUI: true
                    };
                    DialogService.showDialog({}, modalOptions).then(function(result) {
                        $socket.cancelDeferred('esignCF');
                        $scope.updateSecDispPriceList();
                    });
                    $socket.send(JSON.stringify({
                        type: 'ESIG',
                        options: {
                            route: 'esig',
                            payload: {
                                displayText: "I am signing below to indicate that I: " + esignCustomerConfigDataHTML,
                                rxNumberList: ESignFactory.getEsingConfigRxList(),
                                tpCompliancePatESign: BasketFactory.getTpCompliancePatESign(),
                                customPaymentData: ESignFactory.getEsignCustomPaymentData()
                            }
                        }
                    }), true, 'esignCF').then(function(response) {
                        DialogService.closeDialog();
                        if (!response.options.customerSigned) {
                            var modalOptions = {
                                buttons: ['OK'],
                                headerText: 'Information',
                                bodyText: 'Customer DID NOT sign electronically.',
                                blockUI: true
                            };
                            DialogService.showDialog({}, modalOptions).then(function(result) {});
                            return;
                        }
                        var payload = {
                            "eSigCompressionRequest": {
                                "base64PNGESig": response.options.image.replace('data:image/png;base64,', '')
                            }
                        };
                        var eSigCompPromise = Request.invoke({
                            url: appConfig.store.services.API.esigCompression,
                            method: 'POST',
                            data: payload
                        });
                        eSigCompPromise.then(
                            function(result) {
                                var esigModel = $modal.open({
                                    templateUrl: 'views/modals/esig-confirm.html',
                                    keyboard: false,
                                    backdrop: 'static',
                                    size: 'md',
                                    resolve: {
                                        image: function() {
                                            return {
                                                originalImg: response.options.image,
                                                compressedImg: result.base64TIFFEsig
                                            };
                                        }
                                    },
                                    controller: 'EsigPopupCtrl'
                                });
                            },
                            function(result) {
                                var modalOptions = {
                                    buttons: ['Okay'],
                                    headerText: 'ERROR',
                                    bodyText: 'Esign Compression Failed, Please ask customer to Resign'
                                };
                                DialogService.showDialog({}, modalOptions).then(function(result) {
                                    $scope.popUp();
                                });
                            });

                    });
                }
            });
        };

        $scope.cancel = function() {
            if(CONFIG.storeData.isOffline)
                $location.url('/esign-select');
            else
            $location.url('/transaction-details');
        };

        $scope.doAcceptDeclineAction = function(action) {
            var patientFillListMap = $scope.esignAgentConfigData['COUNSELING'].patientRxFillListMap;
            if (action === 'accept') {
                if ($scope.esignAgentConfigData['COUNSELING'].showEsignCounsel) {
                    $modal.open({
                        templateUrl: 'views/modals/esign-counsel.html',
                        keyboard: false,
                        backdrop: 'static',
                        windowClass: 'modal-dialog-full',
                        controller: 'EsignCounselModalCtrl',
                        resolve: {
                            'data': function() {
                                return {
                                    patientRxFillListMap: patientFillListMap,
                                    actionCallback: $scope.esignCounselActionCallback
                                };
                            }
                        }
                    });
                } else {
                    $scope.dispostion = action;
                    $scope.accepted = true;
                    var outcomeList = [];
                    angular.forEach(patientFillListMap, function(patient){
                        patient.rxInfoList.map(function(fillInfo){
                            outcomeList.push(fillInfo);
                        });
                    });
                    var outcomeData = {
                        accept: true,
                        fillInfoList: outcomeList
                    }
                    $scope.outcomeDisposition['COUNSELING'] = outcomeData;
                }
            } else {
                $scope.dispostion = action;
                $scope.accepted = false;
                var outcomeData = {
                    accept: false,
                    fillInfoList: []
                };
                $scope.outcomeDisposition['COUNSELING'] = outcomeData;
            }
        };

        $scope.esignCounselActionCallback = function(data) {
            if (data.action === 'Continue') {
                var outcomeList = [];
                angular.forEach(data.dispositionMap, function(fillInfoList) {
                    fillInfoList.map(function(fillInfo){
                        outcomeList.push(fillInfo);
                    });
                });
                var outcomeData = {
                    accept: true,
                    fillInfoList: outcomeList
                }
                $scope.outcomeDisposition['COUNSELING'] = outcomeData;
                $scope.dispostion = 'accept';
                $scope.accepted = true;
            } else {
                $scope.dispostion = undefined;
                $scope.accepted = undefined;
            }
        };

        $scope.decline = function() {
            $scope.dispostion = 'decline';
            $scope.accepted = true;
        };

        $scope.accept = function() {
            $scope.dispostion = 'accept';
            $scope.accepted = true;
        };

        $scope.patientRefusedToSign = function() {
            if (OrderFactory.getFastpass() && OrderFactory.getFastpassData()) {
                ESignFactory.doFastpassCompleteCancel({
                    statusCode: "-1",
                    statusMessage: "Cancelled"
                });
            }
            var doNext = true;
            if ($scope.eSignConfigDataMap['COUNSELING']) {
                doNext = $scope.accepted ? $scope.accepted : false;
                if (!doNext) {
                    return;
                }
            }
            // splice(position, numberOfItemsToRemove, item)
            var payload = {
                "ESigRefuseRequest": {
                    "register": 1,
                    "transactionNumber": 3456,
                    "storeNumber": CONFIG.storeData.number,
                    "empId": "1234",
                    "messageList": ESignFactory.getESCCustData(),
                    "rxNumberList": ESignFactory.getEsingConfigRxList() || []
                }
            };
            PrintService.doPrint(appConfig.store.services.API.printService.patientRefuseToSign, payload);

            var esigPayload = {
                "ESignatureRequest": {
                    "posSignatureRequest": {
                        "storeNum": CONFIG.storeNumber,
                        "registerNum": CONFIG.registerId,
                        "txnNum": appUtils.getCurrentTimestamp(CONFIG.transationTimeFormat),
                        "txnDateTime": "2015-08-11T09:30:47Z",
                        "fileName": "00144610.729",
                        "configVersion": "201208101351.PUERTORICO",
                        "driveThruInd": false,
                        "patientRefused": true,
                        "homeDelivery": false,
                        "signatureCaptureResultCode": "R",
                        "counselingAccepted": false,
                        "counselingDeclined": false,
                        "psi2Counseling": false,
                        "masterSwitchOn": false,
                        "declinedReason": "N",
                        "counselingOfferedByInit": "Y",
                        "unknownInd": {
                            "otherCounseling": true,
                            "nonSafetyCap": true,
                            "hipaaPrivacy": false,
                            "thirdParty": false,
                            "readyFillSig": false,
                            "rpaocMessage": $scope.hasTcpaMessage
                        },
                        "userId": CONFIG.loggedInUser.id,
                        "fastPassID": OrderFactory.getFastpassData().fastPassID,
                        "signatureFormat": "tiff",
                        "signature": "",
                        "pickupPersonNameFormat": "",
                        "registerPrompts": {
                            "noEventSig": false,
                            "concludingPromptInd": false,
                            "medicarePartBPromptInd": false,
                            "displayCounselingMessageB": false,
                            "otherCounseling": true,
                            "nonSafetyCap": true,
                            "hipaaPrivacy": false,
                            "thirdParty": false,
                            "readyFillSig": false,
                            "rpaocMessage": $scope.hasTcpaMessage
                        },
                        "paymentTerminalDisplay": {
                            "introSignInd": false,
                            "noEventsSigReq": false,
                            "medicarePartBPromptInd": false,
                            "suppressingOfferToCounsel": false,
                            "otherCounseling": true,
                            "nonSafetyCap": true,
                            "hipaaPrivacy": false,
                            "thirdParty": false,
                            "readyFillSig": false,
                            "rpaocMessage": $scope.hasTcpaMessage
                        },
                        "rpaocMessage": {

                        },
                        "medicarePartBInd": true,
                        "sysOnline": true,
                        "isTpHomeDeliverySelected": false,
                        "topCustomerMessage": "Top Customer Message",
                        "displayTopCustomerMessage": false
                    },
                    "storeNumber": CONFIG.storeData.number,
                    "registerNumber": CONFIG.registerId,
                    "transactionNumber": appUtils.getCurrentTimestamp(CONFIG.transationTimeFormat),
                    "status": "S",
                    "messageId": "1234"
                }
            };
            if ($scope.hasTcpaMessage) {
                MessageFactory.resolvedTcpaMessage();
            }
            ESignFactory.setPosSignatureRequest(esigPayload.ESignatureRequest.posSignatureRequest);
            if (CONFIG.storeData.isOffline) {
                MessageFactory.setIsOfflineMessagingDone(true);
            }
            $location.url("/home");
        };

    });


angular.module('weCarePlusApp')
    .controller('EsigPopupCtrl', function($scope, $modalInstance, $location, image, CONFIG, 
            Request, ESignFactory, MessageFactory, OrderFactory) {
        $scope.image = image.originalImg;
        $scope.hasTcpaMessage = MessageFactory.getHasTcpaMessage();

        $scope.redirectHome = function() {

            $modalInstance.close();

            var payload = {
                "ESignatureRequest": {
                    "posSignatureRequest": {
                        "storeNum": CONFIG.storeNumber,
                        "registerNum": CONFIG.registerId,
                        "txnNum": appUtils.getCurrentTimestamp(CONFIG.transationTimeFormat),
                        "txnDateTime": "2015-08-11T09:30:47Z",
                        "fileName": "00144610.729",
                        "configVersion": "201208101351.PUERTORICO",
                        "driveThruInd": false,
                        "patientRefused": false,
                        "homeDelivery": false,
                        "signatureCaptureResultCode": CONFIG.storeData.isOffline ? "O" : "S",
                        "counselingAccepted": false,
                        "counselingDeclined": false,
                        "psi2Counseling": false,
                        "masterSwitchOn": false,
                        "declinedReason": "N",
                        "counselingOfferedByInit": "Y",
                        "unknownInd": {
                            "otherCounseling": true,
                            "nonSafetyCap": true,
                            "hipaaPrivacy": false,
                            "thirdParty": false,
                            "readyFillSig": false,
                            "rpaocMessage": $scope.hasTcpaMessage
                        },
                        "userId": CONFIG.loggedInUser.id,
                        "fastPassID": OrderFactory.getFastpassData().fastPassID,
                        "signatureFormat": "tiff",
                        "signature": image.compressedImg,
                        "pickupPersonNameFormat": "",
                        "registerPrompts": {
                            "noEventSig": false,
                            "concludingPromptInd": false,
                            "medicarePartBPromptInd": false,
                            "displayCounselingMessageB": false,
                            "otherCounseling": true,
                            "nonSafetyCap": true,
                            "hipaaPrivacy": false,
                            "thirdParty": false,
                            "readyFillSig": false,
                            "rpaocMessage": $scope.hasTcpaMessage
                        },
                        "paymentTerminalDisplay": {
                            "introSignInd": false,
                            "noEventsSigReq": false,
                            "medicarePartBPromptInd": false,
                            "suppressingOfferToCounsel": false,
                            "otherCounseling": true,
                            "nonSafetyCap": true,
                            "hipaaPrivacy": false,
                            "thirdParty": false,
                            "readyFillSig": false,
                            "rpaocMessage": $scope.hasTcpaMessage
                        },
                        "rpaocMessage": {

                        },
                        "medicarePartBInd": true,
                        "sysOnline": true,
                        "isTpHomeDeliverySelected": false,
                        "topCustomerMessage": "Top Customer Message",
                        "displayTopCustomerMessage": false
                    },
                    "storeNumber": CONFIG.storeData.number,
                    "registerNumber": CONFIG.registerId,
                    "transactionNumber": appUtils.getCurrentTimestamp(CONFIG.transationTimeFormat),
                    "status": "S",
                    "messageId": "1234"
                }
            };
            if ($scope.hasTcpaMessage) {
                MessageFactory.resolvedTcpaMessage();
            }
            ESignFactory.setPosSignatureRequest(payload.ESignatureRequest.posSignatureRequest);

            if (CONFIG.storeData.isOffline) {
                MessageFactory.setIsOfflineMessagingDone(true);
        }

            $location.url("/home");
            return;
        };
        $scope.dismiss = function() {
            $modalInstance.close();
        };

    });

//Esign Counsel Modal Controller
angular.module('weCarePlusApp')
    .controller('EsignCounselModalCtrl', function($scope, $modalInstance, data) {
        $scope.data = data;
        $scope.data.patientRxFillListMap = angular.copy(data.patientRxFillListMap);
        $scope.dispositionMap = {};
        $scope.continueKeyActive = false;

        $scope.doLineItemAction = function(patientId, fillInfo) {
            var dispositionKey = patientId + '-' + fillInfo.rxNum + fillInfo.refillNum;
            if ($scope.dispositionMap[dispositionKey]) {
                delete fillInfo.fillDisposition.counselInd;
                delete $scope.dispositionMap[dispositionKey];
            } else {
                fillInfo.fillDisposition.counselInd = true;
                $scope.dispositionMap[dispositionKey] = fillInfo;
            }
            if (Object.keys($scope.dispositionMap).length) {
                $scope.continueKeyActive = true;
            } else {
                $scope.continueKeyActive = false;
            }
        };

        $scope.doAction = function(action) {
            if (action === 'Continue') {
                if (Object.keys($scope.dispositionMap).length < 1) {
                    return;
                }
                var callbackData = {
                    action: action,
                    dispositionMap: {}
                };
                angular.forEach($scope.dispositionMap, function(fillInfo, dispositionKey) {
                    var patientId = dispositionKey.split('-')[0];
                    delete fillInfo.fillDisposition.counselInd;
                    if (callbackData.dispositionMap[patientId]) {
                        callbackData.dispositionMap[patientId].push(fillInfo);
                    } else {
                        callbackData.dispositionMap[patientId] = [fillInfo];
                    }
                });
                data.actionCallback && data.actionCallback(callbackData);
                $modalInstance.dismiss();
            } else {
                $modalInstance.dismiss();
            }
            
        };
    });
