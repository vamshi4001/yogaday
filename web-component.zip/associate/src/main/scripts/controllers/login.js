'use strict';

angular.module('weCarePlusApp')
    .controller('LoginCtrl', function($scope, $log, $location, Request, LoginFactory, DialogService, CONFIG, NumberEntryService) {
        $scope.userId = '';
        $scope.password = '';
        $scope.isValiduserId = false;
        $scope.isValidPassword = false;
        // $scope.CONFIG.pageTitle = title;
        $scope.listnerActive = false;

        $scope.onInputFocusListner = function(currentFocusModel) {
            $scope.currentFocus = {
                model: currentFocusModel
            };
        };
        //Login user keyboard event handles
        $scope.onScreenKeyClick = function(inputdata) {
            if (inputdata) {
                $scope.searchAgent(inputdata);
            } else {
                var modalOptions = {
                    buttons: ['OK'],
                    headerText: 'Warning',
                    bodyText: 'Data is required for this field'
                };
                DialogService.showDialog({}, modalOptions).then(function(result) {});
            }
        };
        $scope.onCancel = function() {
            var modalOptions = {
                buttons: ['Yes', 'No'],
                headerText: 'Warning',
                bodyText: 'Are you sure you want to CANCEL the operation?'
            };
            DialogService.showDialog({}, modalOptions).then(function(result) {
                if (result == "Yes") {
                    $scope.inputdata = "";
                    $location.url('/login');
                }
            });
        };
        //password keyboad event handles 
        $scope.onPasswordScreenKeyClick = function(inputdata) {
            $scope.validatePassword(inputdata);
        };
        $scope.searchAgent = function(agentValue) {
            appUtils.log("LOGIN: Authenticate Username " + agentValue);
            LoginFactory.setUserId(agentValue);
            var agentLoginService = Request.invoke({
                url: appConfig.store.services.API.employees + '?emp_id=' + agentValue,
                method: 'GET'
            });
            agentLoginService.then(function(result) {
                appUtils.log("LOGIN: Authenticate Username " + agentValue + " - Successful");
                LoginFactory.setUserId(result[0].empId);
                $location.url('/password');
            }, function(result) {
                appUtils.log("LOGIN: Authenticate Username " + agentValue + " - Failed");
                appUtils.log("LOGIN: Scan Agent Cred To Continue");
                var modalOptions = {
                    buttons: ['Scan<br/>Barcode', 'Cancel'],
                    headerText: 'Scan credentials',
                    bodyText: 'Employee login info has not been saved. To save now, please generate RxConnect credentials and scan barcode here'
                };
                DialogService.showDialog({}, modalOptions).then(function(result) {
                    if (result == "Scan<br/>Barcode") {
                        $scope.listnerActive = true;
                        var modalOptions = {
                            buttons: ['Cancel'],
                            headerText: 'Scan',
                            bodyText: 'Please scan your RxConnect credentials barcode now'
                        };
                        DialogService.showDialog({}, modalOptions).then(function(result) {
                            $scope.listnerActive = false;
                            if (result == "Test") {
                                $scope.listnerActive = true;
                                $scope.$broadcast('SCANNED_DATA_GENERIC', 'KZP');
                            }
                        })
                    };
                });
            });
        };
        $scope.confirmPin = function(result) {
            LoginFactory.setPassword(result);
            var modalOptions = {
                buttons: ['OK'],
                headerText: 'Verify PIN',
                bodyText: 'Please re-enter your PIN to confirm'
            };
            DialogService.showDialog({}, modalOptions).then(function(result) {
                NumberEntryService.showDialog({}, {
                    inputText: 'Confirm Pin',
                    headerText: 'New Pin',
                    inputType: 'password',
                    maxInputLength: 4
                }).then(function(result) {
                    var oldPwd = LoginFactory.getPassword();
                    if (oldPwd == result) {
                        var employeeDetais = LoginFactory.getEmpDetails();
                        appUtils.log("LOGIN: Create Pin/ Confrim Pin For Agent " + employeeDetais.empId + " - Matched");
                        var payload = {
                            employee: {
                                "empId": employeeDetais.empId,
                                "pin": result,
                                "initials": employeeDetais.initials,
                                "firstName": employeeDetais.firstName,
                                "middleName": employeeDetais.middleName,
                                "lastName": employeeDetais.lastName,
                                "licenseNumber": employeeDetais.licenseNumber,
                                "licenseState": employeeDetais.licenseState,
                                "NPI": employeeDetais.NPI,
                                "roles": employeeDetais.roles,
                                "extracareCard": "1234"
                            }
                        };
                        appUtils.log("LOGIN: Invoke Save Employee " + employeeDetais.empId);
                        var saveEmpPromise = Request.invoke({
                            url: appConfig.store.services.API.employees,
                            method: 'POST',
                            data: payload
                        });
                        saveEmpPromise.then(function(result) {
                            appUtils.log("LOGIN: Invoke Save Employee - Successful");
                            var modalOptions = {
                                buttons: ['OK'],
                                headerText: 'Success',
                                bodyText: 'Your password has been successfully saved. If you wish to change this in the future, ask your manager for assistance'
                            };
                            DialogService.showDialog({}, modalOptions).then(function(result) {
                                $scope.validatePassword(LoginFactory.getPassword());
                            });
                        }, function(result, statusCode) {
                            appUtils.log("LOGIN: Invoke Save Employee - Failed");
                            $scope.inputdata = "";
                            var modalOptions = {
                                buttons: ['OK'],
                                headerText: 'Error',
                                bodyText: 'There was issue saving details to server, Please try again later'
                            };
                        });
                    } else {
                        appUtils.log("LOGIN: Create Pin/ Confrim Pin - Not Matched");
                        var modalOptions = {
                            buttons: ['OK'],
                            headerText: 'Error',
                            bodyText: 'Password entered does not match original selection. Please try again'
                        };
                        DialogService.showDialog({}, modalOptions).then(function(result) {});
                        $scope.inputdata = "";
                        return;
                    }
                    $location.url('/patient-lookup');
                });
            });
        };
        $scope.$on('SCANNED_DATA_GENERIC', function(evt, barcode) {
            if (!$scope.listnerActive) {
                return;
            }
            appUtils.log("LOGIN: Scanned Cred Barcode Scan - Successful");
            $scope.listnerActive = false;
            DialogService.closeDialog();
            var employeeId = LoginFactory.getUserId();
            var loginService = Request.invoke({
                url: appConfig.store.services.API.employees + '?emp_id=' + employeeId + "&cred=" + barcode,
                method: 'GET'
            });
            loginService.then(function(result) {
                if (result && result.length) {
                    appUtils.log("LOGIN: Agent Cred Validate - Successful");
                    appUtils.log("LOGIN: New Agent Create Pin - Show Dialog");
                    LoginFactory.setEmpDetails(result[0]);
                    var modalOptions = {
                        buttons: ['OK'],
                        headerText: 'Success !',
                        bodyText: 'RxConnect authentication successful. Please choose 4 digit PIN you will use to sign and punch in/out. NOTE: Write your password down in a secure place for future reference'
                    };
                    DialogService.showDialog({}, modalOptions).then(function(result) {
                        NumberEntryService.showDialog({}, {
                            inputText: 'Create Pin',
                            headerText: 'New Pin',
                            inputType: 'password',
                            maxInputLength: 4
                        }).then(function(result) {
                            appUtils.log("LOGIN: New Agent Confirm Pin - Show Dialog");
                            $scope.confirmPin(result);
                        });
                    });
                }

            }, function(result) {
                appUtils.log("LOGIN: Agent Cred Validate - Failed");
                var modalOptions = {
                    buttons: ['OK'],
                    headerText: 'Error !',
                    bodyText: 'RxConnect authentication failed. Verify that your credentials have not expired and try again.'
                };
                DialogService.showDialog({}, modalOptions).then(function(result) {});
            });
        });
        $scope.validatePassword = function(passwordValue) {
            appUtils.log("LOGIN: Authenticate Password");
            var agentLoginService = Request.invoke({
                url: appConfig.store.services.API.employees + '?emp_id=' + LoginFactory.getUserId() + '&pin=' + passwordValue,
                method: 'GET'
            });
            agentLoginService.then(function(result) {
                if (result && result.length) {
                    appUtils.log("LOGIN: Authenticate Password - Successful");
                    CONFIG.loggedInUser.id = result[0].empId;
                    CONFIG.loggedInUser.roles = result[0].roles;
                    LoginFactory.setUserId(result[0].empId);
                    LoginFactory.setAuthToken(result[0].token);
                    CONFIG.headerData.token = result[0].token;
                    $location.url('/patient-lookup');
                }
            }, function(result) {
                appUtils.log("LOGIN: Authenticate Password - Failed");
                var modalOptions = {
                    buttons: ['OK'],
                    headerText: 'Error Message',
                    bodyText: 'Password is Incorrect'
                };
                DialogService.showDialog({}, modalOptions).then(function(result) {});
            });
        };
    });
