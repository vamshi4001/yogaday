'use strict';

angular.module('weCarePlusApp')
    .controller('HomeCtrl', ['$scope', '$socket', '$location', '$modal', 'DialogService',
        'BasketFactory', 'PatientFactory', 'Request', 'PseFactory', 'OrderFactory',
        'ESignFactory', 'CONFIG', 'EmployeeMgmtFactory', 'NumberEntryService',
        'TransactionInfo', 'PrintService', 'PseService', 'base64', 'MessageFactory', '$route',
        'ManagerOverrideService', 'HipaaService', 'BasketService',
        function($scope, $socket, $location, $modal, DialogService, BasketFactory,
            PatientFactory, Request, PseFactory, OrderFactory,
            ESignFactory, CONFIG, EmployeeMgmtFactory, NumberEntryService,
            TransactionInfo, PrintService, PseService, base64, MessageFactory, $route,
            ManagerOverrideService, HipaaService, BasketService) {

            $scope.init = function() {
                $scope.resolveExtracareHealthRewards();
            };

            var loggerName = 'HomeCtrl';
            $scope.resolveExtracareHealthRewards = function() {
                var selectedPatientList = PatientFactory.getSelectedPatientList();
                var showHipaa = false;
                angular.forEach(selectedPatientList, function(patientItem, patientID) {
                    if (!showHipaa && patientItem.eccData && (patientItem.eccData.enrollmentStatus === 'S' || patientItem.eccData.enrollmentStatus === 'R') && !patientItem.eccData.resolved && patientItem.eccData.xtracareCardNumber) {
                        showHipaa = true;
                        var opts = {
                            patinetId: patientItem.rxCPatientId,
                            patientName: patientItem.lastName + ', ' + patientItem.firstName,
                            phrEnrollmentBarcode: '1900000000' + patientItem.rxCPatientId + '0'
                        };
                        opts.extraCareCardNo = patientItem.eccData.xtracareCardNumber;
                        if (patientItem.eccData.enrollmentStatus === 'R') {
                            delete opts.extraCareCardNo;
                        }
                        HipaaService.enroll(opts);
                    }
                });
                return showHipaa;
            };

            var disableScanListeners = function() {
                appUtils.log("HOME: unbinding all scan listeners...");
                $scope.disableRootScanListeners();
                if ($scope.unBinders.unbindOtcScan) $scope.unBinders.unbindOtcScan();
                if ($scope.unBinders.unbindFastpassScan) $scope.unBinders.unbindFastpassScan();
                if ($scope.unBinders.unbindRxScan) $scope.unBinders.unbindRxScan();
                if ($scope.unBinders.unbindSplRxScan) $scope.unBinders.unbindSplRxScan();
                if ($scope.unBinders.unbindLicenseScan) $scope.unBinders.unbindLicenseScan();
                if ($scope.unBinders.unbindNonLicenseScan) $scope.unBinders.unbindNonLicenseScan();
                if ($scope.unBinders.unbindPhrScan) $scope.unBinders.unbindPhrScan();
            }

            var enableScanListeners = function() {
                appUtils.log("HOME: enabling all scan listeners except license...");
                $scope.enableRootScanListeners();
                $scope.unBinders.unbindOtcScan = $scope.$on('SCANNED_DATA_OTC', scanOtc);
                $scope.unBinders.unbindFastpassScan = $scope.$on('SCANNED_DATA_FASTPASS', handleFastPass);
                $scope.unBinders.unbindRxScan = $scope.$on('SCANNED_DATA_RX', handleRxScan);
                $scope.unBinders.unbindSplRxScan = $scope.$on('SCANNED_DATA_SPLRX', handleSplRxScan);
                $scope.unBinders.unbindPhrScan = $scope.$on('SCANNED_DATA_PHR', handlePhrEnrollment);
            }

            $scope.initializeHome = function() {

                appUtils.log("HOME: initializing home controller...");

                /**
                 * unbind all the scan event listeners when initializing.
                 * They will be bound at the end of this function.
                 */
                disableScanListeners();

                $scope.CONFIG.pageTitle = 'CVS Health';
                $scope.isManager = CONFIG.loggedInUser.roles == 'P' ? true : false;
                $scope.isMinuteClinicDeposits = false;
                $scope.isOffline = CONFIG.storeData.isOffline;
                $scope.isPriceModify = false;
                $scope.isPriceVerify = false;
                $scope.isPserPurchaseIsCompleted = PseFactory.getIsPserPurchaseIsCompleted();
                $scope.isRefund = PseFactory.getIsPseRefund() ? PseFactory.getIsPseRefund() : false;
                $scope.minuteClinicDepositsOrder = [];
                $scope.patientInfoByCardno = PatientFactory.getExtraCareInfoByCardno();
                $scope.patientListByPhone = PatientFactory.getPatientListByPhone();
                $scope.refundSaleCompleted = PseFactory.isPseRefundPayCompleted();
                $scope.rxOrder = BasketFactory.getRxItemsInOrder();
                $scope.tempCurrOrder = OrderFactory.getOtcDataFromTxn();
                $scope.voidEarlierItemActive = false;
                $scope.voidEarlierItemDisabled = ($scope.getAllItemsInOrder().length || $scope.minuteClinicDepositsOrder.length) ? false : true;
                $scope.activePaidOut = null;
                enableScanListeners();
            };

            $scope.isRefundActive = function() {
                if (!$scope.isRefund) {
                    if (Object.keys($scope.rxOrder).length || OrderFactory.getOtcDataFromTxn().length || $scope.minuteClinicDepositsOrder.length) {
                        return false;
                    }
                    return true;
                }
                return true;
            };

            $scope.doPaidouts = function(actionTaken) {
                if ($scope.isRefund || $scope.isPriceModify) {
                    return;
                }
                if ($scope.activePaidOut && $scope.activePaidOut !== actionTaken) {
                    return;
                }
                if ($scope.minuteClinicDepositsOrder.length) {
                    return;
                }
                if ($scope.getAllItemsInOrder().length && !$scope.activePaidOut) {
                    return;
                }
                NumberEntryService.showDialog({}, {
                    inputText: CONFIG.paidOuts[actionTaken].viewData.inputText,
                    headerText: CONFIG.paidOuts[actionTaken].viewData.headerText,
                    cancelConfirm: true,
                    maskCurrency: true,
                    thresholdValue: CONFIG.MAXIMUM_LIMIT.paidOutsLimit,
                    thresholdValueAlertText: CONFIG.paidOuts[actionTaken].viewData.thresholdValueAlertText

                }).then(function(resultVal) {
                    resultVal = -(parseInt(resultVal) / 100).toFixed(2);
                    if ($scope.voidEarlierItemActive && !$scope.voidEarlierItemDisabled) {
                        for (var i = 0; i < OrderFactory.getOtcDataFromTxn().length; i++) {
                            if (resultVal === OrderFactory.getOtcDataFromTxn()[i].retailPrice) {
                                $scope.voidEarlierItemActive = false;
                                $scope.tempCurrOrder.splice(i, 1);
                                $scope.updateSecDispPriceList();
                                return;
                            }
                        }
                    } else {
                        var managerOverridePromise = ManagerOverrideService.doManagerOverride({
                            usernameHeaderText: 'Manager Override',
                            usernameInputTextHelp: 'Enter Manager ID Number',
                            passwordHeaderText: 'Manager Override',
                            passwordInputTextHelp: 'Enter Password',
                            usernameCancelConfirm: true,
                            passwordCancelConfirm: true,
                            bypassIfManager: true
                        });
                        if (!$scope.isManager) {
                            managerOverridePromise.then(
                                function(result) {
                                    if (!$scope.activePaidOut) {
                                        $scope.activePaidOut = actionTaken;
                                        disableScanListeners();
                                        $scope.refundSaleCompleted = true;
                                    }
                                    var otcPaidout = angular.copy(CONFIG.paidOuts[actionTaken].payloadData);
                                    otcPaidout.cost = resultVal;
                                    otcPaidout.retailPrice = resultVal;
                                    OrderFactory.getTransactionIdData();
                                    OrderFactory.getOtcDataFromTxn().push(otcPaidout);
                                    $scope.tempCurrOrder = OrderFactory.getOtcDataFromTxn();
                                    $scope.updateSecDispPriceList();
                                },
                                function(empNotOnFile) {});
                        } else {
                            if (!$scope.activePaidOut) {
                                $scope.activePaidOut = actionTaken;
                                disableScanListeners();
                                $scope.refundSaleCompleted = true;
                            }
                            var otcPaidout = angular.copy(CONFIG.paidOuts[actionTaken].payloadData);
                            otcPaidout.cost = resultVal;
                            otcPaidout.retailPrice = resultVal;
                            OrderFactory.getTransactionIdData();
                            OrderFactory.getOtcDataFromTxn().push(otcPaidout);
                            $scope.tempCurrOrder = OrderFactory.getOtcDataFromTxn();
                            $scope.updateSecDispPriceList();
                        }
                    }
                });
            };
            /**
             *To check whether total items reached max pos sold and display a popup
             * if max pos sold is empty or null, then default value 50 is used
             */
            $scope.isMaxItem = function() {
                var returnValue = false;
                var currentOrderSoldCount = $scope.getAllItemsInOrder().length + $scope.minuteClinicDepositsOrder.length;
                var maxItemsInOrderCount = 50;
                if (DAILY_CONFIG.screenConfig.screenConfig && DAILY_CONFIG.screenConfig.screenConfig.maxPosSold) {
                    maxItemsInOrderCount = DAILY_CONFIG.screenConfig.screenConfig.maxPosSold;
                }
                if (currentOrderSoldCount >= maxItemsInOrderCount) {
                    returnValue = true;
                    var modalOptions = {
                        buttons: ['OK'],
                        headerText: 'Error',
                        bodyText: 'Max POS Items in Order, Action not allowed.'
                    };
                    DialogService.showDialog({}, modalOptions).then(function(result) {
                        //Close window
                    });
                }
                return returnValue;
            };
            $scope.getCurrentTxnNum = function() {
                return TransactionInfo.getTransactionNumber();
            };

            $scope.taxNonTaxAmountAction = function(taxable) {
                if ($scope.isMinuteClinicDeposits || $scope.isMaxItem() || $scope.activePaidOut) {
                    return;
                }
                NumberEntryService.showDialog({}, {
                    inputText: taxable ? 'TAXABLE Amount' : 'Enter CVS OTC Item Price Using Keypad',
                    headerText: taxable ? 'TAXABLE' : 'CVS OTC',
                    cancelConfirm: true,
                    maskCurrency: true,
                    thresholdValue: CONFIG.MAXIMUM_LIMIT.otcAmountLimit
                }).then(function(resultVal) {
                    if (resultVal) {
                        if ($scope.isRefund) {
                            resultVal = -(parseInt(resultVal) / 100).toFixed(2);
                        } else {
                            resultVal = (parseInt(resultVal) / 100).toFixed(2);
                        }
                        var otcItemSpl = {
                            "sku": null,
                            "upc": null,
                            "retailPrice": resultVal,
                            "cost": resultVal,
                            "description": taxable ? "TAXABLE ITEM" : "CVS OTC item",
                            "quantity": 1,
                            "taxableItem": taxable ? true : false
                        };
                        if ($scope.voidEarlierItemActive && !$scope.voidEarlierItemDisabled) {
                            // var taxableNonTaxableOrder = OrderFactory.getOtcDataFromTxn();
                            for (var i = 0; i < OrderFactory.getOtcDataFromTxn().length; i++) {
                                if ((OrderFactory.getOtcDataFromTxn()[i].taxableItem === taxable) && (resultVal === OrderFactory.getOtcDataFromTxn()[i].retailPrice)) {
                                    $scope.voidEarlierItemActive = false;
                                    $scope.tempCurrOrder.splice(i, 1);
                                    $scope.updateSecDispPriceList();
                                    return;
                                }
                            }
                        } else {
                            OrderFactory.getTransactionIdData();
                            OrderFactory.getOtcDataFromTxn().push(otcItemSpl);
                            $scope.tempCurrOrder = OrderFactory.getOtcDataFromTxn();
                            $scope.updateSecDispPriceList();
                        }
                    }
                });

            };


            $scope.getEncodedEccNumber = function() {
                var eccNumber = OrderFactory.getEccNumber();
                if (eccNumber && eccNumber.length > 4) {
                    var encodedEccNumber = eccNumber.substr(eccNumber.length - 4, 4);
                    return encodedEccNumber;
                }
                return;
            };


            $scope.showRegenBarcode = function() {
                return OrderFactory.getTotalBarcode();
            };
            /**
             * This method will be called if anything changes on 
             * the left side of the home screen. This is used as
             * a hook to enable/disable any buttons on the home
             * screen as well.
             */
            $scope.updateSecDispPriceList = function() {
                OrderFactory.setTotalBarcode(null);
                $scope.voidEarlierItemDisabled = ($scope.getAllItemsInOrder().length || $scope.minuteClinicDepositsOrder.length) ? false : true;
                if ($scope.voidEarlierItemDisabled && $scope.activePaidOut) {
                    $scope.activePaidOut = null;
                    enableScanListeners();
                    $scope.refundSaleCompleted = false;
                }
                /**
                 * Call the parent scope function to actually update
                 * the secondary display
                 */
                $scope.$parent.updateSecDispPriceList({
                    isRefund: $scope.isRefund
                });
            };

            $scope.doPseInquery = function(barcode) {
                var pseInquiryPromise = PseService.validatePseItems(barcode, null, null);
                pseInquiryPromise.then(function(result) {
                    if (!PseFactory.getIsPSEFlagIsDisplayed()) {
                        PseFactory.setIsPSEFlagIsDisplayed(true);
                        if (result !== null && (result.responseCode == PSE_ERROR_CODE['PSE_SUCESS_CODE'] || result.responseCode == PSE_ERROR_CODE['PSE_SUCESS_WARNING'])) {
                            // PseFactory.setIdentityScanData("");
                            PseFactory.setIdentityInfo(PseService.mergePersonInfo(result.personinfo, PseFactory.getIdentityInfo()));
                            if (result.responseCode == PSE_ERROR_CODE['PSE_SUCESS_WARNING'] && result.warnings && result.warnings.warning && result.warnings.warning.length) {
                                angular.forEach(result.warnings.warning, function(warningItem) {
                                    if (warningItem.code === 'ID EXPIRATION') {
                                        var modalOptions = {
                                            buttons: ['OK'],
                                            headerText: 'Error',
                                            bodyText: 'Scanned ID Expired'
                                        };
                                        DialogService.showDialog({}, modalOptions).then(function(result) {
                                            //Close window
                                        });
                                        return;
                                    }
                                });
                                $location.url("/license-entry");
                            } else {
                                $scope.showPSECustomerDisplay();
                            }
                        } else if (result !== null && result.responseCode == PSE_ERROR_CODE['PSE_FAIL_CODE']) {
                            if (result.personinfo) {
                                PseFactory.setIdentityInfo(PseService.mergePersonInfo(result.personinfo, PseFactory.getIdentityInfo()));
                            }
                            $scope.showPseErrorMessage();
                            $scope.removeControlledItem();
                            $scope.printPSEDecline(result);
                        } else {
                            $scope.showServiceErrorMessage();
                            $scope.removeControlledItem();
                        }

                    } else {
                        if (result !== null && (result.responseCode == PSE_ERROR_CODE['PSE_SUCESS_CODE'] || result.responseCode == PSE_ERROR_CODE['PSE_SUCESS_WARNING'])) {
                            PseFactory.setIdentityInfo(PseService.mergePersonInfo(result.personinfo, PseFactory.getIdentityInfo()));
                            $scope.addControoledItemToHomeBasket();
                        } else if (result !== null && result.responseCode == PSE_ERROR_CODE['PSE_FAIL_CODE']) {
                            if (result.personinfo) {
                                PseFactory.setIdentityInfo(PseService.mergePersonInfo(result.personinfo, PseFactory.getIdentityInfo()));
                            }
                            $scope.showPseErrorMessage();
                            $scope.removeControlledItem();
                            $scope.printPSEDecline(result);
                        } else {
                            $scope.showServiceErrorMessage();
                            $scope.removeControlledItem();
                        }
                    }
                }, function(result) {
                    $scope.showServiceErrorMessage();
                    $scope.removeControlledItem();
                });
            };

            $scope.removeControlledItem = function() {
                var controlledItem = PseFactory.getControlledItem();
                PseFactory.removeFromCurrentOrderList(controlledItem);
                if ($scope.isRefund) {
                    var toRemoveItem = "";
                    angular.forEach(OrderFactory.getOtcDataFromTxn(), function(otcItem, index) {
                        if (otcItem.upc == controlledItem.upc) {
                            toRemoveItem = index;
                        }
                    });
                    if (toRemoveItem) {
                        OrderFactory.getOtcDataFromTxn().splice(toRemoveItem, 1);
                    }
                }
            };
            $scope.printPSEDecline = function(response) {

                var printPseDicline = angular.copy(PseFactory.getPsePrintServiceRequest());
                printPseDicline.PSEDeclineRequest.dailyLimit = "3.6 g";
                printPseDicline.PSEDeclineRequest.maxLimit = "9.0 g";
                printPseDicline.PSEDeclineRequest.days = "30";
                if (response !== null && response.inquirySid) {
                    printPseDicline.PSEDeclineRequest.transaction = response.inquirySid;
                } else {
                    var tempId = appUtils.getCurrentTimestamp() + "";
                    printPseDicline.PSEDeclineRequest.transaction = tempId.substr(0, 7);
                }
                PrintService.doPrint(appConfig.store.services.API.printService.pseDecline, printPseDicline);
            };

            $scope.showPseErrorMessage = function() {
                //If reached PSE purchase limit invoke PSE Decline
                var pseDeclinePromise = PseService.buildPsePurchaseRequest('DECLINE');
                //Pse Item purchase issue
                var modalOptions = PSE_ERROR_MESSAGE['PSE_INQUERY_FAIL'];
                DialogService.showDialog({}, modalOptions).then(function(type) {
                    if (type == 'OK') {
                        if (PseFactory.getCurrentOrderList().length < 1) {
                            PseFactory.clearPSEData();
                        }
                    }
                });
            };

            $scope.showServiceErrorMessage = function() {
                var modalOptions = PSE_ERROR_MESSAGE['PSE_SERVICE_FAIL'];
                DialogService.showDialog({}, modalOptions).then(function(type) {
                    if (type == 'OK') {
                        if (PseFactory.getCurrentOrderList().length < 1) {
                            PseFactory.clearPSEData();
                        }
                    }
                });
            };

            $scope.showServiceErrorMessageForPuchase = function() {
                var modalOptions = PSE_ERROR_MESSAGE['PSE_PURCHASE_ERROR_MESSAGE'];
                DialogService.showDialog({}, modalOptions).then(function(type) {
                    if (type == 'OK') {

                    }
                });
            };
            $scope.showServiceTimeOutMessageForPuchase = function() {
                var modalOptions = PSE_ERROR_MESSAGE['PSE_PURCHASE_TIMEOUT_MESSAGE'];
                DialogService.showDialog({}, modalOptions).then(function(type) {
                    if (type == 'OK') {

                    }
                });
            };
            $scope.showServiceTimeOutMessageForPuchase = function() {
                var modalOptions = PSE_ERROR_MESSAGE['PSE_PURCHASE_TIMEOUT_MESSAGE'];
                DialogService.showDialog({}, modalOptions).then(function(type) {
                    if (type == 'OK') {

                    }
                });
            };


            $scope.totalAmount = function() {
                var orderTotal = 0;
                if ($scope.minuteClinicDepositsOrder.length) {
                    angular.forEach($scope.minuteClinicDepositsOrder, function(item) {
                        orderTotal += parseFloat(item.amount);
                    });
                    return orderTotal.toFixed(2);
                }
                angular.forEach(OrderFactory.getOtcDataFromTxn(), function(otcItem) {
                    if (otcItem.priceModify) {
                        orderTotal += parseFloat(otcItem.modifiedPrice);
                    } else {
                        orderTotal += parseFloat(otcItem.retailPrice);
                    }
                });
                angular.forEach($scope.rxOrder, function(val, key) {
                    if (val.basketItemInfo.fillDisposition && val.basketItemInfo.fillDisposition.priceModify) {
                        orderTotal += parseFloat(val.basketItemInfo.fillDisposition.modifiedPrice);
                    } else {
                        orderTotal += parseFloat(val.basketItemInfo.patPayAmt);
                    }
                });
                orderTotal = orderTotal.toFixed(2);
                return orderTotal;
            };

            $scope.getAllItemsInOrder = function() {
                var allItems = [];
                angular.forEach($scope.rxOrder, function(val, key) {
                    allItems.push(val);
                });
                angular.forEach(OrderFactory.getOtcDataFromTxn(), function(otcItem) {
                    allItems.push(otcItem);
                });
                if (allItems.length) {
                    OrderFactory.setTotalBarcode(null);
                }
                return allItems;
            };

            $scope.voidEarlierItem = function() {
                if (!$scope.voidEarlierItemDisabled) {
                    $scope.voidEarlierItemActive = !$scope.voidEarlierItemActive;
                }
            };

            $scope.goToWeCare = function() {
                if ($scope.minuteClinicDepositsOrder.length || CONFIG.storeData.isOffline || $scope.activePaidOut) {
                    return;
                }
                if ((!$scope.rxOrder && !$scope.tempCurrOrder) || (!$scope.rxOrder.length && !$scope.tempCurrOrder.length)) {
                    $socket.clear();
                }
                if (PatientFactory.getSelectedPatientList() && Object.keys(PatientFactory.getSelectedPatientList()).length) {
                    $location.url('/basket');
                    return;
                }
                $location.url("/patient-lookup");
                $scope.CONFIG.pageTitle = "Patient Lookup";
            };

            var handleFastPass = function(evt, barcode) {
                $scope.fastPassListner(barcode);
            }

            $scope.clearWholeData = function() {
                appUtils.log("HOME: clearing all the data...");

                $scope.clearAllFactories();
                $scope.initializeHome();
                $route.reload();
            };

            $scope.itemLookup = function() {
                if ($scope.minuteClinicDepositsOrder.length || $scope.activePaidOut) {
                    return;
                }
                disableScanListeners();
                NumberEntryService.showDialog({}, {
                    inputText: 'Enter UPC',
                    headerText: 'UPC',
                    cancelConfirm: true
                }).then(function(result) {
                    enableScanListeners();
                    $scope.$broadcast('SCANNED_DATA_OTC', result);
                }, function() {
                    enableScanListeners();
                });
            };
            $scope.skuLookup = function() {
                if ($scope.minuteClinicDepositsOrder.length || $scope.activePaidOut) {
                    return;
                }
                disableScanListeners();
                NumberEntryService.showDialog({}, {
                    inputText: 'Enter SKU',
                    headerText: 'SKU',
                    cancelConfirm: true
                }).then(function(result) {
                    enableScanListeners();
                    $scope.$broadcast('SCANNED_DATA_OTC', result, true);
                }, function() {
                    enableScanListeners();
                });
            };
            $scope.rxscan = function() {
                if ($scope.minuteClinicDepositsOrder.length) {
                    return;
                }
                if ($scope.isRefund || CONFIG.storeData.isOffline) {
                    NumberEntryService.showDialog({}, {
                        inputText: 'Enter Rx',
                        headerText: 'Rx'
                    }).then(function(result) {
                        $scope.$broadcast('SCANNED_DATA_RX', result);
                    });
                }
            };


            var scanOtc = function(evt, barcode, isSku) {
                if ($scope.isMinuteClinicDeposits || $scope.isMaxItem()) {
                    return;
                }
                var param = isSku ? 'SKU' : 'UPC';
                if ($scope.isPriceModify) {
                    $scope.currentOtcItem = {};
                    if ($scope.isRefund) {
                        var modalOptions = {
                            buttons: ['OK'],
                            headerText: 'Error',
                            bodyText: 'Price Modify not allowed'
                        };
                        DialogService.showDialog({}, modalOptions).then(function(result) {});
                        return;
                    }
                    var itemLookUpPromise = Request.invoke({
                        loadMessage: "Looking up item...",
                        url: appConfig.store.services.API.itemLookUp + '/' + '?' + param + '=' + barcode,
                        method: 'GET'
                    });
                    itemLookUpPromise.then(function(result) {
                        if ($scope.getAllItemsInOrder().length === 0) {
                            OrderFactory.getTransactionIdData();
                        }
                        $scope.currentOtcItem = result;
                        if ($scope.currentOtcItem) {
                            $scope.currentOtcItem.scanInd = 'Y';
                            var modalOptions = {
                                buttons: ['Price', 'Percent', 'Cancel'],
                                headerText: '',
                                bodyText: 'Please select method of price modify'
                            };
                            DialogService.showDialog({}, modalOptions).then(function(result) {
                                $scope.isPriceModify = false;
                                if (result == "Price") {
                                    NumberEntryService.showDialog({}, {
                                        inputText: 'Please enter the PRICE to modify <br/>' +
                                            'the item ' + $scope.currentOtcItem.description +
                                            '<br/>Regular Unit price:&nbsp;' + $scope.currentOtcItem.retailPrice,
                                        headerText: 'PRICE MODIFY',
                                        maskCurrency: true
                                    }).then(function(result) {
                                        if (result) {
                                            if ($scope.currentOtcItem.priceModify) {
                                                var modalOptions = {
                                                    buttons: ['OK'],
                                                    headerText: 'Information',
                                                    bodyText: 'PRICE MODIFY NOT<br/>ALLOWED'
                                                };
                                                DialogService.showDialog({}, modalOptions).then(function(result) {

                                                });
                                                return;
                                            }
                                            $scope.currentOtcItem.modifiedPrice = (parseFloat(result) / 100).toFixed(2);

                                            var amount = $scope.currentOtcItem.modifiedPrice;
                                            var modifiedPriceDiff = parseFloat($scope.currentOtcItem.retailPrice) - amount;
                                            if (amount > parseFloat($scope.currentOtcItem.retailPrice)) {
                                                var mOptions = {
                                                    buttons: ['OK'],
                                                    headerText: 'Information',
                                                    bodyText: 'PRICE MODIFY MARKUP<br/>IS NOT ALLOWED'
                                                };
                                                DialogService.showDialog({}, mOptions).then(function(result) {
                                                    $scope.isPriceModify = true;
                                                    $scope.$broadcast('SCANNED_DATA_OTC', barcode, isSku);
                                                });
                                                return;
                                            }

                                            $scope.currentOtcItem.priceModify = true;
                                            if ($scope.currentOtcItem.pseFlag) {
                                                PseFactory.setControlledItem($scope.currentOtcItem);
                                                PseFactory.addControlledItemToCurrentOrderList();
                                                $scope.showPSE();
                                            } else {
                                                $scope.doManagerOverride({
                                                    callback: $scope.otcItemRefundCallback,
                                                    callbackData: {
                                                        currentOtcItem: $scope.currentOtcItem
                                                    },
                                                    type: 'priceModify',
                                                    amount: modifiedPriceDiff
                                                });
                                                return;
                                            }
                                        }
                                    });
                                } else if (result == "Percent") {
                                    NumberEntryService.showDialog({}, {
                                        inputText: 'Please enter the PERCENT OFF to<br/>' +
                                            'modify the item ' + $scope.currentOtcItem.description +
                                            '<br/>Regular Unit price:&nbsp;' + $scope.currentOtcItem.retailPrice,
                                        headerText: 'PERCENT OFF MODIFY'
                                    }).then(function(result) {
                                        if (result) {
                                            result = parseInt(result);
                                            if (result <= 100) {
                                                if ($scope.currentOtcItem.priceModify) {
                                                    var modalOptions = {
                                                        buttons: ['OK'],
                                                        headerText: 'Information',
                                                        bodyText: 'PRICE MODIFY NOT<br/>ALLOWED'
                                                    };
                                                    DialogService.showDialog({}, modalOptions).then(function(result) {

                                                    });
                                                    return;
                                                }
                                                $scope.currentOtcItem.modifiedPrice = ($scope.currentOtcItem.retailPrice - ($scope.currentOtcItem.retailPrice * result) / 100).toFixed(2);
                                                var amount = $scope.currentOtcItem.modifiedPrice;
                                                var modifiedPriceDiff = parseFloat($scope.currentOtcItem.retailPrice) - amount;
                                                $scope.currentOtcItem.priceModify = true;
                                                if ($scope.currentOtcItem.pseFlag) {
                                                    PseFactory.setControlledItem($scope.currentOtcItem);
                                                    PseFactory.addControlledItemToCurrentOrderList();
                                                    $scope.showPSE();
                                                } else {
                                                    $scope.doManagerOverride({
                                                        callback: $scope.otcItemRefundCallback,
                                                        callbackData: {
                                                            currentOtcItem: $scope.currentOtcItem
                                                        },
                                                        type: 'priceModify',
                                                        amount: modifiedPriceDiff
                                                    });
                                                    return;
                                                }
                                            } else {
                                                var modalOptions = {
                                                    buttons: ['OK'],
                                                    headerText: 'Error',
                                                    bodyText: 'Please enter a valid percentage'
                                                };
                                                DialogService.showDialog({}, modalOptions).then(function(result) {});
                                            }
                                        }
                                    });
                                }
                            });
                        }
                    }, function(result, statusCode) {
                        var modalOptions = {
                            buttons: ['OK'],
                            headerText: 'Error',
                            bodyText: result.message
                        };
                        DialogService.showDialog({}, modalOptions).then(function(result) {});
                    });

                } else {
                    $scope.handleOtcItemScan(barcode, isSku);
                }
            };

            $scope.otcItemRefundCallback = function(opts) {
                OrderFactory.getOtcDataFromTxn().push(opts.currentOtcItem);
                $scope.updateSecDispPriceList();
            };
            $scope.handleOtcItemScan = function(barcode, isSku) {
                var param = isSku ? 'SKU' : 'UPC';
                if ($scope.voidEarlierItemActive && !$scope.voidEarlierItemDisabled) {
                    $scope.voidEarlierItemActive = false;
                    var voidItemFound = false;
                    var toRemoveItem = -1;
                    var otcItemToVoid = {};

                    var itemLookUpPromise = Request.invoke({
                        loadMessage: "Looking up item...",
                        url: appConfig.store.services.API.itemLookUp + '/' + '?' + param + '=' + barcode,
                        method: 'GET'
                    });
                    itemLookUpPromise.then(function(result) {
                        angular.forEach(OrderFactory.getOtcDataFromTxn(), function(otcItem, index) {
                            if (isSku) {
                                if (parseInt(otcItem.sku) == parseInt(result.sku)) {
                                    voidItemFound = true;
                                    toRemoveItem = index;
                                    otcItemToVoid = otcItem;
                                }
                            } else {
                                if (parseInt(otcItem.upc) == parseInt(result.upc)) {
                                    voidItemFound = true;
                                    toRemoveItem = index;
                                    otcItemToVoid = otcItem;
                                }
                            }
                        });
                        if (toRemoveItem > -1) {
                            if (otcItemToVoid.pseFlag) {
                                PseFactory.removeFromCurrentOrderList(otcItemToVoid);
                            }
                            OrderFactory.getOtcDataFromTxn().splice(toRemoveItem, 1);
                            if ($scope.isRefund && !OrderFactory.getOtcDataFromTxn().length) {
                                $scope.isRefund = false;
                            }
                        }
                        $scope.updateSecDispPriceList();
                    }, function(result, statusCode) {
                        var modalOptions = {
                            buttons: ['OK'],
                            headerText: '',
                            bodyText: 'Item not found in current transaction'
                        };
                        DialogService.showDialog({}, modalOptions).then(function(result) {});
                    });
                    $scope.updateSecDispPriceList();
                } else {
                    //if OrderFactory having trasaction data no need to call the same service.
                    OrderFactory.getTransactionIdData();
                    var itemLookUpPromise = Request.invoke({
                        loadMessage: "Looking up item...",
                        url: appConfig.store.services.API.itemLookUp + '/' + '?' + param + '=' + barcode,
                        method: 'GET'
                    });
                    itemLookUpPromise.then(function(result) {
                        var otcItem = result;
                        otcItem.scanInd = 'Y';
                        if ($scope.isRefund) {
                            var amount = otcItem.retailPrice;
                            otcItem.retailPrice = -(otcItem.retailPrice);
                            if (otcItem.pseFlag) {
                                if (CONFIG.pseConfig.pseRefundBlocked && CONFIG.pseConfig.pseRefundBlocked === 'Y') {
                                    DialogService.showDialog({}, {
                                        buttons: ['OK'],
                                        headerText: 'Error',
                                        bodyText: "PSE items cannot be refunded in this store"
                                    }).then(function(selection) {
                                        return;
                                    });
                                } else {
                                    PseFactory.setPseRefundPayCompleted($scope.refundSaleCompleted);
                                    PseFactory.setIsPseRefund(true);
                                    PseFactory.setControlledItem(otcItem);
                                    PseFactory.addControlledItemToCurrentOrderList();
                                    $scope.showPSE();
                                }
                            } else {
                                $scope.doManagerOverride({
                                    callback: $scope.otcItemRefundCallback,
                                    callbackData: {
                                        currentOtcItem: otcItem
                                    },
                                    type: 'refund',
                                    amount: amount
                                });
                                return;
                            }
                        } else {
                            if (otcItem.pseFlag) {
                                PseFactory.setControlledItem(otcItem);
                                PseFactory.addControlledItemToCurrentOrderList();
                                $scope.showPSE();
                            } else {
                                OrderFactory.getOtcDataFromTxn().push(otcItem);
                                $scope.tempCurrOrder = OrderFactory.getOtcDataFromTxn();
                            }
                        }
                        $scope.updateSecDispPriceList();
                    }, function(result, statusCode) {
                        var modalOptions = {
                            buttons: ['OK'],
                            headerText: 'Error',
                            bodyText: result.message
                        };
                        DialogService.showDialog({}, modalOptions).then(function(result) {});
                    });
                }
            };

            var handleRxScan = function(evt, barcode) {
                if ($scope.isMinuteClinicDeposits || $scope.isMaxItem()) {
                    return;
                }
                if ($scope.isPriceModify && $scope.rxOrder.length === 0) {
                    var modalOptions = {
                        buttons: ['OK'],
                        headerText: 'Error',
                        bodyText: 'Price Modify not allowed'
                    };
                    DialogService.showDialog({}, modalOptions).then(function(result) {});
                    return;
                }

                if ($scope.isRefund || $scope.isOffline || ($scope.voidEarlierItemActive &&
                        !$scope.voidEarlierItemDisabled) || $scope.isPriceModify) {
                    OrderFactory.getTransactionIdData();
                    var payload = {
                        RxInfoRequest: {
                            barCode: barcode,
                            storeNumber: CONFIG.storeNumber,
                            screenId: 1234,
                            /////////////////////////////////////////////////////////////
                            // 'R' is for Refunds. Since we just need the barcode for  //
                            // getting the Rx number and fill sequence number, we      //
                            // can use 'R' for Voiding the transaction as well         //
                            /////////////////////////////////////////////////////////////
                            transactionType: 'R'
                        }
                    };
                    if ($scope.isOffline || $scope.isPriceModify) {
                        payload.RxInfoRequest.transactionType = "S";
                        payload.RxInfoRequest.patientProfileList = BasketFactory.getRxOrderData();
                    }

                    var rxScanPromise = Request.invoke({
                        url: appConfig.store.services.API.rxScan,
                        method: 'POST',
                        data: payload
                    });
                    rxScanPromise.then(function(result) {
                        if (result) {
                            var fillInfo = result;
                            /**
                             * Check if the void earlier transaction is active and not 
                             * disabled. If it is, then remove the item from transaction.
                             * If it is not, then it is offline scenario
                             */
                            if ($scope.voidEarlierItemActive && !$scope.voidEarlierItemDisabled) {
                                voidRxFromSale(fillInfo, barcode);
                            } else {
                                if ($scope.isOffline && !$scope.isRefund && !$scope.isPriceModify && !$scope.isPriceVerify) {
                                    var offlineFillInfo = fillInfo;
                                    fillInfo = fillInfo.patientFillInfo;
                                    var modalOptions = {
                                        buttons: ['Cancel', 'C', 'N', 'No letter'],
                                        headerText: 'State Regulatory Information',
                                        bodyText: 'Please select the letter preceding the Prescription number on the receipt'
                                    };
                                    DialogService.showDialog({}, modalOptions).then(function(resultInner) {
                                        var offlinePPRMsgInfo = BasketFactory.getOfflineProfile().patientMessageInfo || {};

                                        if (resultInner === 'C' || resultInner === 'N') {
                                            offlinePPRMsgInfo.srdMsg = offlinePPRMsgInfo.srdMsg || [];
                                            var messageItem = {
                                                disposition: null,
                                                mandatory: null,
                                                notDisplayedReason: null,
                                                timestamp: null,
                                                messageType: 8,
                                                rxNum: fillInfo.rxNum,
                                                refilNum: fillInfo.refillNum,
                                                pFillSeqNum: fillInfo.partialFillSeqNum,
                                                editVersionNum: fillInfo.editVersionNum,
                                                rxPatientId: CONFIG.offlinePatId,
                                                msgSeq: appUtils.getRandomNumber(4),
                                                messageConfig: null,
                                                markDisplayed: false,
                                                state: DAILY_CONFIG.SRDRulesConfig.SRDRulesConfig.state[0].code,
                                                dea: (resultInner == 'C') ? "C3" : "C2",
                                                pickupCaptureIndicator: 'P',
                                                patientCaptureIndicator: 'P',
                                                progType: "1"
                                            };

                                            offlinePPRMsgInfo.srdMsg.push(messageItem);
                                            BasketFactory.getOfflineProfile().patientMessageInfo = offlinePPRMsgInfo;
                                            $scope.tpComplianceMessageAction(BasketFactory.getOfflineProfile(), offlineFillInfo);

                                        } else if (resultInner === 'No letter') {
                                            BasketFactory.getOfflineProfile().patientMessageInfo = offlinePPRMsgInfo;
                                            $scope.tpComplianceMessageAction(BasketFactory.getOfflineProfile(), offlineFillInfo);
                                        } else if (resultInner === 'Cancel') {
                                            return;
                                        }
                                        var patFillList = BasketFactory.getOfflineProfile().patientFillInfoList || [];
                                        patFillList.push(fillInfo);
                                        BasketFactory.getOfflineProfile().patientFillInfoList = patFillList;

                                        fillInfo.fillDisposition = {
                                            dispositionKey: 'SLD',
                                            disposition: 1,
                                            scanInd: 'Y',
                                            taxCollected: 0,
                                            userId: CONFIG.loggedInUser.id,
                                            lineVoidedLater: 'N',
                                            modifiedPrice: null,
                                            fillLevel: 'N',
                                            locationOfRx: 'WB',
                                            voidedTransactionNumber: null,
                                            priceSource: 'T',
                                            barcode: barcode
                                        };

                                        var rxItemInOrder = {
                                            basketItemInfo: fillInfo
                                        };
                                        $scope.rxOrder[barcode] = rxItemInOrder;
                                        MessageFactory.setIsOfflineMessagingDone(false);
                                        $scope.updateSecDispPriceList();
                                    });
                                }
                                if ($scope.isPriceModify) {
                                    var modalOptions = {
                                        buttons: ['Price', 'Percent', 'Cancel'],
                                        headerText: '',
                                        bodyText: 'Please select method of price modify'
                                    };
                                    DialogService.showDialog({}, modalOptions).then(function(result) {
                                        $scope.isPriceModify = false;
                                        if (result == "Price") {
                                            //console.log("Inside Price ");
                                            var currentItem = $scope.rxOrder[barcode];
                                            NumberEntryService.showDialog({}, {
                                                inputText: 'Please enter the PRICE to modify <br/>' +
                                                    'the item ' + currentItem.basketItemInfo.drugDesc +
                                                    '<br/>Regular Unit price:&nbsp;' + currentItem.basketItemInfo.patPayAmt,
                                                headerText: 'PRICE MODIFY',
                                                maskCurrency: true
                                            }).then(function(result) {
                                                if (result) {
                                                    var currentItem = $scope.rxOrder[barcode];
                                                    if (currentItem) {
                                                        if (currentItem.basketItemInfo.fillDisposition.priceModify) {
                                                            var modalOptions = {
                                                                buttons: ['OK'],
                                                                headerText: 'Information',
                                                                bodyText: 'PRICE MODIFY NOT<br/>ALLOWED'
                                                            };
                                                            DialogService.showDialog({}, modalOptions).then(function(result) {

                                                            });
                                                            return;
                                                        }
                                                        var modifiedPrice = (parseFloat(result) / 100).toFixed(2);
                                                        if (modifiedPrice > parseFloat(currentItem.basketItemInfo.patPayAmt)) {
                                                            var mOptions = {
                                                                buttons: ['OK'],
                                                                headerText: 'Information',
                                                                bodyText: 'PRICE MODIFY MARKUP<br/>IS NOT ALLOWED'
                                                            };
                                                            DialogService.showDialog({}, mOptions).then(function(result) {

                                                            });
                                                            return;
                                                        }
                                                        var modifiedPriceDiff = parseFloat(currentItem.basketItemInfo.patPayAmt) - modifiedPrice;
                                                        $scope.doManagerOverride({
                                                            callback: $scope.rxItemPriceModifyCallback,
                                                            callbackData: {
                                                                currentItem: currentItem,
                                                                modifiedPrice: modifiedPrice
                                                            },
                                                            type: 'priceModify',
                                                            amount: modifiedPriceDiff
                                                        });
                                                        // currentItem.basketItemInfo.fillDisposition.modifiedPrice = (parseFloat(result) / 100).toFixed(2);
                                                        // currentItem.basketItemInfo.fillDisposition.priceModify = true;
                                                        // $scope.updateSecDispPriceList();
                                                    }
                                                }
                                            });
                                        } else if (result == "Percent") {
                                            var currentItem = $scope.rxOrder[barcode];
                                            NumberEntryService.showDialog({}, {
                                                inputText: 'Please enter the PERCENT OFF to modify <br/>' +
                                                    'the item ' + currentItem.basketItemInfo.drugDesc +
                                                    '<br/>Regular Unit price:&nbsp;' + currentItem.basketItemInfo.patPayAmt,
                                                headerText: 'PERCENT OFF MODIFY'
                                            }).then(function(result) {
                                                if (result) {
                                                    result = parseInt(result);
                                                    if (result <= 100) {
                                                        var currentItem = $scope.rxOrder[barcode];
                                                        if (currentItem) {
                                                            if (currentItem.basketItemInfo.fillDisposition.priceModify) {
                                                                var modalOptions = {
                                                                    buttons: ['OK'],
                                                                    headerText: 'Information',
                                                                    bodyText: 'PRICE MODIFY NOT<br/>ALLOWED'
                                                                };
                                                                DialogService.showDialog({}, modalOptions).then(function(result) {});
                                                                return;
                                                            }
                                                            var modifiedPrice = (currentItem.basketItemInfo.patPayAmt - (currentItem.basketItemInfo.patPayAmt * result) / 100).toFixed(2);
                                                            var modifiedPriceDiff = parseFloat(currentItem.basketItemInfo.patPayAmt) - modifiedPrice;
                                                            $scope.doManagerOverride({
                                                                callback: $scope.rxItemPriceModifyCallback,
                                                                callbackData: {
                                                                    currentItem: currentItem,
                                                                    modifiedPrice: modifiedPrice
                                                                },
                                                                type: 'priceModify',
                                                                amount: modifiedPriceDiff
                                                            });
                                                            // currentItem.basketItemInfo.fillDisposition.modifiedPrice = (currentItem.basketItemInfo.patPayAmt - (currentItem.basketItemInfo.patPayAmt * result) / 100).toFixed(2);
                                                            // currentItem.basketItemInfo.fillDisposition.priceModify = true;
                                                            // $scope.updateSecDispPriceList();
                                                        }
                                                    } else {
                                                        var modalOptions = {
                                                            buttons: ['OK'],
                                                            headerText: 'Error',
                                                            bodyText: 'Please enter a valid percentage'
                                                        };
                                                        DialogService.showDialog({}, modalOptions).then(function(result) {});
                                                    }
                                                }
                                            });

                                        }
                                    });
                                }
                                //////////////////////////////
                                // process Refund scenario. //
                                //////////////////////////////
                                if ($scope.isRefund) {
                                    processRefundForFill(fillInfo, barcode);
                                }
                            }
                        }
                    }, function(result, statusCode) {
                        var modalOptions = {
                            buttons: ['Okay'],
                            headerText: 'Error',
                            bodyText: result.moreInfo
                        };
                        DialogService.showDialog({}, modalOptions).then(function(result) {});
                    });
                } else {
                    $location.url('/patient-lookup');
                }

                var voidRxFromSale = function(fillInfo, barcode) {

                    fillInfo = fillInfo.patientFillInfo ? fillInfo.patientFillInfo : fillInfo;

                    $scope.voidEarlierItemActive = false;
                    var voidRxFound = false;
                    var offlineFillIndex = -1;
                    angular.forEach(BasketFactory.getBasketData(), function(patProfile, patientId) {
                        angular.forEach(patProfile.patientFillInfoList, function(patFillDetail, index) {
                            if ($scope.buildPartialRxbarcode(fillInfo) ==
                                $scope.buildPartialRxbarcode(patFillDetail)) {
                                voidRxFound = true;
                                offlineFillIndex = index;
                                //New disposition
                                patFillDetail.fillDisposition.disposition = 3;
                                patFillDetail.fillDisposition.dispositionKey = 'HWB';
                                patFillDetail.fillDisposition.scanInd = 'Y';
                                patFillDetail.fillDisposition.taxCollected = 0;
                                patFillDetail.fillDisposition.userId = CONFIG.loggedInUser.id;
                                patFillDetail.fillDisposition.lineVoidedLater = 'N'; //this is mandatory filed Y or N, value becomes Y when you do price modify
                                patFillDetail.fillDisposition.fillLevel = 'N'; //Passing N for now
                                patFillDetail.fillDisposition.locationOfRx = 'WB'; //Need various possible values
                                patFillDetail.fillDisposition.voidedTransactionNumber = CONFIG.TxnNum; //
                                patFillDetail.fillDisposition.priceSource = 'T'; //T-RxConnect, B-Bar Code, P-Price Modify, M-Manual Ring, N-Source Not Set (Used for line-void)                                                        
                            }
                        });
                    });

                    if (($scope.isRefund || CONFIG.storeData.isOffline) && $scope.rxOrder[barcode]) {
                        if (offlineFillIndex > -1)
                            BasketFactory.getOfflineProfile().patientFillInfoList.splice(offlineFillIndex, 1);
                    }

                    if (!voidRxFound) {
                        var modalOptions = {
                            buttons: ['OK'],
                            headerText: 'Error',
                            bodyText: 'Prescription not found in current order'
                        };
                        DialogService.showDialog({}, modalOptions).then(function(result) {});
                    } else {
                        delete $scope.rxOrder[barcode];
                    }
                    $scope.updateSecDispPriceList();
                };

                var processRefundForFill = function(fillInfo, barcode) {
                    if (CONFIG.storeData.isOffline) {
                        fillInfo = fillInfo.patientFillInfo;
                    }

                    //Disposition
                    fillInfo.fillDisposition.disposition = 1;
                    fillInfo.fillDisposition.scanInd = 'Y';
                    fillInfo.fillDisposition.taxCollected = 0;
                    fillInfo.fillDisposition.userId = CONFIG.loggedInUser.id;
                    fillInfo.fillDisposition.lineVoidedLater = 'N'; //this is mandatory filed Y or N, value becomes Y when you do price modify
                    fillInfo.fillDisposition.fillLevel = 'N'; //Passing N for now
                    fillInfo.fillDisposition.voidedTransactionNumber = null; //
                    fillInfo.fillDisposition.priceSource = 'T'; //T-RxConnect, B-Bar Code, P-Price Modify, M-Manual Ring, N-Source Not Set (Used for line-void)                                                        

                    var amount = fillInfo.patPayAmt;
                    fillInfo.patPayAmt = -(fillInfo.patPayAmt);
                    $scope.doManagerOverride({
                        callback: $scope.rxItemRefundCallback,
                        callbackData: {
                            fillInfo: fillInfo,
                            barcode: barcode
                        },
                        type: 'refund',
                        amount: amount,
                        isRx: true
                    });
                };
            };

            $scope.rxItemPriceModifyCallback = function(opts) {
                if (opts) {
                    opts.currentItem.basketItemInfo.fillDisposition.modifiedPrice = opts.modifiedPrice;
                    opts.currentItem.basketItemInfo.fillDisposition.priceModify = true;
                    $scope.updateSecDispPriceList();
                }
            };

            $scope.doManagerOverride = function(opts, skipAlert) {
                var managerOverrideFor = "refund";
                opts = opts ? opts : {};
                opts.type = opts.type ? opts.type : 'refund';
                var thAmount = null;
                if (opts.type == 'priceModify') {
                    managerOverrideFor = "price modify";
                    thAmount = 5;
                } else {
                    thAmount = 10;
                }
                if (parseFloat(opts.amount) > thAmount) {
                    if (skipAlert) {
                        var managerOverridePromise = ManagerOverrideService.doManagerOverride({
                            usernameHeaderText: 'Manager Override',
                            usernameInputTextHelp: 'Enter Manager ID Number',
                            passwordHeaderText: 'Manager Override',
                            passwordInputTextHelp: 'Enter Password',
                            usernameCancelConfirm: true,
                            passwordCancelConfirm: true
                        });
                        managerOverridePromise.then(function(result) {
                            opts.callback && opts.callback(opts.callbackData);
                        }, function(empNotOnFile) {
                            if (empNotOnFile)
                                $scope.doManagerOverride(opts, true);
                        });
                    } else {
                        var modalOptions = {
                            buttons: ['OK'],
                            headerText: 'Information',
                            bodyText: opts.isRx ? 'To continue with prescription ' + managerOverrideFor + ', manager override required' : 'To continue with OTC ' + managerOverrideFor + ', manager override required'
                        };
                        var showDialog = DialogService.showDialog({}, modalOptions).then(function(type) {
                            var managerOverridePromise = ManagerOverrideService.doManagerOverride({
                                usernameHeaderText: 'Manager Override',
                                usernameInputTextHelp: 'Enter Manager ID Number',
                                passwordHeaderText: 'Manager Override',
                                passwordInputTextHelp: 'Enter Password',
                                usernameCancelConfirm: true,
                                passwordCancelConfirm: true
                            });
                            managerOverridePromise.then(function(result) {
                                opts.callback && opts.callback(opts.callbackData);
                            }, function(empNotOnFile) {
                                if (empNotOnFile)
                                    $scope.doManagerOverride(opts, true);
                            });
                        });
                    }

                } else {
                    opts.callback && opts.callback(opts.callbackData);
                }
            };

            $scope.rxItemRefundCallback = function(opts) {
                var rxItemInOrder = {
                    basketItemInfo: opts.fillInfo
                };
                $scope.rxOrder[opts.barcode] = rxItemInOrder;
                var fillsList = BasketFactory.getOfflineProfile().patientFillInfoList || [];
                fillsList.push(opts.fillInfo);
                BasketFactory.getOfflineProfile().patientFillInfoList = fillsList;
                $scope.updateSecDispPriceList();
            };

            var handleSplRxScan = function(evt, barcode) {
                appUtils.log("Rx Speciality Drug Scanned...");
                if ($scope.isPriceModify) {
                    var modalOptions = SPECIALTY_ORDER_MESSAGE['SPECIALTY_PRICE_MODIFIY_ERROR'];
                    DialogService.showDialog({}, modalOptions).then(function(result) {
                        //Close window
                    });
                } else if ($scope.isRefund) {
                    var modalOptions = SPECIALTY_ORDER_MESSAGE['SPECIALTY_REFUND_ITEM_ERROR'];
                    DialogService.showDialog({}, modalOptions).then(function(result) {
                        //Close window
                    });
                } else if ($scope.voidEarlierItemActive) {
                    var modalOptions = SPECIALTY_ORDER_MESSAGE['SPECIALTY_VOID_ITEM_ERROR'];
                    DialogService.showDialog({}, modalOptions).then(function(result) {
                        //Close window
                    });
                } else {
                    $location.url('/patient-lookup');
                }
            };


            $scope.tpComplianceMessageAction = function(patientProfile, offlineFillInfo) {
                if (offlineFillInfo.tpComplianceMsg && ((offlineFillInfo.tpComplianceMsg.formsProvided &&
                            offlineFillInfo.tpComplianceMsg.formsProvided != 'NIL') ||
                        (offlineFillInfo.tpComplianceMsg.formsSigned.formType &&
                            offlineFillInfo.tpComplianceMsg.formsSigned.formType.length &&
                            offlineFillInfo.tpComplianceMsg.formsSigned.formType[0] != 'NIL'))) {

                    offlineFillInfo.tpComplianceMsg.disposition = 1; //set the disposition

                    // Add the TPCompliance message from the service response
                    // to the patient profile.
                    var pProfileMsg = patientProfile.patientMessageInfo;
                    pProfileMsg.tpComplianceMsg = pProfileMsg.tpComplianceMsg || [];
                    pProfileMsg.tpComplianceMsg.push(offlineFillInfo.tpComplianceMsg);

                    $modal.open({
                        templateUrl: 'views/modals/medicare_form.html',
                        keyboard: false,
                        windowClass: 'modal-dialog-full',
                        controller: 'BasketLevelMessages',
                        backdrop: false,
                        resolve: {
                            'data': function() {
                                return {
                                    basketItemInfo: offlineFillInfo.patientFillInfo,
                                    patientInfo: patientProfile,
                                    messageDetails: offlineFillInfo.tpComplianceMsg,
                                    tpComplinceConfig: offlineFillInfo.tpComplianceMsgConfig,
                                    callback: angular.noop
                                };
                            }
                        }
                    });
                }
            };

            $scope.rowSelectPatient = function(event, index, item) {
                $scope.selectedRowIndex = index;
                $scope.selectPatientRowItem = item;
                $scope.continueKeyActive = true;
            };

            $scope.selectPatientToContinue = function() {
                if (!$scope.continueKeyActive) {
                    return;
                }
                getExtraCareInfoByCardNo($scope.selectPatientRowItem.encoded_extra_card_nbr);

            };

            var getExtraCareInfoByCardNo = function(extracareNo) {

                var extraCarelookUpPromise = OrderFactory.getEccInfoByCardNo(extracareNo);
                extraCarelookUpPromise.then(function(result) {
                    PatientFactory.setExtraCareInfoByCardno(result);
                    OrderFactory.setEccNumber(extracareNo);

                    $location.url('/home');
                }, function(result) {
                    var modalOptions = {
                        buttons: ['OK'],
                        headerText: 'Error',
                        bodyText: 'ExtraCare Card Scan Error'
                    };
                    DialogService.showDialog({}, modalOptions).then(function(result) {});
                });
            };

            $scope.extraCareLookUp = function() {
                appUtils.log("lookup up by phone  number");
                if (!CONFIG.txnInfo.transactionNumber) {
                    OrderFactory.getTransactionIdData();
                }
                $location.url('/phone-lookup');
            };


            $scope.cancelEccPhoneLookup = function() {
                $location.url('/home');
            };

            $scope.extraCareLookupCancel = function() {
                var modalOptions = {
                    buttons: ['Yes', 'No'],
                    headerText: 'Cancel',
                    bodyText: 'Are you sure you want to cancel the operation'
                };
                DialogService.showDialog({}, modalOptions).then(function(result) {
                    if (result == "Yes") {
                        $location.url('/home');
                    }
                });
            };

            $scope.lookUpByPhone = function(inputvalue) {
                if ($scope.minuteClinicDepositsOrder.length) {
                    return;
                }
                var q = 'phone=' + inputvalue;
                var lookUpByPhonePromise = Request.invoke({
                    loadMessage: "Looking up phone number...",
                    url: appConfig.store.services.API.extraCareLookUp + '?' + q,
                    method: 'GET'
                });
                lookUpByPhonePromise.then(function(result) {
                    // $scope.patientListByPhone = result;
                    PatientFactory.setPatientListByPhone(result);

                    if (result) {
                        if (result.length === 0) {
                            var empModalOptions = {
                                buttons: ['Okay'],
                                headerText: '!',
                                bodyText: 'Phone number not found.'
                            };
                            DialogService.showDialog({}, empModalOptions).then(function(result) {
                                appUtils.log(result);
                            });
                        } else if (result.length === 1) {
                            $scope.selectPatientRowItem = result[0];
                            getExtraCareInfoByCardNo($scope.selectPatientRowItem.encoded_extra_card_nbr);
                        } else {
                            $location.url('/patient-list-by-phone');
                        }
                    } else {
                        var empModalOptions = {
                            buttons: ['Okay'],
                            headerText: 'Error',
                            bodyText: 'Customer not found.'
                        };
                        DialogService.showDialog({}, empModalOptions);
                    }
                }, function(result) {
                    appUtils.log('phone number NOT FOUND');
                    var modalOptions = {
                        buttons: ['OK'],
                        headerText: 'Error',
                        bodyText: 'Error in CRM service, Please try again later'
                    };
                    DialogService.showDialog({}, modalOptions).then(function(result) {});
                });
            };

            $scope.onScreenClickPhoneLookUp = function(inputvalue) {
                $scope.lookUpByPhone(inputvalue);
            };
            $scope.doPsePerchase = function() {
                if (PseFactory.getCurrentOrderList().length >= 1) {
                    if (!$scope.isRefund) {
                        var psePurchasePromise = PseService.buildPsePurchaseRequest('PURCHASE');

                        psePurchasePromise.then(function(result) {
                            PseFactory.setIsPSEFlagIsDisplayed(true);
                            //PseFactory.setPsePurchaseRequestPayload(result);
                            if (result != null && (result.responseCode == PSE_ERROR_CODE['PSE_SUCESS_CODE'] || result.responseCode == PSE_ERROR_CODE['PSE_SUCESS_WARNING'])) {
                                $scope.isPserPurchaseIsCompleted = true;
                                $scope.getTotal();
                            } else if (result != null && result.responseCode == PSE_ERROR_CODE['PSE_FAIL_CODE']) {
                                $scope.showServiceErrorMessageForPuchase();
                            } else if (result != null && result.responseCode == PSE_ERROR_CODE['PSE_TIMEOUT_CODE']) {
                                PseService.buildPsePurchaseRequest('DECLINE_ALL');
                                $scope.showServiceTimeOutMessageForPuchase();

                            }
                        }, function(result) {
                            $scope.showServiceErrorMessage();
                            $scope.removeControlledItem();
                        });
                    } else {
                        var psePurchasePromise = PseService.buildPseReturnPurchaseRequest();
                        psePurchasePromise.then(function(result) {
                            if (result != null && (result.responseCode == PSE_ERROR_CODE['PSE_SUCESS_CODE'] || result.responseCode == PSE_ERROR_CODE['PSE_SUCESS_WARNING'])) {
                                $scope.isPserPurchaseIsCompleted = true;
                                $scope.getTotal();
                            } else if (result != null && result.responseCode == PSE_ERROR_CODE['PSE_FAIL_CODE']) {
                                $scope.showServiceErrorMessageForPuchase();

                            }
                        }, function(result) {
                            $scope.showServiceErrorMessage();
                        });
                    }
                } else {
                    $scope.getTotal();
                }
                return;
            };

            $scope.getTotal = function() {
                LOGGER.info('Home Page > ACTION:TOTAL > FUNCTION:getTotal > TXN_TYPE:' + ($scope.isRefund ? 'REFUND' : 'SALE'), loggerName);
                var payload;
                if ($scope.isOffline && !MessageFactory.getIsOfflineMessagingDone() &&
                    BasketFactory.getOfflineProfile().patientFillInfoList &&
                    BasketFactory.getOfflineProfile().patientFillInfoList.length && !$scope.isRefund) {
                    CONFIG.messages.txnStartTimestamp = appUtils.getCurrentTimestamp();
                    var data = {
                        patientProfileListResponse: {
                            patientProfileList: BasketFactory.getRxOrderData()
                        }
                    };
                    alert('Need code change as per new message framework compile messages url doesnt exist any more')
                        //Compile Messages API Invocation
                    var compileMessagesPromise = Request.invoke({
                        url: appConfig.store.services.API.compileMessages,
                        method: 'POST',
                        data: data
                    });
                    compileMessagesPromise.then(
                        function(result) {
                            MessageFactory.setTmplNameOld(null);
                            MessageFactory.getNextMessage(BasketFactory.getRxOrderData());
                        },
                        function(result) {
                            //Error
                        });
                    // ESignFactory.showEsign();

                    return;
                }


                if ($scope.minuteClinicDepositsOrder.length) {
                    payload = {
                        "TransactionObject": {
                            "transactionId": OrderFactory.getTransactionIdData().transactionId,
                            "transactionNumber": OrderFactory.getTransactionIdData().transactionNumber,
                            "transactionType": !$scope.isRefund ? "S" : "R",
                            "minitClinicTransaction": {}
                        }
                    };
                    for (var i = 0; i < $scope.minuteClinicDepositsOrder.length; i++) {
                        if (!payload.TransactionObject.minitClinicTransaction[$scope.minuteClinicDepositsOrder[i].key]) {
                            payload.TransactionObject.minitClinicTransaction[$scope.minuteClinicDepositsOrder[i].key] = 0;
                        }
                        payload.TransactionObject.minitClinicTransaction[$scope.minuteClinicDepositsOrder[i].key] += parseFloat($scope.minuteClinicDepositsOrder[i].amount);
                    }
                    var totalPromise = Request.invoke({
                        url: appConfig.store.services.API.minuteClinic,
                        method: 'POST',
                        data: payload,
                        timeout: 20000
                    });
                    $socket.clear();

                    totalPromise.then(
                        function(data, statusCode, moreInfo) {
                            if (data && data.image) {
                                var minuteClinicPrintData = {
                                    "MinuteClinicRequest": {
                                        "register": CONFIG.registerId,
                                        "transactionNumber": OrderFactory.getTransactionIdData().transactionNumber,
                                        "storeNumber": CONFIG.storeData.number,
                                        "empId": CONFIG.loggedInUser.id,
                                    }
                                };
                                if (payload.TransactionObject.minitClinicTransaction.cashAmount) {
                                    minuteClinicPrintData.MinuteClinicRequest.cashAmount = (payload.TransactionObject.minitClinicTransaction.cashAmount).toFixed(2);
                                }
                                if (payload.TransactionObject.minitClinicTransaction.checkAmount) {
                                    minuteClinicPrintData.MinuteClinicRequest.checkAmount = (payload.TransactionObject.minitClinicTransaction.checkAmount).toFixed(2);
                                }
                                PrintService.doPrint(appConfig.store.services.API.printService.minitclinicDeposits, minuteClinicPrintData);
                                // var newPhrenroll = BasketFactory.getNewPhrEnrollment();
                                // if (newPhrenroll) {
                                //     var phrConfirmationData = {
                                //         "PHREnrollmentConfirmationRequest": {
                                //             "prescriptionNumber": 10,
                                //             "rewardAmount": 5,
                                //             "cardNumber": OrderFactory.getEccNumber()
                                //         }
                                //     }
                                //     PrintService.doPrint(appConfig.store.services.API.printService.phrConfirmation, phrConfirmationData);
                                // }
                                OrderFactory.startNewTxn();
                                OrderFactory.setTotalBarcode(data);
                                $modal.open({
                                    templateUrl: 'views/modals/barcode.html',
                                    keyboard: false,
                                    backdrop: false,
                                    size: 'sm',
                                    windowClass: 'total-popup',
                                    controller: 'barcodeCtl',
                                    resolve: {
                                        data: function() {
                                            return {
                                                totalQRCode: ('data:image/png;base64,' + data.image),
                                                recheckStatus: $scope.recheckRxConnectStatus
                                            };
                                        }
                                    }
                                });
                                $scope.clearWholeData();
                            } else {
                                var modalOptions = {
                                    buttons: ['OK'],
                                    headerText: 'Success',
                                    bodyText: CONFIG.lastCallResponse.moreInfo || 'Transaction completed successfully.'
                                };
                                DialogService.showDialog({}, modalOptions).then(function(result) {
                                    $scope.clearWholeData();
                                    $scope.recheckRxConnectStatus();
                                });
                            }
                        },
                        function(data) {
                            $scope.clearWholeData();
                            OrderFactory.startNewTxn();
                            var modalOptions = {
                                buttons: ['OK'],
                                headerText: 'Error',
                                bodyText: 'Unable to process at this time, please try again later'
                            };
                            DialogService.showDialog({}, modalOptions).then(function(result) {
                                if (result === 'OK') {}
                            });
                        });
                    return;
                }

                if ($scope.activePaidOut && $scope.tempCurrOrder.length) {
                    var total = -(parseFloat($scope.totalAmount()));
                    if (total > CONFIG.MAXIMUM_LIMIT.paidOutsLimit) {
                        var modalOptions = {
                            buttons: ['OK'],
                            headerText: 'Error',
                            bodyText: CONFIG.paidOuts[$scope.activePaidOut].viewData.thresholdValueAlertText
                        };
                        DialogService.showDialog({}, modalOptions).then(function(result) {});
                        return;
                    }
                }

                if (($scope.tempCurrOrder && $scope.tempCurrOrder.length) || ($scope.rxOrder && (Object.keys($scope.rxOrder).length))) {

                    var url = appConfig.store.services.API.total;
                    //Paid outs are one kind of refunds as per requirement
                    if ($scope.isRefund || $scope.activePaidOut) {
                        url = appConfig.store.services.API.refund;
                        payload = {
                            TransactionObject: {
                                transactionId: OrderFactory.getTransactionIdData().transactionId,
                                transactionNumber: OrderFactory.getTransactionIdData().transactionNumber,
                                paymentcompleted: $scope.refundSaleCompleted,
                                //need to remove transactiontype value
                                transactionType: 'R',
                                dispositonInfo: {
                                    RegisterNum: CONFIG.registerId,
                                    TxnNum: appUtils.getCurrentTimestamp(CONFIG.transationTimeFormat),
                                    POSTenderType: "Cash",
                                    DispositionId: "20150701152500429",
                                    UserId: CONFIG.loggedInUser.id,
                                    totalTransactionCount: null,
                                    TxnStrtTym: appUtils.getCurrentTimestamp(),
                                    TxnEndTym: appUtils.getCurrentTimestamp(),
                                    FillsSold: 1,
                                    FillNotSold: 0,
                                    MsgDisp: 0,
                                    MsgNotDisp: 0,
                                    OffInd: "N",
                                    OTCcount: OrderFactory.getOtcDataFromTxn() && OrderFactory.getOtcDataFromTxn().length,
                                    SaleTymStmp: appUtils.getCurrentTimestamp(),
                                    WaiterInd: "N",
                                    POSCounselLocation: "1"
                                },
                                patientProfileList: BasketFactory.getRxOrderData(),
                                storeItemList: OrderFactory.getOtcDataFromTxn(),
                                miscInfo: null
                            }
                        };
                        if (!Object.keys($scope.rxOrder).length) {
                            delete payload.TransactionObject.patientProfileList;
                        }
                    } else {
                        if ($scope.resolveExtracareHealthRewards()) {
                            return;
                        }
                        payload = {
                            TransactionObject: {
                                transactionId: OrderFactory.getTransactionIdData().transactionId,
                                transactionNumber: OrderFactory.getTransactionIdData().transactionNumber,
                                //need to remove transactiontype value
                                transactionType: 'S',
                                patientProfileList: BasketFactory.getRxOrderData(),
                                posSignatureRequest: ESignFactory.getPosSignatureRequest(),
                                dispositonInfo: {
                                    RegisterNum: CONFIG.registerId,
                                    TxnNum: appUtils.getCurrentTimestamp(CONFIG.transationTimeFormat),
                                    POSTenderType: "Cash",
                                    DispositionId: "20150701152500429",
                                    UserId: CONFIG.loggedInUser.id,
                                    totalTransactionCount: null,
                                    TxnStrtTym: appUtils.getCurrentTimestamp(),
                                    TxnEndTym: appUtils.getCurrentTimestamp(),
                                    FillsSold: 1,
                                    FillNotSold: 0,
                                    MsgDisp: MessageFactory.getNotDisplayedReasonData().messagesDisplayedCount,
                                    MsgNotDisp: MessageFactory.getNotDisplayedReasonData().messagesNotDisplayedCount,
                                    OffInd: "N",
                                    OTCcount: OrderFactory.getOtcDataFromTxn() && OrderFactory.getOtcDataFromTxn().length,
                                    SaleTymStmp: appUtils.getCurrentTimestamp(),
                                    WaiterInd: PatientFactory.getPatientSearchStr() === 'Waiters' ? 'Y' : 'N',
                                    POSCounselLocation: "1"
                                },
                                storeItemList: OrderFactory.getOtcDataFromTxn(),
                                couponList: [{
                                    campId: null,
                                    cpnNbr: null,
                                    cpnSeqNbr: null,
                                    cpnDiscAmt: null,
                                    redeemOvrdReason: null,
                                    cpnMatchCD: null,
                                    campCpnSeqNbr: null,
                                    dateAndTime: null
                                }],
                                miscInfo: null,
                                extraCareInfo: {
                                    xtracareCardNumber: OrderFactory.getEccNumber(),
                                    enrollmentStatus: null,
                                    hippaExpiryDateTime: null,
                                    targetIndicator: null,
                                    enrollPromptIndicator: null,
                                    couponValue: null,
                                    couponExpiryDateTime: null
                                }

                            }
                        };
                        if (!Object.keys($scope.rxOrder).length) {
                            delete payload.TransactionObject.patientProfileList;
                        }
                        if ($scope.isOffline) {
                            payload.TransactionObject.dispositonInfo.OffInd = "Y";
                        }
                    }
                    var totalPromise = Request.invoke({
                        url: url,
                        method: 'POST',
                        data: payload,
                        timeout: 20000
                    });

                    $socket.clear();
                    totalPromise.then(
                        function(data) {
                            if (data && data.image) {
                                if (CONFIG.mceSurvey.currentCount == 0) {
                                    var txnNum = CONFIG.txnInfo.transactionNumber + "";
                                    // var mceSurveyData = {
                                    //     "CVSSurveyRequest": {
                                    //         "amount": "1,000",
                                    //         "url": "www.cvssurvey.com/SSS",
                                    //         "surveyId": CONFIG.lastCallResponse.moreInfo
                                    //     }
                                    // };
                                    // PrintService.doPrint(appConfig.store.services.API.printService.mceSurvey, mceSurveyData);
                                } else {
                                    CONFIG.mceSurvey.currentCount++;
                                    if (CONFIG.mceSurvey.currentCount >= CONFIG.mceSurvey.maxCycleCount) {
                                        CONFIG.mceSurvey.currentCount = 0;
                                    }
                                }
                                var newPhrenroll = BasketFactory.getNewPhrEnrollment();
                                if (newPhrenroll) {
                                    var phrConfirmationData = {
                                        "PHREnrollmentConfirmationRequest": {
                                            "prescriptionNumber": 10,
                                            "rewardAmount": 5,
                                            "cardNumber": OrderFactory.getEccNumber()
                                        }
                                    }
                                    PrintService.doPrint(appConfig.store.services.API.printService.phrConfirmation, phrConfirmationData);
                                }
                                $scope.clearWholeData();
                                OrderFactory.startNewTxn();
                                OrderFactory.setTotalBarcode(data);
                                $modal.open({
                                    templateUrl: 'views/modals/barcode.html',
                                    keyboard: false,
                                    backdrop: false,
                                    size: 'sm',
                                    windowClass: 'total-popup',
                                    controller: 'barcodeCtl',
                                    resolve: {
                                        data: function() {
                                            return {
                                                totalQRCode: ('data:image/png;base64,' + data.image),
                                                recheckStatus: $scope.recheckRxConnectStatus
                                            };
                                        }
                                    }
                                });
                            } else {
                                var modalOptions = {
                                    buttons: ['OK'],
                                    headerText: 'Success',
                                    bodyText: CONFIG.lastCallResponse.moreInfo || 'Transaction completed successfully.'
                                };

                                if (!$scope.refundSaleCompleted) {
                                    modalOptions.bodyText = 'Transaction completed successfully.';
                                }
                                DialogService.showDialog({}, modalOptions).then(function(result) {
                                    $scope.clearWholeData();
                                    $scope.recheckRxConnectStatus();
                                });
                            }
                        },
                        function(data) {
                            $scope.clearWholeData();
                            OrderFactory.startNewTxn();
                            var modalOptions = {
                                buttons: ['OK'],
                                headerText: 'Error',
                                bodyText: 'Unable to process at this time, please try again later'
                            };
                            DialogService.showDialog({}, modalOptions).then(function(result) {
                                if (result === 'OK') {}
                            });
                        });
                } else {
                    var modalOptions = {
                        buttons: ['Ok'],
                        headerText: 'No Items Found ',
                        bodyText: 'No items found in order'
                    };
                    DialogService.showDialog({}, modalOptions).then(function(result) {
                        if (result === 'Ok') {
                            // PatientFactory.clearSelectedPatientList();
                            // BasketFactory.clearBasketData();
                        }
                    });
                }
            };

            $scope.recheckRxConnectStatus = function() {
                // TODO : check offline status
                Request.invoke({
                    url: appConfig.store.services.API.facility,
                    method: 'GET'
                }).then(
                    function(result) {
                        if (result.offline || result.pharmacyClosed) {
                            $scope.isOffline = true;
                            CONFIG.storeData.isOffline = true;
                            $location.url("/home");
                        } else {
                            $scope.isOffline = false;
                            CONFIG.storeData.isOffline = false;
                            $location.url("/patient-lookup");
                        }
                    });
            };


            $scope.regenBarcode = function() {
                LOGGER.info('Home Page > ACTION:REGENERATE BARCODE > FUNCTION:regenBarcode ', loggerName);

                if (OrderFactory.getTotalBarcode()) {
                    var hasItemsInOrder = false;
                    if ($scope.getAllItemsInOrder().length || $scope.minuteClinicDepositsOrder.length) {
                        hasItemsInOrder = true;
                    }
                    $modal.open({
                        templateUrl: 'views/modals/barcode.html',
                        keyboard: false,
                        backdrop: false,
                        size: 'sm',
                        controller: 'barcodeCtl',
                        windowClass: 'total-popup',
                        resolve: {
                            data: function() {
                                return {
                                    totalQRCode: ('data:image/png;base64,' + OrderFactory.getTotalBarcode()),
                                    hasItemsInOrder: hasItemsInOrder,
                                    recheckStatus: $scope.recheckRxConnectStatus
                                };
                            }
                        }
                    });
                }
            };

            $scope.showPSE = function() {
                if (!PseFactory.getIsPSEFlagIsDisplayed()) {
                    var showPseDialog = function() {
                        /**
                         * Only the generic scan listener should be active. 
                         * All the other scan listners should be disabled.
                         *
                         * This condition should be reversed when the scan is done or 
                         * pressed cancel.
                         */
                        disableScanListeners();
                        var IdModalOptions = PSE_ERROR_MESSAGE['PSE_WARN_MESSAGE'];
                        DialogService.showDialog({}, IdModalOptions).then(function(result) {

                            if (result === 'Manual') {
                                if ($scope.isRefund) {
                                    $location.url('/license-entry');
                                    PseFactory.setIsPSEFlagIsDisplayed(true);
                                } else {
                                    $location.url('/license');
                                }
                            } else if (result === 'Scan') {
                                appUtils.log("HOME: enabling license scan listener.");
                                $scope.unBinders.unbindLicenseScan = $scope.$on('SCANNED_DATA_LICENSE', handleLicenseScan);
                                $scope.unBinders.unbindNonLicenseScan = $scope.$on('SCANNED_DATA_GENERIC', handleNonLicenseScan);
                                showPleaseWait();
                            } else if (result === 'Cancel') {
                                $scope.removeControlledItem();
                                enableScanListeners();
                            }
                        });
                    };

                    var showPleaseWait = function() {
                        var modalOptions = {
                            buttons: ['Cancel'],
                            headerText: 'Please scan......',
                            bodyText: 'Please Scan Customer I.D.',
                            blockUI: false,
                            modalKey: 'please-wait'
                        };
                        DialogService.showDialog({}, modalOptions).then(function(firstRes) {
                            if (firstRes === 'Cancel') {
                                var modalOptionsChildOne = {
                                    buttons: ['Yes', 'No'],
                                    headerText: 'Confirmation',
                                    bodyText: 'Are you sure you wish to CANCEL this operation?',
                                    blockUI: false,
                                    modalKey: 'pse-scan-cancel'
                                };
                                DialogService.showDialog({}, modalOptionsChildOne).then(function(secondRes) {
                                    if (secondRes === 'No') {
                                        showPleaseWait();
                                        return;
                                    } else {
                                        // reset the scan listeners to default.
                                        disableScanListeners();
                                        enableScanListeners();
                                        var modalOptionsChildTwo = {
                                            buttons: ['Yes', 'No'],
                                            headerText: 'Confirmation',
                                            bodyText: 'Restricted Item – ID Required<br/>Would you like to Manually Enter ID Information?',
                                            blockUI: false,
                                            modalKey: 'pse-scan-cancel-contd'
                                        };
                                        DialogService.showDialog({}, modalOptionsChildTwo).then(function(thirdRes) {
                                            if (thirdRes === 'No') {
                                                DialogService.closeDialogByKey('please-wait');
                                                return;
                                            } else {
                                                if ($scope.isRefund) {
                                                    $location.url('/license-entry');
                                                    PseFactory.setIsPSEFlagIsDisplayed(true);
                                                } else {
                                                    $location.url('/license');
                                                }
                                            }
                                        });
                                    }
                                });
                            }
                        });
                    };
                    var showEmployeeTrackingDialog = function() {
                        if (CONFIG.pseConfig.pseEmpTracking === 'Y') {
                            var empModalOptions = {
                                buttons: ['OK'],
                                headerText: '',
                                bodyText: 'Enter employee ID to confirm ID validation under Blacklight.'
                            };
                            DialogService.showDialog({}, empModalOptions).then(function(result) {
                                // Capture the employee ID and store it in PSE factory.
                                NumberEntryService.showDialog({}, {
                                    inputText: "Enter Employee ID",
                                    headerText: "Employee ID",
                                    cancelConfirm: true
                                }).then(function(employeeId) {
                                    PseFactory.setTrackedEmployee(employeeId);
                                    showPseDialog();
                                }, function(argument) {
                                    // EMP ID cancelled
                                    appUtils.log("Cancelled the employee ID information in PSE sale");
                                });

                            });
                        } else {
                            showPseDialog();
                        }
                    };

                    if (CONFIG.pseConfig.pseRphIdReqired === 'Y') {
                        DialogService.showDialog({}, {
                            buttons: ['OK'],
                            headerText: '',
                            bodyText: 'RPh Approval Needed - Key Register ID.'
                        }).then(function(result) {

                            ManagerOverrideService.doManagerOverride({
                                    usernameHeaderText: 'RPh Approval',
                                    usernameInputTextHelp: 'Enter Pharmacist Credentials',
                                    passwordHeaderText: 'RPh Approval',
                                    passwordInputTextHelp: 'Password',
                                    invalidRoleMessage: 'Invalid Role - Not a pharmacist',
                                    usernameCancelConfirm: true,
                                    passwordCancelConfirm: true
                                })
                                .then(function(result) {
                                    PseFactory.setRphName(result);
                                    appUtils.log("Pharmacist ID validated for employeed : " + result);
                                    showEmployeeTrackingDialog();
                                }, function(result, statusCode) {
                                    // Handle the RPH validation errors
                                });
                        });
                    } else {
                        showEmployeeTrackingDialog();
                    }

                } else {
                    //if pse request is already done.
                    if (!$scope.isRefund) {
                        $scope.doPseInquery();
                    } else {
                        OrderFactory.getOtcDataFromTxn().push(PseFactory.getControlledItem());
                        $scope.isPserPurchaseIsCompleted = true;
                        PseFactory.setIsPserPurchaseIsCompleted($scope.isPserPurchaseIsCompleted);
                    }
                }
            };

            var handleNonLicenseScan = function(evt, barcode, SCANNED_DATA_TYPE, barcodeType) {
                if (barcodeType !== '201') {
                    LOGGER.info('Unknown barcode type scanned. Not a PDF417 2D barcode. Type:' + barcodeType);
                    DialogService.closeDialogByKey('invalidBarcode');
                    var modalOptions = {
                        buttons: ['Okay'],
                        headerText: 'Invalid Barcode',
                        bodyText: 'Invalid barcode scanned. Please scan the 2D barcode at the back of the License.',
                        modalKey: 'invalidBarcode',
                        blockUI: true
                    };
                    DialogService.showDialog({}, modalOptions);
                }
            };
            var handleLicenseScan = function(evt, barcode, SCANNED_BARCODE_TYPE) {

                appUtils.log("HOME: license data scanned.");
                //reset the scan listerners
                disableScanListeners();
                enableScanListeners();
                DialogService.closeDialogByKey('all');
                PseFactory.setIsLicenseIdScaned(true);
                if (!$scope.isRefund) {
                    $scope.doPseInquery(base64.encode(barcode));
                } else if ($scope.isRefund) {
                    PseFactory.setIdentityScanData(barcode);
                    $scope.addControoledItemToHomeBasket();
                    OrderFactory.getOtcDataFromTxn().push(PseFactory.getControlledItem());
                    $scope.isPserPurchaseIsCompleted = true;
                    PseFactory.setIsPserPurchaseIsCompleted($scope.isPserPurchaseIsCompleted);
                }
            };

            $scope.showPSECustomerDisplay = function() {
                var modalOptions = {
                    buttons: ['Cancel'],
                    headerText: 'Customer Terminal Processing',
                    bodyText: 'WAITING FOR CUSTOMER RESPONSE',
                    blockUI: true
                };
                DialogService.showDialog({}, modalOptions).then(function(result) {
                    if (result === 'Cancel') {
                        PseFactory.clearPSEData();
                        $socket.cancelDeferred('pse_signature_capture');
                        $scope.removeControlledItem();
                        $scope.updateSecDispPriceList();

                        var customerNotaggreedToSign = PSE_ERROR_MESSAGE['PSE_SERVICE_SCAN_CANCEL'];
                        DialogService.showDialog({}, customerNotaggreedToSign).then(function(result) {
                            appUtils.log(result);
                        });
                    }
                });

                $socket.send(JSON.stringify({
                    type: 'DISPLAY_QUESTION',
                    options: {
                        route: 'pseConfirm',
                        payload: {
                            displayText: CONFIG.PSE_CF_LOG
                        }
                    }
                }), true, 'pse_signature_capture').then(function(response) {
                    if (response.options.isAgreed) {
                        DialogService.closeDialog();
                        //for pse request it is same as esig
                        var eSigCompressionRequest = PseFactory.getEsigCompressedRequestPayload();

                        eSigCompressionRequest.eSigCompressionRequest.base64PNGESig = response.options.image.replace('data:image/png;base64,', '');
                        var esigPromiss = PseService.esinServiceRequest(eSigCompressionRequest);
                        esigPromiss.then(function(result) {
                            PseFactory.setCompressedCustomSign(result.base64TIFFEsig);
                            var esigModel = $modal.open({
                                templateUrl: 'views/modals/esig-confirm.html',
                                keyboard: false,
                                backdrop: false,
                                size: 'md',
                                resolve: {
                                    image: function() {
                                        return {
                                            originalImg: response.options.image,
                                            compressedImg: result.base64TIFFEsig,
                                            callback: $scope.addControoledItemToHomeBasket,
                                            cancleCallback: $scope.showPSECustomerDisplay
                                        };
                                    }
                                },
                                controller: 'PseHomeEsigPopupCtrl'
                            });
                        }, function(result) {
                            var modalOptions = {
                                buttons: ['OK'],
                                headerText: 'ERROR',
                                bodyText: 'Sing Compression Failed, Please ask customer to Resign'
                            };
                            DialogService.closeDialog();
                            DialogService.showDialog({}, modalOptions).then(function(result) {

                            });
                        });


                    } else {
                        DialogService.closeDialog();
                        PseFactory.clearPSEData();
                        var customerNotaggreedToSign = PSE_ERROR_MESSAGE['PSE_CUSTOMER_SCAN_CANCEL'];

                        DialogService.showDialog({}, customerNotaggreedToSign).then(function(result) {
                            appUtils.log(result);
                        });
                    }

                });

            };
            $scope.addControoledItemToHomeBasket = function() {
                //add item to current order list and then go to home
                if (!PseFactory.getIsPseRefund()) {
                    OrderFactory.addOtcItemToTxn(PseFactory.getControlledItem());
                    $scope.updateSecDispPriceList();
                }
                PseFactory.setIsPSEFlagIsDisplayed(true);
            };
            $scope.agentPunchInOut = function() {
                $location.url('/agent-punchinout');
            };

            $scope.refund = function() {
                if ($scope.isRefund) {
                    if (!$scope.getAllItemsInOrder().length && !$scope.minuteClinicDepositsOrder.length) {
                        $scope.isRefund = false;
                        $scope.refundSaleCompleted = false;
                        appUtils.log("HOME: getting out of refund mode.");
                        return;
                    } else {
                        return;
                    }
                }
                if (!$scope.isRefundActive() || ($scope.isMinuteClinicDeposits || $scope.minuteClinicDepositsOrder.length)) {
                    return;
                }
                var modalOptions = {
                    buttons: ['Yes', 'No'],
                    headerText: ' ',
                    bodyText: 'Was sale completed on Target POS terminal for items you wish to return?'
                };
                appUtils.log("HOME: Getting into a Refund mode.");
                disableScanListeners();
                DialogService.showDialog({}, modalOptions).then(function(result) {
                    enableScanListeners();
                    if (($scope.tempCurrOrder && $scope.tempCurrOrder.length) || ($scope.rxOrder && Object.keys($scope.rxOrder).length)) {
                        return;
                    }
                    $scope.isRefund = true;
                    $scope.refundSaleCompleted = (result === 'Yes') ? true : false;
                    BasketFactory.removeAllPatients();
                    BasketService.updateBasketData('0', {});
                }, function() {
                    enableScanListeners();
                });
            };
            $scope.employeeMgmt = function(employee) {
                var employeePromise = Request.invoke({
                    loadMessage: "Loading employees...",
                    url: appConfig.store.services.API.employeeMgmt,
                    method: 'GET'
                });
                employeePromise.then(function(result) {
                    if (result === null) {
                        return;
                    }
                    EmployeeMgmtFactory.setUserInfo(result);
                    $modal.open({
                        templateUrl: 'views/modals/emp-mgmt.html',
                        keyboard: false,
                        windowClass: 'modal-dialog-full',
                        backdrop: false,
                        scope: $scope.$new(),
                        controller: 'EmployeeMgmtCtrl'

                    });
                }, function() {
                    //
                });
            };
            $scope.testLog = function() {
                console.log("Rx Items in Order ");
                console.log(BasketFactory.getRxItemsInOrder());
                console.log("Basket data ");
                console.log(BasketFactory.getBasketData());
                BasketFactory.getRxOrderData();
            };
            $scope.test = function() {
                $scope.isOffline = true;
                $scope.goOffLine();
            };
            $scope.priceModify = function() {
                if ($scope.activePaidOut) {
                    return;
                }
                if ($scope.minuteClinicDepositsOrder.length) {
                    return;
                }

                $scope.isPriceModify = !$scope.isPriceModify;

                // if ($scope.isPriceModify) {
                //     angular.forEach(OrderFactory.getOtcDataFromTxn(), function(otcItem) {
                //         otcItem
                //     });
                //     // var modalOptions = {
                //     //     buttons: ['Price', 'Percent', 'Cancel'],
                //     //     headerText: '',
                //     //     bodyText: 'Please select method of price modify'
                //     // };
                //     // DialogService.showDialog({}, modalOptions).then(function(result) {});

                // } else {

                // }
            }
            $scope.priceVerify = function() {
                if ($scope.minuteClinicDepositsOrder.length) {
                    return;
                }
                if ($scope.getAllItemsInOrder().length) {
                    $scope.isPriceVerify = !$scope.isPriceVerify;
                }
            };

            $scope.voidTxn = function(voidTxn) {
                if ($scope.getAllItemsInOrder().length || $scope.getEncodedEccNumber()) {
                    var modalOptions = {
                        buttons: ['Yes', 'No'],
                        headerText: 'Void Transaction',
                        bodyText: 'Do you want to void current transaction?'
                    };
                    DialogService.showDialog({}, modalOptions).then(function(result) {
                        if (result && result === 'Yes') {
                            if (OrderFactory.getFastpass() && OrderFactory.getFastpassData()) {
                                ESignFactory.doFastpassCompleteCancel({
                                    statusCode: "-1",
                                    statusMessage: "Canceled"
                                });
                            }
                            $scope.clearWholeData();
                        }
                    });
                } else if ($scope.minuteClinicDepositsOrder.length) {
                    var miniclinicOptions = {
                        buttons: ['Yes', 'No'],
                        headerText: 'Void Transaction',
                        bodyText: 'Do you want to void current transaction?'
                    };
                    DialogService.showDialog({}, miniclinicOptions).then(function(result) {
                        if (result && result === 'Yes') {
                            $scope.clearWholeData();
                        }
                    });
                }
            };

            $scope.minuteClinicDeposits = function() {
                if ($scope.getAllItemsInOrder().length || $scope.isMaxItem() || $scope.activePaidOut) {
                    return;
                }
                if ($scope.isMinuteClinicDeposits && $scope.minuteClinicDepositsOrder.length === 0) {
                    $scope.minuteClinicDepositsActive = false;
                    $scope.isMinuteClinicDeposits = false;
                    return;
                }
                $scope.minuteClinicDepositsActive = true;
                if ($scope.voidEarlierItemActive) {
                    if ($scope.isMinuteClinicDeposits) {
                        if (!$scope.minuteClinicDepositsOrder.length) {
                            var modalOptions = {
                                buttons: ['OK'],
                                headerText: 'Error',
                                bodyText: 'No Minute Clinic Deposits'
                            };
                            DialogService.showDialog({}, modalOptions).then(function(result) {});
                            return;
                        }
                        var modalOptions = {
                            buttons: ['Cash<br>Deposits', 'Check<br>Deposits', 'Cancel'],
                            headerText: 'Void Earlier Item',
                            bodyText: 'Void Earlier Item'
                        };
                        DialogService.showDialog({}, modalOptions).then(function(result) {
                            if (result == "Cash<br>Deposits") {
                                NumberEntryService.showDialog({}, {
                                    inputText: 'Cash Deposit Amount',
                                    headerText: 'Cash Deposits',
                                    cancelConfirm: true,
                                    maskCurrency: true
                                }).then(function(resultVal) {
                                    if (resultVal) {
                                        $scope.minuteClinicDepositsActive = false;
                                        $scope.voidEarlierItemActive = false;
                                        resultVal = (parseInt(resultVal) / 100).toFixed(2);
                                        var itemFound = false;
                                        for (var i = 0; i < $scope.minuteClinicDepositsOrder.length; i++) {
                                            if ($scope.minuteClinicDepositsOrder[i].key == 'cashAmount' && (resultVal == $scope.minuteClinicDepositsOrder[i].amount)) {
                                                $scope.minuteClinicDepositsOrder.splice(i, 1);
                                                OrderFactory.setMinuteClinicDepositsOrder($scope.minuteClinicDepositsOrder);
                                                itemFound = true;
                                                if (!$scope.minuteClinicDepositsOrder.length) {
                                                    $scope.isMinuteClinicDeposits = false;
                                                }
                                                $scope.updateSecDispPriceList();
                                                return;
                                            }
                                        }
                                        if (itemFound) {
                                            var modalOptions = {
                                                buttons: ['OK'],
                                                headerText: 'Error',
                                                bodyText: 'Voided item not in transaction'
                                            };
                                            DialogService.showDialog({}, modalOptions).then(function(result) {});
                                        }
                                    }
                                });
                            } else if (result == "Check<br>Deposits") {
                                NumberEntryService.showDialog({}, {
                                    inputText: 'Check Deposit Amount',
                                    headerText: 'Check Deposits',
                                    cancelConfirm: true,
                                    maskCurrency: true
                                }).then(function(resultVal) {
                                    if (resultVal) {
                                        $scope.minuteClinicDepositsActive = false;
                                        $scope.voidEarlierItemActive = false;
                                        resultVal = (parseInt(resultVal) / 100).toFixed(2);
                                        for (var i = 0; i < $scope.minuteClinicDepositsOrder.length; i++) {
                                            if ($scope.minuteClinicDepositsOrder[i].key == 'checkAmount' && (resultVal == $scope.minuteClinicDepositsOrder[i].amount)) {
                                                $scope.minuteClinicDepositsOrder.splice(i, 1);
                                                OrderFactory.setMinuteClinicDepositsOrder($scope.minuteClinicDepositsOrder);
                                                if (!$scope.minuteClinicDepositsOrder.length) {
                                                    $scope.isMinuteClinicDeposits = false;
                                                }
                                                $scope.updateSecDispPriceList();
                                                return;
                                            }
                                        }
                                    }
                                });
                            }
                        });
                    }
                } else {
                    var modalOptions = {
                        buttons: ['Cash<br>Deposits', 'Check<br>Deposits', 'Cancel'],
                        headerText: 'Minute Clinic Deposits',
                        bodyText: 'Minute Clinic Deposits'
                    };
                    DialogService.showDialog({}, modalOptions).then(function(result) {
                        if (result == "Cash<br>Deposits") {
                            if (!$scope.isMinuteClinicDeposits == true) {
                                $scope.isMinuteClinicDeposits = true;
                            }
                            NumberEntryService.showDialog({}, {
                                inputText: 'Cash Deposit Amount',
                                headerText: 'Cash Deposits',
                                cancelConfirm: true,
                                maskCurrency: true
                            }).then(function(resultVal) {
                                if (resultVal) {
                                    $scope.minuteClinicDepositsActive = false;
                                    $scope.voidEarlierItemDisabled = false;
                                    if ($scope.minuteClinicDepositsOrder.length === 0) {
                                        OrderFactory.startNewTxn();
                                    }
                                    var cashAmount = {
                                        key: 'cashAmount',
                                        amount: !$scope.isRefund ? (parseInt(resultVal) / 100).toFixed(2) : -(parseInt(resultVal) / 100).toFixed(2),
                                        label: 'MC Cash Total'
                                    };
                                    $scope.minuteClinicDepositsOrder.push(cashAmount);
                                    OrderFactory.setMinuteClinicDepositsOrder($scope.minuteClinicDepositsOrder);
                                    $scope.updateSecDispPriceList();
                                }
                            });
                        } else if (result == "Check<br>Deposits") {
                            if (!$scope.isMinuteClinicDeposits == true) {
                                $scope.isMinuteClinicDeposits = true;
                            }
                            NumberEntryService.showDialog({}, {
                                inputText: 'Check Deposit Amount',
                                headerText: 'Check Deposits',
                                cancelConfirm: true,
                                maskCurrency: true
                            }).then(function(resultVal) {
                                if (resultVal) {
                                    $scope.minuteClinicDepositsActive = false;
                                    if ($scope.minuteClinicDepositsOrder.length === 0) {
                                        OrderFactory.startNewTxn();
                                    }
                                    var checkAmount = {
                                        key: 'checkAmount',
                                        amount: !$scope.isRefund ? (parseInt(resultVal) / 100).toFixed(2) : -(parseInt(resultVal) / 100).toFixed(2),
                                        label: 'MC Check Total'
                                    };
                                    $scope.minuteClinicDepositsOrder.push(checkAmount);
                                    OrderFactory.setMinuteClinicDepositsOrder($scope.minuteClinicDepositsOrder);
                                    $scope.updateSecDispPriceList();
                                }
                            });
                        }
                    });
                }
            };

            var handlePhrEnrollment = function(evt, barcode) {
                var parsedPatientId = barcode.substring(10, barcode.length - 1);
                var phrStatusPromise = Request.invoke({
                    loadMessage: "Checking rewards enrollment status",
                    url: appConfig.store.services.API.phrStatus + '?patient-id=' + parsedPatientId,
                    method: 'GET'
                });
                phrStatusPromise.then(function(eccData) {
                    eccData = eccData ? eccData : {};
                    if (eccData.enrollmentStatus !== 'E') {
                        var opts = {
                            patinetId: parsedPatientId,
                            phrEnrollmentBarcode: barcode,
                            extraCareCardNo: eccData.xtracareCardNumber || ""
                        };
                        HipaaService.enroll(opts);
                    } else {
                        //
                    }
                }, function(eccData) {
                    var modalOptions = {
                        buttons: ['OK'],
                        headerText: 'Error',
                        bodyText: 'Sorry, we are temporarily unable to complete this transaction due to system issue.<br/>If you would like to join the Pharmacy ExtraBucks Rewards program, you can go online<br/>to cvs.com/rxrewards today or we can take care of this for you on your next visit.',
                        blockUI: true
                    };
                    DialogService.showDialog({}, modalOptions).then(function(type) {});
                });
            };

            $scope.initializeHome();
        }
    ]);


angular.module('weCarePlusApp')
    .controller('barcodeCtl', function($scope, $modalInstance, data, $location, PatientFactory, BasketFactory, OrderFactory, PrintService) {
        $scope.data = data;
        $scope.dismiss = function() {
            LOGGER.info('Barcode dialog  > ACTION:DISMISS > FUNCTION:dismiss ', 'barcodeCtl');
            $modalInstance.close();
            PatientFactory.clearSelectedPatientList();
            BasketFactory.clearBasketData();
            OrderFactory.clearTxnObject();
            data.recheckStatus();
        };

        $scope.printQRcode = function() {
            var barCodeData = OrderFactory.getTotalBarcodeData();
            var QRpayload = {
                'QRCodeRequest': {
                    'qrData': barCodeData
                }
            };
            if (barCodeData) {
                PrintService.doPrint(appConfig.store.services.API.printService.totalQRCode, QRpayload);
                LOGGER.info('Barcode dialog  > ACTION:PRINT > FUNCTION:PRINT ', 'barcodeCtl');
            } else {
                LOGGER.error('PRINT FAILURE: Barcode data absent', 'barcodeCtl');
            }
            $scope.dismiss();
        };
    });

angular.module('weCarePlusApp')
    .controller('PseHomeEsigPopupCtrl', function($scope, $modalInstance, $location, image, CONFIG, Request, ESignFactory, PseFactory) {
        $scope.image = image.originalImg;

        $scope.redirectHome = function() {
            PseFactory.setIsItemCanAddToTotal(true);
            image.callback && image.callback();
            $modalInstance.close();
        };
        $scope.dismiss = function() {
            image.cancleCallback && image.cancleCallback();
            $modalInstance.close();
        };
    });
