'use strict';

angular.module('weCarePlusApp')
    .controller('PseCtrl', function($scope, $location, $modal, $route, DialogService, $routeParams, PseFactory, Request, OrderFactory, CONFIG, base64, $socket, FormValidationService, PseService, PrintService, $filter) {
        $scope.licenseID = '';
        $scope.identityInfo = PseFactory.getIdentityInfo();
        $scope.identityType = PseFactory.getIdentityInfo().idType || 'DL_ID';
        $scope.issuingAgency = PseFactory.getIdentityInfo().issuingAgency || '';
        $scope.idNumber = PseFactory.getIdentityInfo().id || '';
        $scope.expirationDate = PseFactory.getIdentityInfo().expiration ? $filter('date')(PseFactory.getIdentityInfo().expiration, 'MM/dd/yyyy', "UTC") : '';
        $scope.lastName = PseFactory.getIdentityInfo().lastName || '';
        $scope.firstName = PseFactory.getIdentityInfo().firstName || '';
        $scope.birthDate = PseFactory.getIdentityInfo().birthDate ? $filter('date')(PseFactory.getIdentityInfo().birthDate, 'MM/dd/yyyy', "UTC") : '';
        $scope.address1 = PseFactory.getIdentityInfo().address1 || '';
        $scope.city = PseFactory.getIdentityInfo().city || '';
        $scope.zipCode = PseFactory.getIdentityInfo().zip || '';
        $scope.state = PseFactory.getIdentityInfo().state || '';
        $scope.countries = ['USA', 'CANADA'];
        $scope.isLicenseIdScaned = PseFactory.getIsLicenseIdScaned();
        $scope.isItemCanAddtoTotal = PseFactory.getIsItemCanAddToTotal();
        $scope.stateList = STATE_MAP;
        $scope.index = 0;
        $scope.isPseRefund = PseFactory.getIsPseRefund();
        $scope.idWarnings = [];
        $scope.currentFieldKey = '';

        $scope.orderedFieldKeyList = ['identityType', 'expirationDate', 'birthDate', 'zipCode', 'state', 'idNumber', 'lastName', 'firstName', 'address1', 'city'];
        $scope.orderedFieldKeyListPassport = ['identityType', 'expirationDate', 'birthDate', 'zipCode', 'issuingAgency', 'idNumber', 'lastName', 'firstName', 'address1', 'city'];
        $scope.currentFocusModelKey = 'expirationDate';

        $scope.userInputFieldValidaion = {
            idNumber: 'PSE_ID_VALID',
            issuingAgency: 'COUNTRY',
            state: 'STATE',
            firstName: 'FIRST_NAME',
            lastName: 'LAST_NAME',
            expirationDate: 'EXPIRATION_DATE',
            birthDate: 'PSE_DATE_OF_BIRTH',
            zipCode: 'ZIPCODE',
            address1: 'STREET_ADDRESS',
            city: 'CITY'
        };

        $scope.isFormValid = false;

        $scope.loadifLicenIsScaned = function() {
            if ($scope.isLicenseIdScaned) {
                //$scope.searchLicenseId(PseFactory.getIdentityScanData());
            }
        };

        $scope.onErrorResult = function() {
            var modalOptions = PSE_ERROR_MESSAGE['PSE_SERVICE_FAIL'];
            DialogService.showDialog({}, modalOptions).then(function(type) {
                $location.url('/home');
            });
        };

        $scope.showPseErrorMessage = function() {
            //If reached PSE purchase limit invoke PSE Decline
            var pseDeclinePromise = PseService.buildPsePurchaseRequest('DECLINE');
            //Pse Item purchase issue
            var modalOptions = PSE_ERROR_MESSAGE['PSE_INQUERY_FAIL'];
            DialogService.showDialog({}, modalOptions).then(function(type) {
                $scope.goToHomePage();
                if (type == 'OK') {
                    if (PseFactory.getCurrentOrderList().length < 1) {
                        PseFactory.clearPSEData();
                    }
                }
            });
        };

        $scope.showUnknownPharmacyMessage = function() {
            //Pse Item purchase issue
            var modalOptions = PSE_ERROR_MESSAGE['UNKNOWN_PHARMACY'];
            DialogService.showDialog({}, modalOptions).then(function(type) {
                $scope.goToHomePage();
                if (type == 'OK') {
                    if (PseFactory.getCurrentOrderList().length < 1) {
                        PseFactory.clearPSEData();
                    }
                }
            });
        };

        $scope.onFocusListner = function(currentFocusModel) {
            $scope.currentFocus = {
                model: currentFocusModel
            };
        };

        var inputs = $(':input');


        $scope.onLicenseScreenKeyClick = function(keyType, keyVal) {
            var tempValue = $scope[$scope.currentFocus.model];

            if (keyType === 'normKey') {
                tempValue = tempValue ? (tempValue + keyVal) : keyVal;
                if ($scope.currentFocus.model === 'idNumber') {
                    if (tempValue.length <= 20) {
                        $scope[$scope.currentFocus.model] = tempValue;
                        $scope.currentFocus.el.target.focus();
                    }
                    return;
                }

                if ($scope.currentFocus.model === 'issuingAgency') {
                    if (tempValue.length <= 0) {
                        $scope.currentFocus.el.target.focus();
                        return;
                    }
                    if (tempValue.length <= 2) {
                        $scope[$scope.currentFocus.model] = tempValue;
                        $scope.currentFocus.el.target.focus();
                    }
                    return;
                }

            } else if (keyType === 'splKey') {
                switch (keyVal) {
                    case 'clear':
                        tempValue = '';
                        $scope[$scope.currentFocus.model] = '';
                        $scope.currentFocus.el.target.focus();
                        break;
                    case 'backspace':
                        tempValue = tempValue ? (tempValue.length > 0 ? tempValue.substr(0, tempValue.length - 1) : '') : null;
                        $scope[$scope.currentFocus.model] = tempValue;
                        $scope.currentFocus.el.target.focus();
                        break;
                    case 'enter':
                        var errorMessageList = [];
                        var issuingAgencyType;
                        $scope.isFormValid = true;

                        errorMessageList = FormValidationService.doValidate($scope.userInputFieldValidaion.idNumber, $scope.idNumber);
                        if (errorMessageList.length) {
                            $scope.handleErrorMessages(errorMessageList);
                            $scope.isFormValid = false;
                            return;
                        };

                        if ($scope.identityType === 'PASSPORT') {
                            issuingAgencyType = 'COUNTRY';
                        } else {
                            issuingAgencyType = $scope.userInputFieldValidaion.state;
                        }
                        errorMessageList = FormValidationService.doValidate(issuingAgencyType, $scope.issuingAgency);
                        if (errorMessageList.length) {
                            $scope.handleErrorMessages(errorMessageList);
                            $scope.isFormValid = false;
                            return;
                        };

                        if ($scope.isFormValid) {
                            $scope.doPseInquery(null, $scope.idNumber, $scope.issuingAgency, $scope.identityType);
                        }
                        break;
                    case 'cancel':
                        $scope.onTransactionCancel();
                        break;
                    case 'previous':
                        if ($scope.index > 0) {
                            $scope.index = $scope.index - 1;
                            var preInput = inputs[$scope.index];
                            if (preInput) {
                                preInput.focus();
                            }
                        } else { //to set the focus first element
                            $scope.currentFocus.el.target.focus();
                        }
                        break;
                    case 'next':
                        //it traverse to next element when next key is pressed
                        if ($scope.index < inputs.length - 1) {
                            $scope.index = $scope.index + 1;
                            var nextInput = inputs[$scope.index];
                            if (nextInput) {
                                nextInput.focus();
                            }
                        } else { //to set the focus first element
                            $scope.currentFocus.el.target.focus();
                        }
                        break;
                    default:
                        break;
                }
            } else {
                appUtils.log("Invalid type of key pressed.");
            }
        };

        //show PSE customer details 
        $scope.showPSECustomerDisplay = function() {
            var modalOptions = {
                buttons: ['Cancel'],
                headerText: 'Customer Terminal Processing',
                bodyText: 'WAITING FOR CUSTOMER RESPONSE',
                blockUI: true
            };
            DialogService.showDialog({}, modalOptions).then(function(result) {
                if (result === 'Cancel') {
                    PseFactory.clearPSEData();
                    $socket.cancelDeferred('pse_signature_capture');
                    $scope.updateSecDispPriceList();
                    var customerNotaggreedToSign = PSE_ERROR_MESSAGE['PSE_SERVICE_SCAN_CANCEL'];
                    DialogService.showDialog({}, customerNotaggreedToSign).then(function(result) {
                        $location.url('/home');
                    });
                }
            });
            $socket.send(JSON.stringify({
                type: 'DISPLAY_QUESTION',
                options: {
                    route: 'pseConfirm',
                    payload: {
                        displayText: CONFIG.PSE_CF_LOG
                    }
                }
            }), true, 'pse_signature_capture').then(function(response) {
                if (response.options.isAgreed) {
                    DialogService.closeDialog();
                    //for pse request it is same as esig
                    var eSigCompressionRequest = PseFactory.getEsigCompressedRequestPayload();

                    eSigCompressionRequest.eSigCompressionRequest.base64PNGESig = response.options.image.replace('data:image/png;base64,', '');
                    var esigPromiss = PseService.esinServiceRequest(eSigCompressionRequest);
                    esigPromiss.then(function(result) {
                        PseFactory.setCompressedCustomSign(result.base64TIFFEsig);
                        var esigModel = $modal.open({
                            templateUrl: 'views/modals/esig-confirm.html',
                            keyboard: false,
                            backdrop: false,
                            size: 'md',
                            resolve: {
                                image: function() {
                                    return {
                                        originalImg: response.options.image,
                                        compressedImg: result.base64TIFFEsig,
                                        callback: $scope.addControoledItemToHomeBasket,
                                        cancleCallback: $scope.showPSECustomerDisplay
                                    };
                                }
                            },
                            controller: 'PseEsigPopupCtrl'
                        });
                    }, function(result) {
                        var modalOptions = {
                            buttons: ['OK'],
                            headerText: 'ERROR',
                            bodyText: 'Sign Compression Failed, Please ask customer to Resign'
                        };
                        DialogService.closeDialog();
                        DialogService.showDialog({}, modalOptions).then(function(result) {

                        });
                    });


                } else {
                    DialogService.closeDialog();
                    PseFactory.clearPSEData();
                    var customerNotaggreedToSign = PSE_ERROR_MESSAGE['PSE_CUSTOMER_SCAN_CANCEL'];
                    DialogService.showDialog({}, customerNotaggreedToSign).then(function(result) {
                        appUtils.log(result);
                        $scope.goToHomePage();
                    });
                }

            });

        };

        $scope.handleErrorMessages = function(errorMessageList) {
            if (errorMessageList.length) {
                var errorMessageBodyHtml = '';
                angular.forEach(errorMessageList, function(errorMessage) {
                    errorMessageBodyHtml += errorMessage + '<br/>';
                });
                var modalOptions = {
                    buttons: ['OK'],
                    headerText: 'Error',
                    bodyText: errorMessageBodyHtml
                };
                DialogService.showDialog({}, modalOptions).then(function(result) {});
            }
        };

        $scope.doPseInquery = function(identityData, idnumber, state, idType) {
            var pseInquiryPromise = PseService.validatePseItems(identityData, idnumber, state, idType)
                //on sucess service will give 0000 or 0003
            pseInquiryPromise.then(function(result) {
                if (result != null && (result.responseCode == PSE_ERROR_CODE['PSE_SUCESS_CODE'] || result.responseCode == PSE_ERROR_CODE['PSE_SUCESS_WARNING'])) {
                    PseFactory.setIdentityInfo(PseService.mergePersonInfo(result.personinfo, PseFactory.getIdentityInfo()));
                    if (result.responseCode == PSE_ERROR_CODE['PSE_SUCESS_WARNING'] && result.warnings.warning.length >= 1) {
                        $scope.updateWarningList(result.warnings.warning);
                        $location.url("/license-entry");
                    } else {
                        $scope.showPSECustomerDisplay();
                    }
                } else if (result != null && result.responseCode == PSE_ERROR_CODE['PSE_FAIL_CODE']) {
                    if (result.inquiryValidation && result.inquiryValidation.resultCode === '-2' && result.inquiryValidation.errorMessage === 'UNKNOWN_PHARMACY') {
                        $scope.showUnknownPharmacyMessage();
                    } else {
                        $scope.showPseErrorMessage();
                    }
                    $scope.removeItemFromOrder();
                    var printPseDicline = angular.copy(PseFactory.getPsePrintServiceRequest());
                    printPseDicline.PSEDeclineRequest.dailyLimit = "3.6 g";
                    printPseDicline.PSEDeclineRequest.maxLimit = "9.0 g";
                    printPseDicline.PSEDeclineRequest.days = "30";
                    if (result !== null && result.inquirySid) {
                        printPseDicline.PSEDeclineRequest.transaction = result.inquirySid;
                    } else {
                        var tempId = appUtils.getCurrentTimestamp() + "";
                        printPseDicline.PSEDeclineRequest.transaction = tempId.substr(0, 7);
                    }
                    PrintService.doPrint(appConfig.store.services.API.printService.pseDecline, printPseDicline);
                } else {
                    $scope.removeItemFromOrder();
                    $scope.onErrorResult();
                }
            }, function(result) {
                $scope.removeItemFromOrder();
                $scope.onErrorResult();
            });
        };

        $scope.updateWarningList = function(warnings) {
                angular.forEach(warnings, function(warning) {
                    $scope.idWarnings.push(warning.code);
                });
            }
            //remove Item
        $scope.removeItemFromOrder = function() {

            PseFactory.removeFromCurrentOrderList(PseFactory.getControlledItem());
            if (PseFactory.getIsPseRefund()) {
                var toRemoveItem = "";
                angular.forEach(OrderFactory.getOtcDataFromTxn(), function(otcItem, index) {
                    if (otcItem.upc == controlledItem.upc) {
                        toRemoveItem = index;
                    }
                });
                OrderFactory.getOtcDataFromTxn().splice(toRemoveItem, 1);
            }
        };
        $scope.onLicenseEntryScreenKeyClick = function(keyType, keyVal) {
            var tempValue = $scope[$scope.currentFocus.model];
            if (keyType === 'normKey') {
                tempValue = tempValue ? (tempValue + keyVal) : keyVal;

                if ($scope.currentFocus.model === 'idNumber') {
                    if (tempValue.length <= 20) {
                        $scope[$scope.currentFocus.model] = tempValue;
                    }
                    return;
                } else if ($scope.currentFocus.model === 'state' || $scope.currentFocus.model === 'issuingAgency') {
                    if (tempValue.length <= 2) {
                        $scope[$scope.currentFocus.model] = tempValue;
                    }
                    return;
                } else if ($scope.currentFocus.model === 'zipCode') {
                    if (tempValue.length <= 5) {
                        $scope[$scope.currentFocus.model] = tempValue;
                    }
                    return;
                } else if ($scope.currentFocus.model === 'firstName' || $scope.currentFocus.model === 'lastName') {
                    if (tempValue.length <= 9) {
                        $scope[$scope.currentFocus.model] = tempValue;
                    }
                    return;
                } else if ($scope.currentFocus.model === 'address1' || $scope.currentFocus.model === 'city') {
                    if (tempValue.length <= 21) {
                        $scope[$scope.currentFocus.model] = tempValue;
                    }
                    return;
                } else if ($scope.currentFocus.model === 'expirationDate' || $scope.currentFocus.model === 'birthDate') {
                    if (tempValue.length === 1 && parseInt(tempValue) <= 1) {
                        $scope[$scope.currentFocus.model] = tempValue;
                        return;
                    } else if (tempValue.length === 2 && parseInt(tempValue.charAt(tempValue.length - 1)) <= 9) {
                        tempValue += '/'
                        $scope[$scope.currentFocus.model] = tempValue;
                        return;
                    } else if (tempValue.length === 4 && parseInt(tempValue.charAt(tempValue.length - 1)) < 4) {
                        $scope[$scope.currentFocus.model] = tempValue;
                        return;
                    } else if (tempValue.length === 5 && parseInt(tempValue.charAt(tempValue.length - 2)) < 4) {
                        var tempLenth = tempValue.length;
                        if (parseInt(tempValue.substring(3, tempLenth)) < 32) {
                            tempValue += '/'
                            $scope[$scope.currentFocus.model] = tempValue;
                            return;
                        }
                    } else if (tempValue.length === 6 && parseInt(tempValue.charAt(tempValue.length - 1)) < 3) {
                        $scope[$scope.currentFocus.model] = tempValue;
                        return;
                    } else if (tempValue.length <= 10 && parseInt(tempValue.charAt(6)) < 3) {
                        $scope[$scope.currentFocus.model] = tempValue;
                        return;
                    }
                    return;
                }
                return;

            } else if (keyType === 'splKey') {
                switch (keyVal) {
                    case 'clear':
                        tempValue = '';
                        $scope[$scope.currentFocus.model] = '';
                        break;
                    case 'backspace':
                        tempValue = tempValue ? (tempValue.length > 0 ? tempValue.substr(0, tempValue.length - 1) : '') : null;
                        if ($scope.currentFocus.model !== 'identityType') {
                            $scope[$scope.currentFocus.model] = tempValue;
                        }
                        break;
                    case 'enter':
                        var errorMessageList = [];
                        var breakValidationLoop = false;
                        $scope.isFormValid = true;
                        angular.forEach(inputs, function(inputField) {
                            if (!breakValidationLoop) {
                                if (inputField.type == 'text') {
                                    var inputName = $(inputField).attr('ng-model');
                                    var inputValue = inputField.value;
                                    if ((inputName === 'state' && $scope.identityType === 'PASSPORT') ||
                                        (inputName === 'issuingAgency' && $scope.identityType !== 'PASSPORT')) {
                                        return;
                                    }

                                    if (inputName && !inputValue) {
                                        $scope.isFormValid = false;
                                        breakValidationLoop = true;
                                        var modalOptions = PSE_ERROR_MESSAGE['PSE_REQUIRED_VALIDATION_MESSAGE'];
                                        DialogService.showDialog({}, modalOptions).then(function(result) {
                                            //Close window
                                        });
                                        inputField.focus();
                                        return;
                                    }
                                    errorMessageList = FormValidationService.doValidate($scope.userInputFieldValidaion[inputName], inputValue);
                                }
                            }
                            if (errorMessageList.length) {
                                $scope.isFormValid = false;
                                breakValidationLoop = true;
                                return;
                            }
                        });
                        if (!$scope.isFormValid) {
                            $scope.handleErrorMessages(errorMessageList);
                            return;
                        }
                        if ($scope.isFormValid) {
                            var expDate = $filter('date')(appUtils.isValidDate($scope.expirationDate), 'yyyy-MM-dd', "UTC");
                            var birthDate = $filter('date')(appUtils.isValidDate($scope.birthDate), 'yyyy-MM-dd', "UTC");
                            var personInfoDetails = {
                                "id": $scope.idNumber,
                                "idType": $scope.identityType,
                                "issuingAgency": $scope.issuingAgency || $scope.state || '',
                                "expiration": expDate,
                                "lastName": $scope.lastName,
                                "firstName": $scope.firstName,
                                "middleName": $scope.middleName,
                                "birthDate": birthDate,
                                "address1": $scope.address1,
                                "city": $scope.city,
                                "state": $scope.state || '',
                                "zip": $scope.zipCode
                            };

                            PseFactory.setIdentityInfo(personInfoDetails);
                            //is refund 
                            if (!$scope.isPseRefund) {
                                $scope.showPSECustomerDisplay();
                            } else {
                                $scope.goToHomePage();
                                //if Pse refund not do any thing just added the data scaned in factory data
                                $scope.addControoledItemToHomeBasket();
                            }
                        }

                        break;
                    case 'cancel':
                        //clear controlled item and go home page
                        $scope.onTransactionCancel();
                        break;
                    case 'previous':
                        $scope.doNextPrevAction('prev');
                        break;
                    case 'next':
                        $scope.doNextPrevAction('next');
                        break;
                    default:
                        break;
                }
            } else {
                appUtils.log("Invalid type of key pressed.");
            }
        };

        $scope.selectFieldClickHandler = function(seletedKey) {
            $scope.currentFocusModelKey = seletedKey;
        };

        $scope.doNextPrevAction = function(keyVal) {
            var fieldList;
            if ($scope.identityType === 'PASSPORT') {
                fieldList = $scope.orderedFieldKeyListPassport;
            } else {
                fieldList = $scope.orderedFieldKeyList;
            }
            var currentFieldIndex = fieldList.indexOf($scope.currentFocusModelKey);
            var orderedFieldKeyListLength = fieldList.length;
            if (keyVal === 'next') {
                if ((currentFieldIndex + 1) < orderedFieldKeyListLength) {
                    $scope.currentFocusModelKey = fieldList[(currentFieldIndex + 1)];
                } else {
                    $scope.currentFocusModelKey = fieldList[0];
                }
            } else {
                if (currentFieldIndex === 0) {
                    $scope.currentFocusModelKey = fieldList[orderedFieldKeyListLength - 1];
                } else {
                    $scope.currentFocusModelKey = fieldList[(currentFieldIndex - 1)];
                }
            }
            $scope.currentFocus.model = $scope.currentFocusModelKey;
        };

        $scope.goToHomePage = function() {
            $location.url("/home");
        };

        $scope.onTransactionCancel = function() {
            var IdModalOptions = PSE_ERROR_MESSAGE['PSE_SERVICE_CANCEL'];
            DialogService.showDialog({}, IdModalOptions).then(function(result) {
                if (result === 'OK') {
                    PseFactory.clearPSEData();
                    $scope.removeItemFromOrder();
                    $scope.goToHomePage();
                    appUtils.log(IdModalOptions.bodyText);
                }
            });
        };

        $scope.addControoledItemToHomeBasket = function() {
            //add item to current order list and then go to home
            // if (!$scope.isPseRefund) {
            OrderFactory.addOtcItemToTxn(PseFactory.getControlledItem());
            $scope.updateSecDispPriceList();
            // }
            PseFactory.setIsPSEFlagIsDisplayed(true);
            $scope.goToHomePage();
        };

    });

angular.module('weCarePlusApp')
    .controller('PseEsigPopupCtrl', function($scope, $modalInstance, $location, image, CONFIG, Request, ESignFactory, PseFactory) {
        $scope.image = image.originalImg;

        $scope.redirectHome = function() {
            PseFactory.setIsItemCanAddToTotal(true);
            image.callback && image.callback();
            $modalInstance.close();
        };
        $scope.dismiss = function() {
            image.cancleCallback && image.cancleCallback();
            $modalInstance.close();
        };
    });
