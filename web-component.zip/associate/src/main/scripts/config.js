'use strict';


angular.module('weCarePlusApp').value('CONFIG', {
    clockFormat: 'mediumTime',
    dateFormat: 'MM-dd-yyyy',
    birthDayFormat: 'MMM-dd',
    workstationID: null,
    registerId: null,
    pseConfig: {},
    registerData: {
        id: null,
        printerQname: 'wcp_pr'
    },
    offlinePatId: 0,
    storeData: {
        number: 68630,
        isOffline: false,
        rdyFillLiteConfirmationFlag: 'off',
        printerQname: 'wcp_pr01'
    },
    txnInfo: {},
    messages: {
        txnStartTimestamp: null,
        patientMessageInfoKeyMap: {
            "1": "eanMsg",
            "2": "msgCentrMsg",
            "3": "pciCounslMsg",
            "4": "patCentricMsg",
            "5": "rxCentrMsg",
            "6": "patCentricMsg",
            "7": "patDemoMsg",
            "8": "srdMsg",
            "9": "tpComplianceMsg",
            "10": "patientCareMessage"
        }
    },
    headerData: {
        token: null
    },
    storeNumber: 68630,
    screenId: 2,
    versionNo: 1,
    timestampFormat: 'yyyymmddHHMMss',
    transationTimeFormat: 'HHss',
    socket: {
        reconnect: true,
        endpoint: 'wss://wecare.localhost.stores.cvs.com:9900/associate'
    },
    loggedInUser: {
        role: "manager"

    },
    pageTitle: "CVS Health",
    BASKET_SCENARIO: {
        CONSTANT: 'scenario',
        DELIMETER: '.'
    },
    MONTH_MAX_DAYS: {
        JAN: 31,
        FEB: 29,
        MAR: 31,
        APR: 30,
        MAY: 31,
        JUN: 30,
        JUL: 31,
        AUG: 31,
        SEP: 30,
        OCT: 31,
        NOV: 30,
        DEC: 31
    },
    DATE_DELIMETER: '-',
    DEFAULT_POLL_INTERVAL: 900000,
    ID_TYPES: {
        '01': 'Military ID',
        '02': 'State ID',
        '05': 'Passport',
        '06': 'Drivers License',
        '07': 'SSN',
        '08': 'Tribal ID'
    },
    RELATIONSHIP: {
        '01': 'Patient',
        '02': 'Patient/ Legal Guardian',
        '03': 'Spouse',
        '04': 'Caregiver',
        '05': 'Other (ASAP-2005)'
    },
    RELATIONSHIP_TO_PATIENT: {
        '01': 'Patient',
        '02': 'Parent',
        '03': 'Spouse',
        '04': 'Caregiver',
        '05': 'Relative',
        '06': 'Friend'
    },
    PATIENT_DETAILS: {
        'PREFERRED_CONTACT_HOME': 1,
        'PREFERRED_CONTACT_OFFICE': 2,
        'PREFERRED_CONTACT_MOBILE': 3,
        '1': 'home',
        '2': 'work',
        '3': 'mobile',
        'home': '1',
        'work': '2',
        'mobile': '3',
        LABELS: {
            '1': 'Home',
            '2': 'Work',
            '3': 'Cell'
        }
    },
    mceSurvey: {
        maxCycleCount: 1,
        currentCount: 0
    },
    srdIdscanDisallowedStates: ['AK', 'AZ', 'AR', 'CA', 'CO', 'CT', 'DL', 'DC', 'GA', 'IA', 'MN', 'MO', 'MT', 'NE', 'NH', 'NJ', 'NY', 'ND', 'OH', 'OR', 'PA', 'PR', 'RI', 'SD', 'VT', 'VA', 'WY'],
    PSE_CF_LOG: 'Pursuant to Federal and certain State Law, when purchasing items containing Pseudoephedrine, purchasers\' information must be logged. Section 1001 of Title 18, United States Code, states that whoever, with respect to the logbook, knowingly and willfully falsifies, conceals, or covers up by any trick, scheme, or device a material fact, or makes any materially false, fictitious, or fraudulent statement or representation, or makes or uses any false writing or document knowing the same to contain any materially false, fictitious, or fraudulent statement or entry, shall be fined not more than $250,000 if an individual or $500,000 if an organization, imprisoned not more than five years, or both.',
    THRESHOLD_AMOUNT: {
        priceModify: 10,
        voidTransaction: 10,
        refund: 10
    },
    MAXIMUM_LIMIT:{
        otcAmountLimit: 999.99,
        paidOutsLimit: 200
    },
    lastCallResponse: {},
    PROG_SUB_TYPE: {
        AOB: {
            AOB_REQUIRED_PT: 1,
            AOB_REQUIRED_REP: 2,
            AOB_SIGN_DATE: 3,
            AOB_REFUSE: 4,
            AOB_REFUSE_MAXDAYS: 5,
            AOB_REFUSE_THRESHOLD: 6,
            AOB_RETURN: 7
        },
        ABN: {
            ABN_REQUIRED: 1,
            ABN_OPTION: 3,
            ABN_OPTION_MISMATCH_1: 4,
            ABN_OPTION_MISMATCH_2: 5,
            ABN_OPTION_MISMATCH_3: 6,
            ABN_REFUSE_UNASSIGNED: 7,
            ABN_REFUSE_ASSIGNED_ITEMS: 9,
            ABN_EMPLOYEE: 10,
            ABN_SIGN_DATE: 11,
            ABN_RETURN: 12
        }
    },
    paidOuts: {
        ESS: {
            viewData: {
                "inputText": "Emergency Store Supplies Amount",
                "headerText": "Emergency Store Supplies",
                "thresholdValueAlertText": 'Amount entered exceeds the allowable limit'
            },
            payloadData: {
                "sku": 667121,
                "upc": 400000311838,
                "description": "TGT-RX - Supplies",
                "quantity": 1,
                "taxableItem": true
            }
        },
        CE: {
            viewData: {
                "inputText": "Customer Escalation Amount",
                "headerText": "Customer Escalation",
                "thresholdValueAlertText": 'Amount entered exceeds the allowable limit'
            },
            payloadData: {
                "sku": 667139,
                "upc": 400000311845,
                "description": "TGT-RX - Cust. SVC",
                "quantity": 1,
                "taxableItem": true
            }
        },
        THRESHOLD_AMOUNT: 200
    }
});

//Barcode Scanner Broadcast Flag and Listner Object
var BARCODE_SCAN_HANDLER = {
    ROOT: {
        broadcast: true
    },
    SCANNED_DATA_GENERIC: {
        broadcast: true,
        listener: null
    },
    SCANNED_DATA_ECC: {
        broadcast: true,
        listener: null
    },
    SCANNED_DATA_OTC: {
        broadcast: true,
        listener: null
    },
    SCANNED_DATA_RX: {
        broadcast: true,
        listener: null
    },    SCANNED_DATA_SPLRX: {
        broadcast: true,
        listener: null
    },
    SCANNED_DATA_PHR: {
        broadcast: true,
        listener: null
    },
    SCANNED_DATA_FASTPASS: {
        broadcast: true,
        listener: null
    },
    SCANNED_DATA_IMAGE: {
        broadcast: true,
        listener: null
    },
    SCANNED_DATA_FORM: {
        broadcast: true,
        listener: null
    },
    SCANNED_DATA_LICENSE: {
        broadcast: true,
        listener: null
    }
};

var DAILY_CONFIG = {
    basketConfig: {},
    messageConfig: {},
    pharmacyInfo: {},
    screenConfig: {},
    patientFormsConfig: {},
    SRDRulesConfig: {},
    actionNoteButtonConfig: {},
    nintyDayPaymentTerminal: {
     value: 'Y',
    }
};

var appConfig = {
    pageTitle: 'CVS Health',
    dateFormat: 'MM/DD/YYYY',
    timeFormat: 'MM:ss TT',
    barcodeMinLength: 5,
    store: {
        services: {
            API: {
                patientSearch: '/service/patients/patientSearch',
                waiters: '/service/patients/waiters',
                patientBasket: '/service/patients/patientProfile',
                rxScan: '/service/scripts/scan',
                eSignature: '/service/sales/esignature',
                eSignConfig: '/service/messages/esig2',
                eSignConfigPayment: '/service/messages/esig2/payment',
                total: '/service/sales/completetransaction',
                refund: '/service/sales/completetransaction/refund',
                minuteClinic: '/service/sales/completetransaction/minitclinic',
                pseInquiry: '/service/compliance/pse/inquiry',
                pseLicense: '/service/compliance/pse/license',
                psePurchase: '/service/compliance/pse/purchase',
                pseReturn: '/service/compliance/pse/return',
                pseRefundBlocked: '/service/stores/attributes/pse_block_refund',
                pseRphIdReqired: '/service/stores/attributes/pse_rph_id_req',
                pseEmpTracking: '/service/stores/attributes/pse_emp_tracking',
                rdyFillLiteConfirmationFlag: '/service/stores/attributes/rdyfilllite_confirmation_flag',
                pseDecline: '/service/compliance/pse/purchasedecline',
                pseRefusal: '/service/compliance/pse/refusal',
                phrEnrollment: '/service/customers/phr/hrenrollment',
                extraCareLookUp: '/service/customers/ecc/accounts',
                agentlogin: '/service/agent/login',
                agentpassword: '/service/agent/password',
                completeRxOrder: '/service/sales/completeorder',
                employees: '/service/stores/employees',
                punchinout: '/service/stores/employees/punchinout',
                itemLookUp: '/service/items/front-stores',
                fastPass: '/service/patients/fastpass',
                phrStatus: '/service/customers/phr/enroll-status',
                expedite: '/service/scripts/expedite',
                transationIdService: '/service/bsl/transaction-start',
                compileMessages: {
                    'inStore': '/service/messages/instore/compileMessages',
                    'rxScan': '/service/scripts/scan',
                    'completeRxOrder': '/service/messages/completeOrder/compileMessages',
                    'rxSelect': '/service/messages/rxSelect/compileMessages'
                },
                displayMessages: {
                    'inStore': '/service/messages/instore/displayMessages',
                    'rxScan': '/service/messages/rxScan/displayMessages',
                    'completeRxOrder': '/service/messages/completeOrder/displayMessages',
                    'rxSelect': '/service/messages/rxSelect/displayMessages'
                },
                compileOffLineMessages: '/service/messages/compileOffLineMessages',
                getNextMessage: '/service/messages/instore/displayMessages',
                employeeMgmt: '/service/stores/employees',
                mealWaiver: '/service/stores/employees/employeewaiver',
                fastPassPatient: '/service/bsl/fastpass/transaction/',
                facility: '/service/bsl/rxconnect/facility',
                fastPassScan: '/service/patients/profiles',
                empDetails: '/service/employees/isEmpCredExist/empid',
                storeNumber: '/service/stores/attributes/store_number',
                stateCode: '/service/stores/attributes/statecode',
                esigCompression: '/service/stores/esig/esig-compression',
                monitorService: '/monitor/alert/message',
                printService: {
                    phrEnrollment: '/service/devices/printers/PHR_Enrollment',
                    patientRefuseToSign: '/service/devices/printers/Esig_Refuse',
                    mceSurvey: '/service/devices/printers/CVS_Survey',
                    phrConfirmation: '/service/devices/printers/PHR_Confirmation',
                    phrOfferToEnroll: '/service/devices/printers/PHR_Offer',
                    phrRedeem: '/service/devices/printers/PHR_Redeem',
                    pseDecline: '/service/devices/printers/PSE_Decline',
                    tcpa: '/service/devices/printers/TCPA',
                    minitclinicDeposits: '/service/devices/printers/MC',
                    totalQRCode: '/service/devices/printers/QRCODE'
                },
                dailyConfig: {
                    basketConfig: {
                        interval: 1800000,
                        endpoint: '/service/stores/configs/POSBasket',
                        active: true
                    },
                    messageConfig: {
                        interval: 1800000,
                        endpoint: '/service/stores/configs/POSMessage',
                        active: true
                    },
                    pharmacyInfo: {
                        interval: 1800000,
                        endpoint: '/service/stores/configs/pharmacy',
                        active: true
                    },
                    screenConfig: {
                        interval: 1800000,
                        endpoint: '/service/stores/configs/POSScreen',
                        active: true
                    },
                    SRDRulesConfig: {
                        interval: 1800000,
                        endpoint: '/service/stores/configs/srdRules',
                        active: true
                    },
                    patientFormsConfig: {
                        interval: 1800000,
                        endpoint: '/service/stores/configs/patientForms',
                        active: true
                    },
                    actionNoteButtonConfig: {
                        interval: 1800000,
                        endpoint: '/service/stores/configs/actionNote',
                        active: true
                    },
                    nintyDayPaymentTerminal: {
                        interval: 1800000,
                        endpoint: '/service/stores/attributes/ninety_day_payment_terminal_confirmation',
                        active: true  
                    }

                }
            }
        }
    }
}

var PSI2_PROD_PROP = {
    "scenario.ADE.0": 23,
    "scenario.TP.0": 23,
    "scenario.AP.0": 23,
    "scenario.IE.0": 23,
    "scenario.TPR.0": 23,
    "scenario.RAR.0": 23,
    "scenario.ADE.2": 32,
    "scenario.TP.2": 32,
    "scenario.AP.2": 32,
    "scenario.IE.2": 32,
    "scenario.TPR.2": 32,
    "scenario.NP.2": 86,
    "scenario.ADE.5": 48,
    "scenario.TP.5": 48,
    "scenario.AP.5": 48,
    "scenario.IE.5": 48,
    "scenario.TPR.5": 48,
    "scenario.OOS.5": 37,
    "scenario.NP.5": 85,
    "scenario.ADE.3": 57,
    "scenario.TP.3": 57,
    "scenario.AP.3": 57,
    "scenario.IE.3": 57,
    "scenario.TPR.3": 57,
    "scenario.ADE.4": 60,
    "scenario.TP.4": 60,
    "scenario.AP.4": 60,
    "scenario.IE.4": 60,
    "scenario.TPR.4": 60,
    "scenario.CF.0": 1,
    "scenario.CF.5": 34,
    "scenario.GSR.0": 2,
    "scenario.GSR.5": 35,
    "scenario.HCR.0": 62,
    "scenario.HCR.5": 63,
    "scenario.SIG.0": 64,
    "scenario.SIG.5": 67,
    "scenario.DSR1.0": 65,
    "scenario.DSR1.5": 66,
    "scenario.DSR2.0": 65,
    "scenario.DSR2.5": 66,
    "scenario.MC.0": 3,
    "scenario.MC.5": 36,
    "scenario.PA.0": 6,
    "scenario.PA.5": 39,
    "scenario.PD.0": 8,
    "scenario.PD.4": 13,
    "scenario.PD.2": 28,
    "scenario.PD.5": 41,
    "scenario.PD.3": 53,
    "scenario.PE.0": 7,
    "scenario.PE.4": 12,
    "scenario.PE.2": 27,
    "scenario.PE.5": 40,
    "scenario.PE.3": 52,
    "scenario.PI.0": 4,
    "scenario.PI.5": 37,
    "scenario.OOS.0": 4,
    "scenario.PR.0": 5,
    "scenario.PR.4": 11,
    "scenario.PR.2": 26,
    "scenario.PR.5": 38,
    "scenario.PR.3": 51,
    "scenario.RRA.0": 19,
    "scenario.RRA.5": 44,
    "scenario.RTS.0": 10,
    "scenario.RTS.5": 43,
    "scenario.RV1.0": 9,
    "scenario.RV1.4": 14,
    "scenario.RV1.2": 29,
    "scenario.RV1.5": 42,
    "scenario.RV1.3": 54,
    "scenario.RV2.0": 9,
    "scenario.RV2.4": 14,
    "scenario.RV2.2": 29,
    "scenario.RV2.5": 42,
    "scenario.RV2.3": 54,
    "scenario.SF.0": 20,
    "scenario.SF.4": 15,
    "scenario.SF.2": 30,
    "scenario.SF.5": 45,
    "scenario.SF.3": 55,
    "scenario.SLD.0": 22,
    "scenario.SLD.5": 47,
    "scenario.SR.0": 21,
    "scenario.SR.4": 16,
    "scenario.SR.2": 31,
    "scenario.SR.5": 46,
    "scenario.SR.3": 56,
    "scenario.VR.0": 24,
    "scenario.VR.4": 17,
    "scenario.VR.2": 33,
    "scenario.VR.5": 49,
    "scenario.VR.3": 58,
    "scenario.WB.0": 25,
    "scenario.WB.1": 25,
    "scenario.WB.4": 18,
    "scenario.WB.5": 50,
    "scenario.WB.3": 59,
    "scenario.SWB.0": 68,
    "scenario.SWB.4": 70,
    "scenario.REF.0": 69,
    "scenario.REF.4": 70,
    "scenario.SC.0": 71,
    "scenario.SC.5": 72,
    "scenario.RXC.0": 68,
    "scenario.RXC.5": 69,
    "scenario.PCR.0": 75,
    "scenario.PCR.5": 76,
    "scenario.RRE.0": 77,
    "scenario.RRE.4": 78,
    "scenario.RRE.2": 79,
    "scenario.RRE.5": 80,
    "scenario.RRE.3": 81,
    "scenario.DCR.0": 73,
    "scenario.DCR.5": 74,
    "scenario.HDR.0": 82,
    "scenario.HDR.5": 83,
    "scenario.default": 61
};

var BASKET_SCENARIO = {
    ACTION_STATUS: { // ID : DISPOSITION
        "1": "1",
        "8": "3",
        "9": "5",
        "7": "4",
        "2": "2",
        "4": "CANCEL_HANDOFF",
        "3": "OK"
    },
    STATUS_KEY: { // DISPOSITION : DISPOSITION KEY
        "1": "SLD",
        "2": "EXP",
        "3": "HWB",
        "4": "RTS",
        "5": "RPH",
        "OK": ""
    }
}

var TEMPLATE_MAP = {
    messages: {
        "6-2": "sms-enrollement",
        "8-1": "srd-pickup-id",
        "5-1": "ready-fill",
        "5-3": "ready-fill-unenroll",
        "5-4": "auto-fill-confirmation",
        "5-7": "ready-fill-lite",
        "5-8": "drive-ready-fill",
        "5-9": "message-90days",
        "4-1": "patient-counseling",
        "4-2": "patient-counseling",
        "6-3": "tcpa",
        "6-1": "extra-care",        
        "7-1": "patient-demographic",
        "2-2": "message-centric",
        "2-4": "message-centric",
        "2-10": "message-centric",
        "2-11": "message-centric",
        "2-12": "message-centric",
        "2-13": "message-centric",
        "5-14": "pcps",
        "5-15": "pcps",
        "5-16": "pcps",
        "5-12": "med-d",
        "0-5-8-0": "is-patient-present",
        "0-5-9-0": "is-patient-present"
    },
    rxScanMessages: {
        "0-0-0-2": {
            templateUrl: 'views/messages/basket/ipledge.html',
            modalCtrl: 'IPledgeMessageModalCtrl',
            windowClass: 'minor-popup'
        },
        "0-0-0-6":{
                templateUrl: 'views/messages/basket/cancelrx.html',//Add template to show unscanned Rx
                modalCtrl: 'cancelRxModalCtrl', //add controller that handles unscanned
                windowClass: 'minor-popup'
        },
        "1-*": {
            templateUrl: 'views/modals/active-note.html',//Add template to show action-notes
            modalCtrl: 'ActionNoteMessagesCtrl' //add controller that handles action-notes
        },
        "9-1": {
            templateUrl: 'views/modals/medicare_form.html',
            modalCtrl: 'tpComplianceController'
        },
        "5-13": {
            templateUrl: '',
            modalCtrl: ''
        },
        "5-10-12": {
            templateUrl: '',
            modalCtrl: ''
        },
        "5-11-1": {
            templateUrl: '',
            modalCtrl: ''
        }
    },
    rxSelectMessages:{
        "1-*": {
                templateUrl: 'views/modals/active-note.html',//Add template to show action-notes
                modalCtrl: 'ActionNoteMessagesCtrl' //add controller that handles action-notes
            },
        "0-*": {
                templateUrl: 'views/modals/basket-rx-item.html',//Add template to show action-notes
                modalCtrl: 'BasketRxItemModalCtrl' //add controller that handles action-notes
            }

    },
    completeOrderMessages:{
        "1-*": {
                templateUrl: 'views/modals/active-note.html',//Add template to show action-notes
                modalCtrl: 'ActionNoteMessagesCtrl' //add controller that handles action-notes
            },

        "0-0-0-3":{
                templateUrl: 'views/messages/basket/immunization.html' ,
                modalCtrl: 'ImmunizationCtrl',
                windowClass: 'minor-popup'
            },
        "0-0-0-4":{
                templateUrl: 'views/messages/basket/speciality.html' ,
                modalCtrl: 'SpecialityCtrl',
                windowClass: 'minor-popup'
            },
        "0-0-0-5":{
                templateUrl: 'views/modals/unscanned-rx-list.html',//Add template to show unscanned Rx
                modalCtrl: 'UnScannedRxModalCtrl' //add controller that handles unscanned
            },
        "0-0-0-6":{
                templateUrl: 'views/modals/canceledrx.html',//Add template to show unscanned Rx
                modalCtrl: 'cancelRxModalCtrl', //add controller that handles unscanned
                windowClass: 'minor-popup'
            }
    },
    alertMessages: {
        "A-A": {
            templateUrl: 'views/dialogs/is-patient-present.html',
            modalCtrl: 'IsPatientPresentModalCtrl',
            windowClass: 'minor-popup'
    }
    }
};

var MSG_TYPE_MAP = {
    '4': 'patCounslMsg'
};

var TP_COMPLIENCE_FORM_TYPES = {
    '1': 'AOB',
    '2': 'ABN',
    '3': 'RRP',
    '4': 'NIL'
};

var PAGE_TITLE = {
    login: 'LOGIN',
    password: 'PASSWORD'
};

var STATE_MAP = ['AB', 'BC', 'MB', 'NB', 'NF', 'NL', 'NS', 'NT', 'ON', 'PE', 'QC', 'SK', 'YT', 'CN', 'MX', 'US', 'AK', 'AL', 'AR', 'AZ', 'CA', 'CO', 'CT', 'DC', 'DE', 'FL', 'GA', 'HI', 'IA', 'ID', 'IL', 'IN', 'KS', 'KY', 'LA', 'MA', 'MD', 'ME', 'MI', 'MN', 'MO', 'MS', 'MT', 'NC', 'ND', 'NE', 'NH', 'NJ', 'NM', 'NV', 'NY', 'OH', 'OK', 'OR', 'PA', 'RI', 'SC', 'SD', 'TN', 'TX', 'UT', 'VA', 'VT', 'WA', 'WI', 'WV', 'WY', 'AS', 'FM', 'GU', 'MP', 'PR', 'PW', 'UM', 'VI', '99'];

var COUNTRY_MAP = ['US', 'CN'];

var PSE_ERROR_MESSAGE = {
    'PSE_INQUERY_FAIL': {
        'bodyText': 'PSE sale not authorized Product cannot be sold <br> Remove from bagging area',
        'headerText': 'PSE Purchase Error',
        'buttons': ['OK']
    },
    'PSE_SERVICE_FAIL': {
        'bodyText': 'Couldn\'t reach server',
        'headerText': 'Error',
        'buttons': ['OK']
    },
    'PSE_SERVICE_CANCEL': {
        'buttons': ['OK'],
        'headerText': '',
        'bodyText': 'Cashier canceled action.<br>Product cannot be sold.<br>Remove from bagging area'
    },
    'PSE_SERVICE_SCAN_CANCEL': {
        'buttons': ['OK'],
        'headerText': '',
        'bodyText': 'Cashier canceled action.<br>Product cannot be sold.<br>Remove from bagging area'
    },
    'PSE_CUSTOMER_SCAN_CANCEL': {
        'buttons': ['OK'],
        'headerText': '',
        'bodyText': 'Customer declines to sign PSE log.<br>Product cannot be sold.<br>Remove from bagging area'
    },
    'PSE_WARN_MESSAGE': {
        'buttons': ['Scan', 'Manual', 'Cancel'],
        'headerText': '',
        'bodyText': 'Restricted item - ID required. <br>Scan barcode or manually enter ID information'
    },
    'PSE_PURCHASE_ERROR_MESSAGE': {
        'buttons': ['OK'],
        'headerText': '',
        'bodyText': 'PSE sale/refund not authorized Product cannot be sold <br> Remove from bagging area and Void the Item'
    },
    'PSE_PURCHASE_TIMEOUT_MESSAGE': {
        'buttons': ['OK'],
        'headerText': '',
        'bodyText': 'PSE sale/refund timeout, <br/>Please try again in a few minutes.'
    },
    'PSE_REQUIRED_VALIDATION_MESSAGE': {
        'buttons': ['OK'],
        'headerText': 'Error',
        'bodyText': 'Invalid data. Value Required'
    },
    'UNKNOWN_PHARMACY': {
        'buttons': ['OK'],
        'headerText': 'Error',
        'bodyText': 'Due to a system issue we are unable to prcoess<br/>this transaction at this time.<br/>Please try again in a few minutes.'
    }

};


var SPECIALTY_ORDER_MESSAGE = {
    'SPECIALTY_COMPLETE_ORDER_FAIL': {
        'bodyText': 'All Specialty Items for the Specialty Order# needs to be sold',
        'headerText': 'Specialty Item Sale',
        'buttons': ['OK']
    },
    'SPECIALTY_PRICE_MODIFIY_ERROR': {
        'bodyText': 'The price of a Specialty Item may not be modified',
        'headerText': '',
        'buttons': ['OK']
    },
    'SPECIALTY_VOID_ITEM_ERROR': {
        'bodyText': 'Specialty Items may not be voided. To void this item.<br> you will need to void the entire transation',
        'headerText': '',
        'buttons': ['OK']
    },
    'SPECIALTY_REFUND_ITEM_ERROR': {
        'bodyText': 'Refund may not be issued for Specialty Items.',
        'headerText': '',
        'buttons': ['OK']
    },

}
var PSE_ERROR_CODE = {
    'PSE_SUCESS_CODE': '0000',
    'PSE_SUCESS_WARNING': '0003',
    'PSE_FAIL_CODE': '0004',
    'PSE_TIMEOUT_CODE': '0005'
};
