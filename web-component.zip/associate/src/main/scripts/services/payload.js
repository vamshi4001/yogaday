'use strict';

angular.module('weCarePlusApp')
    .service('PayloadService', ['BasketFactory', 'MessageFactory', 'CONFIG',
        function(BasketFactory, MessageFactory, CONFIG) {
            var _this = this;
            
            this.compileInStoreMessages = function() {
                var data =  {
                  "instoreCompileMessageRequest": {
                      "barcode": null,
                      "fillInfo": null,
                      "listOfPatientProfiles": BasketFactory.getPatientProfileList()
                    }
                };
                return data;
            };

            this.displayInStoreMessage = function() {
                var data = {
                    "instoreDisplayMessageRequest": {
                        "indexJustDisplayed": MessageFactory.getCurrentMessageIndex(),
                        "transactionCountProcessedBeforeCurrentSet": 0,
                        "txnStartTimestamp": CONFIG.messages.txnStartTimestamp,
                        "previousSetProcessed": false,
                        "txnCurrentTimestamp": appUtils.getCurrentTimestamp(),
                        "listOfLists": MessageFactory.getMasterMessageList()
                    }
                };
                return data;
            };

            // Compile Message when Rx Barcode Scan
            this.compileRxScanMessages = function(){
                
                var data = {
                    "RxInfoRequest": {
                        "barCode": BasketFactory.getScanedBarcode(),
                        "transactionType": "S",
                        "storeNumber": CONFIG.storeNumber,
                        "screenId": 1234,
                        "patientProfileList": BasketFactory.getPatientProfileList()
                    }
                };
                return data;                
            }

            //Display Message When Rx Barcode Scan 
            this.displayRxScanMessage = function(){
                var data = {
                    "rxScanDisplayMessageRequest": {
                        "indexJustDisplayed": MessageFactory.getCurrentMessageIndex(),
                        "transactionCountProcessedBeforeCurrentSet": 0,
                        "txnStartTimestamp": CONFIG.messages.txnStartTimestamp,
                        "previousSetProcessed": false,
                        "txnCurrentTimestamp": appUtils.getCurrentTimestamp(),
                        "listOfLists": MessageFactory.getMasterMessageList()
                    }
                };
                return data;
            }

            //Compile Message when Rx Script Select
            this.compileRxSelectMessages=function(){
                var data={
                    "rxSelectCompileMessageRequest":{
                          "barcode": null,
                          "fillInfo":BasketFactory.getSelectedPatientProfileFillInfo(),
                          "listOfPatientProfiles":BasketFactory.getPatientProfileList()
                    }
                };

                return data;
            }

            //Display Message when Rx Scritp Select
            this.displayRxSelectMessage=function(){
                var data = {
                    "rxSelectDisplayMessageRequest": {
                        "indexJustDisplayed": MessageFactory.getCurrentMessageIndex(),
                        "transactionCountProcessedBeforeCurrentSet": 0,
                        "txnStartTimestamp": CONFIG.messages.txnStartTimestamp,
                        "previousSetProcessed": false,
                        "txnCurrentTimestamp": appUtils.getCurrentTimestamp(),
                        "listOfLists": MessageFactory.getMasterMessageList()
                    }
                };
                return data; 
            }

            //Compile Message when Rx Script Select
            this.compileCompleteOrderMessages=function(){
                var data={
                    "completeOrderCompileMessageRequest":{
                          "barcode": null,
                          "fillInfo":null,
                          "listOfPatientProfiles":BasketFactory.getPatientProfileList()
                    }
                };

                return data;
            }

            //Display Message when Rx Scritp Select
            this.displayCompleteOrderMessage=function(){
                var data = {
                    "completeOrderDisplayMessageRequest": {
                        "indexJustDisplayed": MessageFactory.getCurrentMessageIndex(),
                        "transactionCountProcessedBeforeCurrentSet": 0,
                        "txnStartTimestamp": CONFIG.messages.txnStartTimestamp,
                        "previousSetProcessed": false,
                        "txnCurrentTimestamp": appUtils.getCurrentTimestamp(),
                        "listOfLists": MessageFactory.getMasterMessageList()
                    }
                };
                return data; 
            }

        }
    ]);
