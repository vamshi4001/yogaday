'use strict';

angular.module('weCarePlusApp')
    .service('HipaaService', ['CONFIG', 'Request', 'DialogService', '$socket', 'OrderFactory', 'PrintService', '$modal',
        function(CONFIG, Request, DialogService, $socket, OrderFactory, PrintService, $modal) {
            var service = {};
            var customerSigned = true;
            var patinetId;
            var phrEnrollmentBarcode;
            var hipaaInProcess = false;
            var extraCareCardNo;
            var esignData;

            service.enroll = function(opts) {
                esignData = '';
                hipaaInProcess = true;
                patinetId = opts.patinetId;
                phrEnrollmentBarcode = opts.phrEnrollmentBarcode;
                extraCareCardNo = opts.extraCareCardNo || OrderFactory.getEccNumber();
                customerSigned = true;
                var modalOptions = {
                    buttons: [],
                    headerText: 'Customer Terminal Processing',
                    bodyText: 'WAITING FOR CUSTOMER RESPONSE',
                    blockUI: true
                };
                DialogService.showDialog({}, modalOptions);
                $socket.send(JSON.stringify({
                    type: 'ESIG',
                    options: {
                        payload: {
                            displayText: '',
                            patientName: opts.patientName
                        },
                        route: 'phrEnroll'
                    }
                }), true).then(function(response) {
                    if (response.options.disagree) {
                        hipaaInProcess = false;
                        DialogService.closeDialog();
                        var modalOptions = {
                            buttons: ['OK'],
                            headerText: 'Information',
                            bodyText: 'Customer canceled Enrollment.',
                            blockUI: true
                        };
                        DialogService.showDialog({}, modalOptions).then(function(result) {});
                    } else {
                        DialogService.closeDialog();
                        if (response.options.noSignature) {
                            customerSigned = false;
                            var modalOptions = {
                                buttons: ['OK'],
                                headerText: '',
                                bodyText: 'Customer DID NOT sign electronically.',
                                blockUI: true
                            };
                            DialogService.showDialog({}, modalOptions).then(function(result) {
                                PrintService.doPrint(appConfig.store.services.API.printService.phrEnrollment, {});
                                service.showForm(response.options.esignData);
                            });
                        } else {
                            service.showForm(response.options.esignData);
                        }
                    }
                });
            };
            service.showForm = function(esign) {
                esignData = esign;
                $modal.open({
                    templateUrl: 'views/modals/hipaa-form.html',
                    keyboard: false,
                    /*windowClass: 'major-popup',*/
                    backdrop: false,
                    controller: 'HipaaFormModalCtrl',
                    resolve: {
                        'data': function() {
                            return {
                                patinetId: patinetId,
                                phrEnrollmentBarcode: phrEnrollmentBarcode,
                                customerSigned: customerSigned,
                                extraCareCardNo: extraCareCardNo
                            };
                        }
                    }
                });
            };
            service.getHipaaInProcess = function() {
                return hipaaInProcess;
            };
            service.setHipaaInProcess = function(data) {
                hipaaInProcess = data;
            };
            service.getEsignData = function() {
                return esignData;
            };
            return service;
        }
    ]);
