'use strict';

angular.module('weCarePlusApp')
    .service('PrintService', ['CONFIG', 'Request', function(CONFIG, Request) {
        var service = {
            doPrint: function(url, data, options) {
                url = url + "?q_name=" + CONFIG.registerData.printerQname;
                Request.invoke({
                    url: url,
                    method: 'POST',
                    data: data
                });
            }
        }
        return service;

    }]);
