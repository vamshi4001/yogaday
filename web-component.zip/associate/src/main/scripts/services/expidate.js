'use strict';

angular.module('weCarePlusApp')
    .service('ExpidateService', ['BasketFactory', 'CONFIG', '$location', 'Request',
        function(BasketFactory, CONFIG, $location, Request) {

           this.expidateScript=function(basketItemInfo){

			appUtils.log("Expedited service called on :" + JSON.stringify(basketItemInfo));
            var payload = {
                "ExpediteRequest": {
                    "rxNumber": basketItemInfo.rxNum,
                    "refillNumber": basketItemInfo.refillNum,
                    "editVersionNumber": basketItemInfo.editVersionNum,
                    "partialFillSeqNumber": basketItemInfo.partialFillSeqNum
                }
            };
            var expediteServiceRequest = Request.invoke({
                url: appConfig.store.services.API.expedite,
                method: 'POST',
                data: payload
            });
            expediteServiceRequest.then(function(result) {
                appUtils.log('expedite service is update with details');
            }, function(result) {
                appUtils.log('expedite Not able to service the request');
            });
           };


        }
    ]);