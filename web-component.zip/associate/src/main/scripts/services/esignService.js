'use strict';

angular.module('weCarePlusApp')
    .service('EsignService', ['ESignFactory', 'BasketFactory', 'CONFIG', '$location', 'Request',
        function(ESignFactory, BasketFactory, CONFIG, $location, Request) {

            var self = this;

            this.showEsign = function(payload) {
                if (!payload) {
                    payload = BasketFactory.getRxOrderData();
                }
                    
                var payloadData = {
                    'patientProfileListResponse':{
                        'patientProfileList': payload
                    }
                }

                var eSignConfigPromise = Request.invoke({
                    url: appConfig.store.services.API.eSignConfig,
                    method: 'POST',
                    data: payloadData
                });

                eSignConfigPromise.then(function(result) {
                    ESignFactory.buildEsignConfigData(result);
                    ESignFactory.setEsigMasterData(result);
                    $location.url('/esign-log');
                }, function(result, statusCode) {
                    //Error
                });
            }

            this.invokeEsign = function () {
                if (CONFIG.storeData.isOffline) {
                    $location.url('/esign-select');
                } else {
                    self.showEsign();
                }
            }

            this.getPaymentTerminalData = function () {
                var payloadData = {
                    'esignatureRegisterResponse': ESignFactory.getEsigMasterData()
                }

                var eSignPaymentPromise = Request.invoke({
                    url: appConfig.store.services.API.eSignConfigPayment,
                    method: 'POST',
                    data: payloadData
                });

                return eSignPaymentPromise;
            }

        }
    ]);
