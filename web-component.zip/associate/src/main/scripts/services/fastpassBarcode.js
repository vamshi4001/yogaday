'use strict';

angular.module('weCarePlusApp')
    .service('FastpassBarcode', function() {
        this.constants = {
            BAR_CODE_START : "91",
            BARCODE_TYPE_FAST_PASS : "02",
            VERSION_1 : "01",
            VERSION_2 : "02",
            LENGTH_FIXED_DEFINITION : 2,
            LENGTH_TYPE : 2,
            LENGTH_VERSION : 2,
            CONSTANT_ZERO : "0",
            
            INDICATOR_FAST_PASS : "F",
            INDICATOR_EXTRA_CARE:"E",
            INDICATOR_MCX:"M",
            INDICATOR_TRANS:"T",
            INDICATOR_CONN:"C",
            INDICATOR_USER:"U",
            INDICATOR_BARCODE_TYPE:"B",
            INDICATOR_VERSION:"V"
        };
        this.pattern1 = "910201" + "(" + this.constants.INDICATOR_FAST_PASS + "\\d+" + ")?"+
                         this.constants.INDICATOR_EXTRA_CARE + "\\d+" + "(" + this.constants.INDICATOR_MCX + "\\d+" + ")?";

        this.isFastPass = function (barcode)
        {
           return (barcode != null && barcode.startsWith('91') &&  (barcode.match(this.pattern1) || barcode.indexOf('\n') != -1)); 
        };

        this.parseBarcode = function(barcode) 
        {
             var result = {
                 barCode : null, 
                 type: null,
                 version: null,
                 fastPassID: null,
                 extraCareCard: null,
                 mcxID : "0",
                 transId : null,
                 connectivity : null,
                 userID : null,
                 mcxflag : null
             }
             if(!barcode || !(barcode.match(this.pattern1) || barcode.indexOf("\n") != -1 ))
             {
                return false;
             }
             if(barcode.match(this.pattern1))
             {
                result.type = barcode.substring(2,4);
                result.version = barcode.substring(4,6);
                var startIndex = barcode.indexOf(this.constants.INDICATOR_FAST_PASS); 
                if( startIndex > -1)
                {
                    result.fastPassID = this.getField(barcode, startIndex);
                }

                startIndex = barcode.indexOf(this.constants.INDICATOR_EXTRA_CARE);
                if(startIndex > -1)
                {
                   result.extraCareCard = this.getField(barcode, startIndex);
                }
                startIndex = barcode.indexOf(this.constants.INDICATOR_MCX);
                 
                if(startIndex > -1)
                {
                   result.mcxflag = this.getField(barcode, startIndex);
                }
                return result;
             }
             else if (barcode.match("^91\nB0"))
             {
                var tokens = barcode.split('\n');
                angular.forEach(tokens, function(value, index){
                    if(value.startsWith(this.constants.INDICATOR_BARCODE_TYPE))                    
                    {
                        result.type = value.substring(1);
                    }
                    else if (value.startsWith(this.constants.INDICATOR_VERSION))
                    {
                        result.version = value.substring(1);
                    }
                    else if (value.startsWith(this.constants.INDICATOR_FAST_PASS))
                    {
                        result.fastPassID = value.substring(1);
                    } 
                    else if (value.startsWith(this.constants.INDICATOR_EXTRA_CARE))
                    {
                        result.extraCareCard = value.substring(1);
                    }
                    else if (value.startsWith(this.constants.INDICATOR_MCX))
                    {
                        result.mcxflag = value.substring(1);
                    }
                    else if (value.startsWith(this.constants.INDICATOR_USER))
                    {
                        result.userID = value.substring(1);
                    }
                    else if (value.startsWith(this.constants.INDICATOR_TRANS))
                    {
                        result.transId = value.substring(1);
                    }
                    else if (value.startsWith(this.constants.INDICATOR_CONN))
                    {
                        result.connectivity = value.substring(1);
                    }
                }, this);
                return result;
             }
        }

        this.getField = function(barcode, index)
        {
            if(barcode.length > index+1)
            {
                var shorterVersion = barcode.substring(index + 1);
                var brokenParts = shorterVersion.match(/([0-9]*)([a-zA-Z]+)?/);
                if(brokenParts && brokenParts.length && brokenParts.length > 1)
                {
                    return brokenParts[1];
                }
                else
                {
                    return null;
                }
            }
            else
                return null;
        }
    });
