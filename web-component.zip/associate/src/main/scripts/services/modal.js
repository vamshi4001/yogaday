'use strict';

angular.module('weCarePlusApp')
    .service('ModalService', ['$q', '$modal', '$modalStack', function($q, $modal, $modalStack) {
        var modalDefaults = {
            backdrop: 'static',
            keyboard: true,
            animation: false
        };

        this.showModal = function(modalOptions, customOptions) {
            var deferred;
            customOptions = customOptions || {};
            if (customOptions.promise) {
                deferred = $q.defer();
                modalOptions.resolve = modalOptions.resolve || {};
                modalOptions.resolve.deferred = function() {
                    return deferred;
                };
            }
            angular.extend(modalOptions, modalDefaults);
            $modal.open(modalOptions);
            if (deferred) {
                return deferred.promise;
            }
        };

        this.closeAll = function() {
            $modalStack.dismissAll();
        };
    }]);
