'use strict';

angular.module('weCarePlusApp')
    .service('PseService', ['Request', 'DialogService', 'CONFIG', 'PseFactory', '$filter', function(Request, DialogService, CONFIG, PseFactory, $filter) {

        var pseService = {};
        var inquiryResult = {};
        //pse Inquery Request
        pseService.inqueryPseItem = function(payload) {
            var pseInquiryPromise = Request.invoke({
                url: appConfig.store.services.API.pseInquiry,
                method: 'POST',
                data: payload
            });
            return pseInquiryPromise;
        };

        pseService.doPseDecline = function(payload) {
            var pseDeclinePromise = Request.invoke({
                url: appConfig.store.services.API.pseDecline,
                method: 'POST',
                data: payload
            });
            return pseDeclinePromise;
        };

        //Pse Purchanse Request
        pseService.purchansePseItem = function(payload) {
            var psePurchasePromise = Request.invoke({
                url: appConfig.store.services.API.psePurchase,
                method: 'POST',
                data: payload
            });
            return psePurchasePromise;
        };

        //Pse Purchanse Request
        pseService.returnPseItem = function(payload) {
            var pseReturnPromise = Request.invoke({
                url: appConfig.store.services.API.pseReturn,
                method: 'POST',
                data: payload
            });
            return pseReturnPromise;
        };

        //Pse Identy Scan issue
        pseService.licenseScanRequest = function(payload) {
            var identityScanPromise = Request.invoke({
                url: appConfig.store.services.API.pseLicense,
                method: 'POST',
                data: payload
            });

            identityScanPromise.then(function(identityResult) {
                PseFactory.setIdentityInfo(identityResult.driversLicense);
                PseFactory.setIdentityPayload(payload);
                return identityResult;
            }, function(result) {
                return result;
            });
        };

        //pse esin compress service
        pseService.esinServiceRequest = function(payload) {
            var eSigCompPromise = Request.invoke({
                url: appConfig.store.services.API.esigCompression,
                method: 'POST',
                data: payload
            });
            return eSigCompPromise;
        };


        pseService.validatePseItems = function(identityData, idnumber, state, idType) {

            var pseItems = PseFactory.getCurrentOrderList() || [];
            var inquiryPayload = angular.copy(PseFactory.getInquiryRequestPayload());
            inquiryPayload.PseInquiryRequest.idScan = identityData;
            //update person Information 

            var personInfoData = {
                "id": idnumber ? idnumber : '',
                "idType": idType ? idType : '',
                "issuingAgency": state ? state : '',
                "expiration": "",
                "lastName": "",
                "firstName": "",
                "middleName": "",
                "birthDate": "",
                "address1": "",
                "city": "",
                "state": idType !== 'PASSPORT' ? state : '',
                "zip": ""
            };

            inquiryPayload.PseInquiryRequest.objPersonInfo = Object.keys(PseFactory.getIdentityInfo()).length > 1 ? angular.copy(PseFactory.getIdentityInfo()) : personInfoData;
            //Need to revalidate the logic
            angular.forEach(pseItems, function(pseItem) {
                var item = {
                    "upc": pseItem.upc ? pseItem.upc : "",
                    "productName": pseItem.description,
                    "ndcnumber": null,
                    "gramsPerBox": pseItem.pseGramsPerBox,
                    "pillsperbox": 0,
                    "dosagesperbox": 0,
                    "producttype": null,
                    "pediatric": false,
                    "boxes": 1
                };

                inquiryPayload.PseInquiryRequest.inquiryDetail.push(item);

            });

            var pharmacyTech = appUtils.prepandZeros(CONFIG.loggedInUser.id, 10) +
                        '/1/0/' + appUtils.prepandZeros(PseFactory.getRphName(), 11) + '/00';
            inquiryPayload.PseInquiryRequest.pharmacyInfo.pharmacyTech = appUtils.prepandZeros(pharmacyTech, 50);
            inquiryPayload.PseInquiryRequest.pharmacyInfo.pharmacistApproval = appUtils.prepandZeros(PseFactory.getTrackedEmployee(), 10);
            

            return pseService.inqueryPseItem(inquiryPayload);
        };

        pseService.buildPsePurchaseRequest = function(type) {
            var pseItems = PseFactory.getCurrentOrderList() || [];
            var purchasePayload = angular.copy(PseFactory.getPsePurchaseRequestPayload());
            purchasePayload.PsePurchaseRequest.timeStamp = appUtils.getCurrentTimestamp();
            purchasePayload.PsePurchaseRequest.personInfo = PseFactory.getIdentityInfo();
            purchasePayload.PsePurchaseRequest.personInfo.expiration=PseFactory.getIdentityInfo().expiration ? $filter('date')(new Date(PseFactory.getIdentityInfo().expiration), 'yyyy-MM-dd', "UTC") : '';
            purchasePayload.PsePurchaseRequest.personInfo.city = PseFactory.getIdentityInfo().city ? PseFactory.getIdentityInfo().city : '';
            purchasePayload.PsePurchaseRequest.personInfo.birthDate = PseFactory.getIdentityInfo().birthDate ? $filter('date')(new Date(PseFactory.getIdentityInfo().birthDate), 'yyyy-MM-dd') : '';

            // RJ - Zero filled; CCCCCCCCCC/S/K/PPPPPPP/TT
            // C - Ten digit Cashier Signon Id
            // S - Status, 1 for Pharmacist Id on file, 0 for Not-On-File
            // K - RPh id Keyed (0) or Scanned (1)
            // P - Seven digit RPh Employee Id
            // T - Two digit temp Id (Zeroes, if badge is scanned)

            var pharmacyTech = appUtils.prepandZeros(CONFIG.loggedInUser.id, 10) +
                                    '/1/0/' + appUtils.prepandZeros(PseFactory.getRphName(), 11) + '/00';
            purchasePayload.PsePurchaseRequest.pharmacyInfo.pharmacyTech = appUtils.prepandZeros(pharmacyTech, 50);
            purchasePayload.PsePurchaseRequest.pharmacyInfo.pharmacistApproval = appUtils.prepandZeros(PseFactory.getTrackedEmployee(), 10);
            
            if (type === 'PURCHASE') {
                angular.forEach(pseItems, function(pseItem) {
                var item = {
                    "upc": pseItem.upc ? pseItem.upc : "",
                    "productName": pseItem.description,
                    "ndcnumber": null,
                    "gramsPerBox": pseItem.pseGramsPerBox,
                    "pillsperbox": 0,
                    "dosagesperbox": 0,
                    "producttype": null,
                    "pediatric": false,
                    "boxes": 1
                };
                purchasePayload.PsePurchaseRequest.purchase.purchaseDetail.push(item);
                });
                purchasePayload.PsePurchaseRequest.signature.value = PseFactory.getCompressedCustomSign();
                return pseService.purchansePseItem(purchasePayload);
            } else if (type === 'DECLINE') {
                var pseItem = pseItems[pseItems.length - 1];
                var item = {
                    "upc": pseItem.upc ? pseItem.upc : "",
                    "productName": pseItem.description,
                    "ndcnumber": null,
                    "gramsPerBox": pseItem.pseGramsPerBox,
                    "pillsperbox": 0,
                    "dosagesperbox": 0,
                    "producttype": null,
                    "pediatric": false,
                    "boxes": 1
                };
                purchasePayload.PsePurchaseRequest.purchase.purchaseDetail.push(item);
                //For decline signature should be empty
                purchasePayload.PsePurchaseRequest.signature = {};
                if(pseItems.length > 1)
                    return pseService.doPseDecline(purchasePayload);
                else 
                    return false;
            } else if (type === 'DECLINE_ALL') {
                angular.forEach(pseItems, function(pseItem) {
                var item = {
                    "upc": pseItem.upc ? pseItem.upc : "",
                    "productName": pseItem.description,
                    "ndcnumber": null,
                    "gramsPerBox": pseItem.pseGramsPerBox,
                    "pillsperbox": 0,
                    "dosagesperbox": 0,
                    "producttype": null,
                    "pediatric": false,
                    "boxes": 1
                };

                purchasePayload.PsePurchaseRequest.purchase.purchaseDetail.push(item);

                });
                purchasePayload.PsePurchaseRequest.signature = {};
                return pseService.doPseDecline(purchasePayload);
            }
        };

        pseService.mergePersonInfo = function(newVersion, factoryVersion)
        {
            var toReturn = {
                id: factoryVersion.id || newVersion.id,
                idType: factoryVersion.idType || newVersion.idType,
                issuingAgency: factoryVersion.issuingAgency || newVersion.issuingAgency,
                expiration: factoryVersion.expiration || newVersion.expiration,
                lastName: factoryVersion.lastName || newVersion.lastName,
                firstName: factoryVersion.firstName || newVersion.firstName,
                middleName: factoryVersion.middleName || newVersion.middleName,
                birthDate: factoryVersion.birthDate || newVersion.birthDate,
                address1: factoryVersion.address1 || newVersion.address1,
                city: factoryVersion.city || newVersion.city,
                state: factoryVersion.state || newVersion.state,
                zip: factoryVersion.zip || newVersion.zip
            };
            return toReturn;
        }


        pseService.buildPseReturnPurchaseRequest = function() {
            var pseItems = PseFactory.getCurrentOrderList() || [];
            var pseReturnRequest = angular.copy(PseFactory.getPseReturnRequestPayload());
            pseReturnRequest.PseReturnRequest.transactionTime = appUtils.getCurrentTimestamp();
            pseReturnRequest.PseReturnRequest.returnedItems.postSale=true;
            if(PseFactory.getIdentityScanData())
            {
                pseReturnRequest.PseReturnRequest.idScan = PseFactory.getIdentityScanData() ? PseFactory.getIdentityScanData() : '';
            }
            else
            {
            pseReturnRequest.PseReturnRequest.personInfo = Object.keys(PseFactory.getIdentityInfo()).length > 1 ? PseFactory.getIdentityInfo() : {};
            pseReturnRequest.PseReturnRequest.personInfo.city=PseFactory.getIdentityInfo().city? PseFactory.getIdentityInfo().city:'';
            pseReturnRequest.PseReturnRequest.personInfo.expiration=PseFactory.getIdentityInfo().expiration ? $filter('date')(new Date(PseFactory.getIdentityInfo().expiration), 'yyyy-MM-dd', "UTC") : '';
            pseReturnRequest.PseReturnRequest.personInfo.birthDate=PseFactory.getIdentityInfo().birthDate ? $filter('date')(new Date(PseFactory.getIdentityInfo().birthDate), 'yyyy-MM-dd', "UTC"): '';
            }

            angular.forEach(pseItems, function(pseItem) {
                var item = {
                    "upc": pseItem.upc ? pseItem.upc : "",
                    "productName": pseItem.description,
                    "ndcnumber": null,
                    "gramsPerBox": pseItem.pseGramsPerBox,
                    "pillsperbox": 0,
                    "dosagesperbox": 0,
                    "producttype": null,
                    "pediatric": false,
                    "boxes": 1
                };

                pseReturnRequest.PseReturnRequest.returnedItems.purchaseDetail.push(item);

            });

            return pseService.returnPseItem(pseReturnRequest);

        };
        return pseService;
    }]);
