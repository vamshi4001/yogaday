'use strict';

angular.module('weCarePlusApp')
    .service('NumberEntryService', ['$modal', function($modal) {


        var modalDefaults = {
            backdrop: true,
            keyboard: true,
            modalFade: true,
            windowClass: 'major-popup',
            templateUrl: 'views/modals/helpBarcodeEntry.html'
        };

        var modalInstance = {};

        var modalOptions = {
            // can have a maximum of six buttons in the UI.
            inputText: 'Enter Data',
            headerText: 'Enter here',
            maxInputLength: 24
        };

        this.showDialog = function(customModalDefaults, customModalOptions) {
            customModalDefaults = customModalDefaults || {};
            customModalDefaults.backdrop = 'static';
            return this.show(customModalDefaults, customModalOptions);
        };

        this.closeDialog = function() {
            if (modalInstance) {
                modalInstance.close();
            }
        };

        this.show = function(customModalDefaults, customModalOptions) {
            //Create temp objects to work with since we're in a singleton service
            var tempModalDefaults = {};
            var tempModalOptions = {};

            //Map angular-ui modal custom defaults to modal defaults defined in service
            angular.extend(tempModalDefaults, modalDefaults, customModalDefaults);

            //Map modal.html $scope custom properties to defaults defined in service
            angular.extend(tempModalOptions, modalOptions, customModalOptions);

            if (!tempModalDefaults.controller) {
                tempModalDefaults.controller = function($scope, $modalInstance, DialogService) {

                    $scope.modalOptions = tempModalOptions;
                    modalInstance = $modalInstance;

                    $scope.sendValue = function(inputValue) {
                        if (inputValue) {
                            if($scope.modalOptions.thresholdValue){
                                if((parseInt(inputValue) / 100).toFixed(2) <= $scope.modalOptions.thresholdValue){
                                    $modalInstance.close(inputValue);
                                }
                                else{
                                    var modalOptions = {
                                        buttons: ['OK'],
                                        headerText: 'Error',
                                        bodyText: $scope.modalOptions.thresholdValueAlertText || 'Amount exceeds maximum limit'
                                    };
                                    DialogService.showDialog({}, modalOptions).then(function(result) {});    
                                }
                            } 
                            else{
                                $modalInstance.close(inputValue);
                            }
                        } else {
                            var modalOptions = {
                                buttons: ['OK'],
                                headerText: 'Warning',
                                bodyText: 'Data is required for this field'
                            };
                            DialogService.showDialog({}, modalOptions).then(function(result) {});
                        }
                    };
                    $scope.closeDialog = function() {
                        if (customModalOptions.cancelConfirm) {
                            var modalOptions = {
                                buttons: ['Yes', 'No'],
                                headerText: 'Cancel',
                                bodyText: 'Are you sure you want to Cancel?'
                            };
                            DialogService.showDialog({}, modalOptions).then(function(result) {
                                if (result == 'Yes') {
                                    $modalInstance.dismiss();
                                } else {
                                    return;
                                }
                            });
                        } else {
                            $modalInstance.dismiss();
                        }
                    };
                };
            }
            return $modal.open(tempModalDefaults).result;
        };

    }]);
