'use strict';

angular.module('weCarePlusApp')
    .service('MonitorService', ['CONFIG', '$http', function(CONFIG, $http) {
        var dataDefaults = {
                            message:"UI Alert",
                            detailMessages:["Generic alert"],
                            status:"NEW",
                            alertLevel:"HIGH"
                        };
        var service = {
            sendAlert: function(data) {
                // var newData = angular.extend({}, dataDefaults, data);
                // newData.messageId = 0;
                // newData.component = CONFIG.componentType;
                // var url = appConfig.store.services.API.monitorService;
                // $http.put(url, newData);
            }
        }
        return service;

    }]);
