'use strict';

angular.module('weCarePlusApp')
    .service('FormValidationService', ['$modal', 'CONFIG', function($modal, CONFIG) {
        var validate = {};
        var errorMessageList = [];
        //SRD
        var state;
        var idFieldRules = {};
        var country;
        var relationShipDetails = [];
        var fieldLabelValidationRuleMap = {};

        var ERROR_MESSAGE_MAP = {
            'VALIDATION_TYPE_REQUIRED': 'The value cannot be empty, Please give valid input.',
            'VALIDATION_TYPE_MIN_LENGTH': 'Minimum length requirement not met.',
            'VALIDATION_TYPE_MAX_LENGTH': 'Maximum length exceeded.',
            'VALIDATION_TYPE_INVALID_CHAR': 'Invalid character found.',
            'VALIDATION_TYPE_CHARACTERS': 'Invalid characters found.',
            'VALIDATION_TYPE_REPEAT_CHARACTERS': 'Repeat characters found.',
            'VALIDATION_TYPE_SEQUENCE_CHARACTERS': 'Sequencial characters/Space Not Allowed found.',
            'VALIDATION_TYPE_STATE': 'Invalid state.',
            'VALIDATION_TYPE_JURISDICTION': 'Invalid Jurisdiction ID.',
            'VALIDATION_TYPE_INVALID_ZIP_CODE_LENGTH': 'Zip code must be 5-digits, please re-enter',
            'VALIDATION_TYPE_COUNTRY': 'Invalid country. Should be US/CN',
            'VALIDATION_TYPE_EXCLUSION': 'The value is not allowed.',
            'VALIDATION_TYPE_PREFIX': 'The value does not contain a required prefix.',
            'VALIDATION_TYPE_SUFFIX': 'The value does not contain a required suffix.',
            'VALIDATION_TYPE_INVALID_DATE': 'The date entered is not valid.',
            'VALIDATION_TYPE_PAST_EXPIRATION_DATE': 'Expiration date must be after today\'s date.',
            'VALIDATION_TYPE_PAST_MAX_EXPIRATION_DATE': 'Expiration date cannot be greater than 12/31/2099.',
            'VALIDATION_TYPE_INVALID_DOB_PAST': 'Date of Birth must be greater than or equal to 1900.',
            'VALIDATION_TYPE_INVALID_DOB_FUTURE': 'Date of Birth should between 1900 and not future date.',
            'VALIDATION_TYPE_INVALID_DOB': 'The Date of Birth entered is invalid.',
            'VALIDATION_TYPE_EXPIRATION_DATE': 'The expiration date is invalid.',
            'VALIDATION_TYPE_INVALID_CITY_CHARS': 'City cannot contain numbers or symbols. Please re-enter.',
            'VALIDATION_TYPE_INVALID_FNAME_CHARS': 'First name cannot contain numbers or symbols. Please re-enter.',
            'VALIDATION_TYPE_INVALID_LNAME_CHARS': 'Last name cannot contain numbers or symbols. Please re-enter.',
            'VALIDATION_TYPE_INVALID_ALFANUMERIC': 'Only alpha-numeric characters are allowed.',
            'VALIDATION_TYPE_INVALID_ALFA': 'Only alpha characters are allowed.',
            'VALIDATION_TYPE_INVALID_NUMERIC': 'Only numeric characters are allowed.',
            'VALIDATION_TYPE_INVALID_DOB_FOR_PSE':'Birth Date: 18YRS TO PURCHASE CUSTOMER UNDERAGE'
        };

        var WIDCARD = "%";

        var firstNameFieldDefaults = {
            maxLength: 19,
            allowedChars: ["'", "-", " "]
        };
        var lastNameFieldDefaults = {
            maxLength: 19,
            allowedChars: ["'", "-", " "]
        };
        var stateValidateDefaults = {
            maxLength: 2,
            allowedChars: []
        };
        var countryValidateDefaults = {
            maxLength: 2,
            minLenth: 2
        };

        var zipcodeValidateDefaults = {
            exactLength: true,
            onlyDights: true,
            minLenth: 5
        };
        //as per the DOB validation
        var dobValidateDefaults = {
            minDate: new Date(Date.parse("11/31/1899")),
            maxDate: new Date()
        };
        //expirationDate field validation
        var expirationDateFieldValidation = {
            minDate: new Date(),
            maxDate: new Date(Date.parse("11/31/2099"))
        };

        //city field validation
        var cityFieldValidation = {
            minLenth: 1,
            maxLength: 20
        };

        //Steet Validation
        var streetFieldValidation = {
            minLenth: 1,
            maxLength: 32
        };

        validate.doValidate = function(fieldKey, fieldValue, opts) {
            errorMessageList = [];
            fieldLabelValidationRuleMap[fieldKey] && fieldLabelValidationRuleMap[fieldKey](fieldValue);
            return errorMessageList;

        };

        validate.setState = function(data) {
            state = data;
        };

        validate.setCountry = function(data) {
            country = data;
        }

        validate.setIdFieldRules = function(data) {
            idFieldRules = data;
        };

        validate.setRelationShipRules = function(data) {
            relationShipDetails = data;
        };

        //validate ID validation 
        validate.validatePseID = function(data) {
            var isIdFieldValid = false;
            if (data) {
                if (validate.validateMinLenth(data, 4)) {
                    isIdFieldValid = true;
                } else {
                    errorMessageList.push(ERROR_MESSAGE_MAP['VALIDATION_TYPE_MIN_LENGTH']);
                    isIdFieldValid = false;
                }

                if (validate.validateMaxLenth(data, 20)) {
                    isIdFieldValid = true;
                } else {
                    errorMessageList.push(ERROR_MESSAGE_MAP['VALIDATION_TYPE_MAX_LENGTH']);
                    isIdFieldValid = false;
                }

                if (validate.validateAlphaNumaric(data)) {
                    isIdFieldValid = true;
                } else {
                    isIdFieldValid = false;
                }
                return isIdFieldValid;
            } else {
                errorMessageList.push('ID not entered.');
            }
            return false;
        };
        //Id Field Valiation need to pass the id details as json
        validate.validateIdFormat = function(idValue) {
            var isIdFieldValid = false;
            if (idValue && idFieldRules) {
                if (idFieldRules.exclusionList && idFieldRules.exclusionList.length > 1) {
                    // if exclusion list faild
                    if (!validate.validateExclusionList(idValue, idFieldRules.exclusionList)) {
                        isIdFieldValid = true;
                    } else {
                        errorMessageList.push(ERROR_MESSAGE_MAP['VALIDATION_TYPE_EXCLUSION']);
                        return;
                    }
                }

                if (idFieldRules.inclusionList && idFieldRules.inclusionList.length > 1) {
                    var inclusionList = idFieldRules.inclusionList.split(";");
                    var InclusionListData = [];
                    angular.forEach(inclusionList, function(includeValue) {
                        InclusionListData.push(includeValue.substring(1, includeValue.length - 1));
                    });
                    angular.forEach(InclusionListData, function(includeValue) {
                        if (idValue.search(includeValue) > 0) {
                            isIdFieldValid = true;
                        } else {
                            errorMessageList.push();
                            isIdFieldValid = false;
                        }
                    });
                }

                //Need to check rx mask validation for id filed

                //Min length
                if (idFieldRules.idFormat && idFieldRules.idFormat.minLength) {
                    if (validate.validateMinLenth(idValue, idFieldRules.idFormat.minLength)) {
                        isIdFieldValid = true;
                    } else {
                        errorMessageList.push(ERROR_MESSAGE_MAP['VALIDATION_TYPE_MIN_LENGTH']);
                        return;
                    }
                }

                //Max length
                if (idFieldRules.idFormat && idFieldRules.idFormat.maxLength) {
                    if(idFieldRules.idFormat.maxLength === idFieldRules.idFormat.minLength) {
                        idFieldRules.idFormat.maxLength++;
                    }
                    if (validate.validateMaxLenth(idValue, idFieldRules.idFormat.maxLength)) {
                        isIdFieldValid = true;
                    } else {
                        errorMessageList.push(ERROR_MESSAGE_MAP['VALIDATION_TYPE_MAX_LENGTH']);
                       return;
                    }
                }

                //special char
                if (idFieldRules.validations && idFieldRules.validations.spaceNotAllowed) {
                    if (idFieldRules.validations.spaceNotAllowed) {
                        isIdFieldValid = validate.validateInvalidChar(idValue, " ");
                        if (isIdFieldValid) {
                            errorMessageList.push(ERROR_MESSAGE_MAP['VALIDATION_TYPE_SEQUENCE_CHARACTERS']);

                        }
                    }
                }

                if (country && idFieldRules.idFormat && idFieldRules.idFormat.countryCodePrefix) {
                    //country prefix
                    if (idFieldRules.idFormat.countryCodePrefix) {
                        isIdFieldValid = validate.validatePrefixValidation(idValue, country, 2);
                        if (!isIdFieldValid) {
                            errorMessageList.push(ERROR_MESSAGE_MAP['VALIDATION_TYPE_PREFIX']);
                            return;
                        }
                    }
                    //country code suffix
                    if (idFieldRules.idFormat.countryCodeSuffix) {
                        isIdFieldValid = validate.validateSuffixValidation(idValue, country, 2);
                        if (!isIdFieldValid) {
                            errorMessageList.push(ERROR_MESSAGE_MAP['VALIDATION_TYPE_SUFFIX']);
                            return;
                        }
                    }
                }
                //state code prefix
                if (idFieldRules.idFormat && idFieldRules.idFormat.stateCodePrefix) {
                    isIdFieldValid = validate.validatePrefixValidation(idValue, idValue.substring(0, 2), 2);
                    if (!isIdFieldValid) {
                        errorMessageList.push(ERROR_MESSAGE_MAP['VALIDATION_TYPE_PREFIX']);
                        return;
                    }
                }

                //state code suffix
                if (idFieldRules.idFormat && idFieldRules.idFormat.stateCodeSuffix) {
                    isIdFieldValid = validate.validateSuffixValidation(idValue, idValue.substring(0, 2), 2);
                    if (!isIdFieldValid) {
                        errorMessageList.push(ERROR_MESSAGE_MAP['VALIDATION_TYPE_SUFFIX']);
                        return;
                    }
                }
                //mil code prefix 
                if (idFieldRules.idFormat && idFieldRules.idFormat.milCodePrefix) {
                    isIdFieldValid = validate.validatePrefixValidation(idValue, 'MIL', 3);
                    if (!isIdFieldValid) {
                        errorMessageList.push(ERROR_MESSAGE_MAP['VALIDATION_TYPE_PREFIX']);
                        return;
                    }
                }

                //mil code suffix
                if (idFieldRules.idFormat && idFieldRules.idFormat.milCodeSuffix) {
                    isIdFieldValid = validate.validateSuffixValidation(idValue, 'MIL', 3);
                    if (!isIdFieldValid) {
                        errorMessageList.push(ERROR_MESSAGE_MAP['VALIDATION_TYPE_SUFFIX']);
                        return;
                    }
                }
                return isIdFieldValid;
            } else {
                errorMessageList.push('ID not entered.');
                return;
            }
            return false;
        }

        validate.validateRelationShip = function(relationId) {
            if (relationId) {
                if (!relationShipDetails.length) {
                    return true;
                }
                if (validate.isValueInList(relationId, relationShipDetails)) {
                    return true;
                } else {
                    errorMessageList.push(ERROR_MESSAGE_MAP['VALIDATION_TYPE_EXCLUSION']);
                    return false;
                }
            }
        };
        //First Name validatoion 
        validate.validateFirstName = function(name) {
            if (name) {
                if (validate.validateName(name, 1, firstNameFieldDefaults.maxLength)) {
                    return true;
                } else {
                    errorMessageList.push(ERROR_MESSAGE_MAP['VALIDATION_TYPE_INVALID_FNAME_CHARS']);
                    return false;
                }
            }
        };
        //City validation 
        validate.validateCity = function(name) {
            if (name) {
                if (validate.validateName(name, cityFieldValidation.minLenth, cityFieldValidation.maxLength)) {
                    return true;
                } else {
                    errorMessageList.push(ERROR_MESSAGE_MAP['VALIDATION_TYPE_INVALID_CITY_CHARS']);
                    return false;
                }
            }
        };
        // DOB Validation 
        validate.validateDOB = function(dob) {
            if (dob) {
                var result = validate.validateBetweenDate(dob, dobValidateDefaults.minDate, dobValidateDefaults.maxDate);
                if (result === 'SUCCESS') {
                    return true;
                } else if (result === 'ERROR') {
                    errorMessageList.push(ERROR_MESSAGE_MAP['VALIDATION_TYPE_INVALID_DOB_FUTURE']);
                    return false;
                } else {
                    errorMessageList.push(ERROR_MESSAGE_MAP['VALIDATION_TYPE_INVALID_DOB']);
                    return false;
                }
            }
        };

         // DOB Validation 
        validate.validatePSEDOB = function(dob) {
            if (dob) {

                var pseresult=validate.validateAgeForSudoDrug(dob);
                if(pseresult==='SUCCESS'){
                        return true;
                }else if(pseresult ==='ERROR'){
                    errorMessageList.push(ERROR_MESSAGE_MAP['VALIDATION_TYPE_INVALID_DOB_FOR_PSE']);
                    return false;
                }

                var result = validate.validateBetweenDate(dob, dobValidateDefaults.minDate, dobValidateDefaults.maxDate);
                if (result === 'SUCCESS') {
                    return true;
                } else if (result === 'ERROR') {
                    errorMessageList.push(ERROR_MESSAGE_MAP['VALIDATION_TYPE_INVALID_DOB_FUTURE']);
                    return false;
                } else {
                    errorMessageList.push(ERROR_MESSAGE_MAP['VALIDATION_TYPE_INVALID_DOB']);
                    return false;
                }

                
            }
        };

        validate.validateAgeForSudoDrug=function(data){
            var today = new Date();
            var birthDate = appUtils.isValidDate(data);
            var age = today.getFullYear() - birthDate.getFullYear();
            var m = today.getMonth() - birthDate.getMonth();
            if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
                age--;
            }

            if(age < 18) {
                return 'ERROR';
            }
            else {
                return 'SUCCESS';
            }

        };
        //Expiration Date validation 
        validate.validateExpiration = function(date) {
            if (date) {
                var result = validate.validateBetweenDate(date, expirationDateFieldValidation.minDate, expirationDateFieldValidation.maxDate);
                if (result === 'SUCCESS') {
                    return true;
                } else {
                    errorMessageList.push(ERROR_MESSAGE_MAP['VALIDATION_TYPE_EXPIRATION_DATE']);
                    return false;
                }
            }
        };
        validate.validateCountry = function(country) {
            if (country) {
                var result = COUNTRY_MAP.indexOf(country);
                if (result > -1) {
                    return true;
                } else {
                    errorMessageList.push(ERROR_MESSAGE_MAP['VALIDATION_TYPE_COUNTRY']);
                    return false;
                }
            }
        };
        //Zip Code validation 
        validate.validateZip = function(zipcode) {
            if (zipcode) {
                if (validate.validateNumaric(zipcode) && validate.validateMinLenth(zipcode, zipcodeValidateDefaults.minLenth)) {
                    return true;
                } else {
                    errorMessageList.push(ERROR_MESSAGE_MAP['VALIDATION_TYPE_INVALID_ZIP_CODE_LENGTH']);
                    return false;
                }
            }
        };
        //street validation 
        validate.validateStreetField = function(street) {
            if (street) {
                if (validate.validateMinLenth(street, streetFieldValidation.minLenth) && 
                        validate.validateMinLenth(street, streetFieldValidation.maxLength))
                {
                    if (street.match(/^[a-zA-Z0-9-\/] ?([a-zA-Z0-9-\/]|[a-zA-Z0-9-\/] )*[a-zA-Z0-9-\/]$/)) {
                        return true;
                    }
                }
            }
            return false;
        };

        //Validate Name
        validate.validateName = function(name, minLenth, maxLength, allowedChars) {
            name = name.trim();
            if (name.length >= minLenth && name.length < maxLength && validate.validateAlpha(name)) {
                return true;
            }
            return false;
        };
        //Alpha validation
        validate.validateAlpha = function(name) {
            if (name.match(/^[a-zA-Z\s]+$/)) {
                return true;
            }
            errorMessageList.push(ERROR_MESSAGE_MAP['VALIDATION_TYPE_INVALID_ALFA']);
            return false;
        };

        // Alpha Numaric 
        validate.validateAlphaNumaric = function(name) {
            if (name.match(/^[0-9a-zA-Z]+$/)) {
                return true;
            }
            errorMessageList.push(ERROR_MESSAGE_MAP['VALIDATION_TYPE_INVALID_ALFANUMERIC']);
            return false;

        };

        //Numaric validation 
        validate.validateNumaric = function(zipcode) {
            if (zipcode.match(/^[0-9]+$/)) {
                return true;
            }
            errorMessageList.push(ERROR_MESSAGE_MAP['VALIDATION_TYPE_INVALID_NUMERIC']);
            return false;
        };

        //Between Validation
        validate.validateBetweenDate = function(userDate, fromDate, toDate) {
            userDate = appUtils.isValidDate(userDate);
            if (userDate) {
                if (userDate >= fromDate && userDate <= toDate) {
                    return 'SUCCESS';
                }
                return 'ERROR';
            }
            return 'INVALID';
        };

        //state validation
        validate.validateState = function(name) {
            if (name) {
                if (STATE_MAP.indexOf(name) > -1 && validate.validateAlpha(name)) {
                    return true;
                }
            }
            errorMessageList.push(ERROR_MESSAGE_MAP['VALIDATION_TYPE_STATE']);
            return false;
        };
        //min Length validaiton 
        validate.validateMinLenth = function(field, minLenth) {
            field = field + "";
            if (field && minLenth) {
                if (field.length >= minLenth) {
                    return true;
                }
            }
            return false;
        };

        //max length validation
        validate.validateMaxLenth = function(field, maxLength) {
            field = field + "";
            if (field && maxLength) {
                if (field.length < maxLength) {
                    return true;
                }
            }
            return false;
        };
        //Invalid charecter validation
        validate.validateInvalidChar = function(field, invalidChar) {
            if (field.indexOf(invalidChar) > -1) {
                return true;
            }
            return false;
        };
        validate.validateExclusionList = function(idvalue, exclusionList) {
            var isIdExclusion = true;
            //please refer ExclusionValidator.java of wecare old 
            var exclustionData = exclusionList.split(";");
            var containsExclusionData = [];
            var startWithExclusionData = [];
            var endWithExclusionData = [];
            var equalsExclusionData = [];

            if (exclustionData) {
                angular.forEach(exclustionData, function(exclusionItem) {
                    var length = exclusionItem.length;
                    if (exclusionItem.charAt(1) == '%' && exclusionItem.charAt(length - 1) == '%') {
                        containsExclusionData.push(exclusionItem.substring(2, length - 1));
                    } else if (exclusionItem.charAt(1) == '%') {
                        endWithExclusionData.push(exclusionItem.substring(2, length));
                    } else if (exclusionItem.charAt(length - 1) == '%') {
                        startWithExclusionData.push(exclusionItem.substring(1, length - 1));
                    } else {
                        equalsExclusionData.push(exclusionItem.substring(1, length));
                    }
                });
            }

            angular.forEach(containsExclusionData, function(contain) {
                if (idvalue.search(contain) > 0) {
                    isIdExclusion = false;
                }
            });

            angular.forEach(startWithExclusionData, function(contain) {
                var regString = new RegExp('^' + contain + '.*$');

                if (idvalue.match(regString)) {
                    isIdExclusion = false;
                }
            });

            angular.forEach(endWithExclusionData, function(contain) {
                var regString = new RegExp('^.*' + contain + '$');

                if (idvalue.match(regString)) {
                    isIdExclusion = false;
                }
            });

            angular.forEach(equalsExclusionData, function(contain) {
                var regString = new RegExp('^' + contain + '.*$');
                if (idvalue.match(regString)) {
                    isIdExclusion = false;
                }
            });
        };
        //validate prefix data
        validate.validatePrefixValidation = function(fieldValue, prefixValue, prefixlenth) {
            if (fieldValue && prefixValue && prefixlenth > 0) {
                if (fieldValue.substring(0, prefixlenth) == prefixValue) {
                    return true;
                } else {
                    return false;
                }
            }
        };
        //validate suffix
        validate.validateSuffixValidation = function(fieldValue, suffixValue, suffixlenth) {
            if (fieldValue && suffixValue && suffixlenth > 0) {
                if (fieldValue.substring(fieldValue.length - suffixlenth, fieldValue.length) == suffixValue) {
                    return true;
                } else {
                    return false;
                }
            }
        };

        //validate any id is present in list or not
        validate.isValueInList = function(idvlaue, listData) {
            if (listData.length > -1) {
                if (listData.indexOf(idvlaue) > -1) {
                    return true;
                }
            }
            return false;
        };

        fieldLabelValidationRuleMap = {
            'ID_VALUE': validate.validateIdFormat,
            'JURISDICTION_ID': validate.validateState,
            'EXPIRATION_DATE': validate.validateExpiration,
            'DATE_OF_BIRTH': validate.validateDOB,
            'STATE': validate.validateState,
            'CITY': validate.validateCity,
            'ZIPCODE': validate.validateZip,
            'FIRST_NAME': validate.validateFirstName,
            'LAST_NAME': validate.validateFirstName,
            'STREET_ADDRESS': validate.validateStreetField,
            'RELATIONSHIP_CODE': validate.validateRelationShip,
            'PSE_ID_VALID': validate.validatePseID,
            'PSE_DATE_OF_BIRTH':validate.validatePSEDOB,
            'COUNTRY' : validate.validateCountry
        };
        return validate;
    }]);
