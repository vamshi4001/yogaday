'use strict';

angular.module('weCarePlusApp')
    .service('MessageService', ['Request', 'MessageFactory', 'PayloadService', 'BasketService', 'ModalService', 'EsignService', '$location', '$q', 'BasketFactory', '$route', 'DialogService',
        function(Request, MessageFactory, PayloadService, BasketService, ModalService, EsignService, $location, $q, BasketFactory, $route, DialogService) {
            var _this = this;
            this.templateData = null;
            this.prevTemplateData = null;
            var loggerName = 'MessageService';
            this.entryTypeHandlerMap = {
                handleCompileMessage: {
                    inStore: 'handleInStoreCompileMessage',
                    rxScan: 'handleRxScanCompileMessage',
                    rxSelect: 'handleRxSelectCompileMessage',
                    completeRxOrder: 'handleCompleteOrderCompileMessage'
                },
                handleDisplayMessage: {
                    inStore: 'handleInStoreDisplayMessage',
                    rxScan: 'handleRxScanDisplayMessage',
                    rxSelect: 'handleRxSelectDisplayMessage',
                    completeRxOrder: 'handleCompleteOrderDisplayMessage'
                }
            };
            this.payloadHandler = {
                inStore: {
                    compileMessage: 'compileInStoreMessages',
                    displayMessage: 'displayInStoreMessage'
                },
                rxScan: {
                    compileMessage: 'compileRxScanMessages',
                    displayMessage: 'displayRxScanMessage'
                },
                rxSelect: {
                    compileMessage: 'compileRxSelectMessages',
                    displayMessage: 'displayRxSelectMessage'
                },
                completeRxOrder: {
                    compileMessage: 'compileCompleteOrderMessages',
                    displayMessage: 'displayCompleteOrderMessage'
                }

            }
            this.entryType; //entryType = 'inStore', 'rxScan', 'completeRxOrder', 'rxSelect' 
            this.rxScanQueue = []; // Will not be cleared in clear method * Please dont add to it - PHANI 
            this.compileMessageResponse = {};
            this.canRejectPromise = null;
            this.clearWholeData = function(){
                _this.clear();
                while(_this.rxScanQueue.length>0){
                    _this.rxScanQueue.shift();
                }
            }
            this.clear = function() {
                _this.templateData = null;
                _this.prevTemplateData = null;
                _this.entryType = null;
                _this.compileMessageResponse = {};
                _this.canRejectPromise = null;
                MessageFactory.clearData();
            };

            this.getRxScanQueue = function() {
                return _this.rxScanQueue;
            };

            this.processRxScan = function(barcode, entryType) {
                var deferred = $q.defer();
                var isRxInQueue = _this.checkDuplicateRxScan(barcode, entryType, deferred);
                if (!isRxInQueue) {
                    (_this.rxScanQueue.length === 1) && _this.compileMessage(entryType, deferred);
                    return deferred.promise;
                } else {
                    deferred = null;
                }
            };

            this.checkDuplicateRxScan = function(barcode, entryType, deferred) {
                var flag = 0;
                for (var i = 0; i < _this.rxScanQueue.length; i++) {
                    if (_this.rxScanQueue[i].barcode === barcode) {
                        flag = 1;
                    }
                }
                if (flag == 1) {
                    return true;
                } else {
                    var rxScanData = {
                        deferred: deferred,
                        entryType: entryType,
                        barcode: barcode
                    };
                    _this.rxScanQueue.push(rxScanData);
                }
            };
            this.removeRxItemFromQueue = function(barcode) {
                for (var i = 0; i < _this.rxScanQueue.length; i++) {
                    if (_this.rxScanQueue[i].barcode === barcode) {
                        _this.rxScanQueue.splice(i, 1);
                    }
                }
            }
            this.processRxScanQueue = function() {
                _this.rxScanQueue.shift();
                if (_this.rxScanQueue.length) {
                    _this.compileMessage(_this.rxScanQueue[0].entryType, _this.rxScanQueue[0].deferred);
                }
            };

            this.completeRxOrder = function(entryType) {
                var deferred = $q.defer();
                _this.compileMessage(entryType, deferred);
                return deferred.promise;
            };

            this.compileMessage = function(entryType, deferred) {
                LOGGER.info('FUNCTION:compileMessage > INVOKED', loggerName);
                _this.clear();
                _this.entryType = entryType;
                var compileMessagesPromise = Request.invoke({
                    url: appConfig.store.services.API.compileMessages[_this.entryType],
                    method: 'POST',
                    data: PayloadService[_this.payloadHandler[_this.entryType].compileMessage]()
                });
                compileMessagesPromise.then(
                    function(result) {
                        _this.compileMessageResponse = result;
                        _this[_this.entryTypeHandlerMap.handleCompileMessage[_this.entryType]](result, deferred);
                    },
                    function(result) {
                        LOGGER.error('FUNCTION:compileMessage > END > API:ERROR', loggerName);
                        _this[_this.entryTypeHandlerMap.handleCompileMessage[_this.entryType]](result.payload, deferred);
                    }
                );
            };

            this.handleInStoreCompileMessage = function(result, deferred) {
                if (result.listOfListOfEntries && result.listOfListOfEntries.length) {
                    LOGGER.info('FUNCTION:compileMessage > END > API:SUCCESS', loggerName);
                    MessageFactory.setMasterMessageList(result.listOfListOfEntries);
                    BasketService.updateSuppressedMessageListDispostion(result.suppressedEntries);
                    _this.displayMessage();
                } else {
                    MessageFactory.clearData();
                    EsignService.invokeEsign();
                }
            };

            this.handleRxSelectCompileMessage = function(result, deferred) {
                if (result.listOfListOfEntries && result.listOfListOfEntries.length) {
                    LOGGER.info('FUNCTION:handleRxSelectCompileMessage > ListOfListOfEntries has SIZE ' + result.listOfListOfEntries.length, loggerName);
                    MessageFactory.setMasterMessageList(result.listOfListOfEntries);
                    BasketService.updateSuppressedMessageListDispostion(result.suppressedEntries);
                    _this.displayMessage(deferred);
                } else {
                    //This Condition Should Never Be Invoked for RxSelect, Added for Better Error Handling - PHANI
                    LOGGER.error('FUNCTION:handleRxSelectCompileMessage > ListOfListOfEntries is EMPTY', loggerName);
                    deferred && deferred.resolve();
                }
            };

            this.handleCompleteOrderCompileMessage = function(result, deferred) {
                if (result.listOfListOfEntries && result.listOfListOfEntries.length) {
                    LOGGER.info('FUNCTION:handleRxSelectCompileMessage > ListOfListOfEntries has SIZE ' + result.listOfListOfEntries.length, loggerName);
                    MessageFactory.setMasterMessageList(result.listOfListOfEntries);
                    BasketService.updateSuppressedMessageListDispostion(result.suppressedEntries);
                    _this.displayMessage(deferred);
                } else {
                    //This Condition Should Never Be Invoked for RxSelect, Added for Better Error Handling - PHANI
                    LOGGER.error('FUNCTION:handleRxSelectCompileMessage > ListOfListOfEntries is EMPTY', loggerName);
                    //resolving promise in basket to get the data
                    deferred && deferred.resolve();

                }

            }

            this.handleRxScanCompileMessage = function(result, deferred) {
                if (result.rxScanServicePayLoad && result.rxScanServicePayLoad.listOfListOfEntries && result.rxScanServicePayLoad.listOfListOfEntries.length) {
                    LOGGER.info('FUNCTION:handleRxSelectCompileMessage > ListOfListOfEntries has SIZE ' + result.rxScanServicePayLoad.listOfListOfEntries.length, loggerName);
                    MessageFactory.setMasterMessageList(result.rxScanServicePayLoad.listOfListOfEntries);
                    BasketService.updateSuppressedMessageListDispostion(result.rxScanServicePayLoad.suppressedEntries);
                    _this.displayMessage(deferred);
                } else {
                    LOGGER.info('FUNCTION:handleRxScanCompileMessage > ListOfListOfEntries is EMPTY', loggerName);
                    _this.processRxScanQueue();
                    deferred && deferred.resolve({
                        patientId: _this.compileMessageResponse.patientId,
                        fillInfo: _this.compileMessageResponse.patientFillInfo
                    });
                }
            };

            this.displayMessage = function(deferred) {
                LOGGER.info('FUNCTION:displayMessage > INVOKED', loggerName);
                var displayMessagePromise = Request.invoke({
                    url: appConfig.store.services.API.displayMessages[_this.entryType],
                    method: 'POST',
                    data: PayloadService[_this.payloadHandler[_this.entryType].displayMessage]()
                });
                displayMessagePromise.then(
                    function(result) {
                        LOGGER.debug('FUNCTION:displayMessage > END > API:SUCCESS', loggerName);
                        _this[_this.entryTypeHandlerMap.handleDisplayMessage[_this.entryType]](result, deferred);
                    },
                    function(result) {
                        if (result.code == result.payload.businessStatus) {
                            _this.canRejectPromise = true;
                            LOGGER.debug('FUNCTION:displayMessage > END > API:ERROR > businessStatus:' + result.payload.businessStatus, loggerName);
                            _this[_this.entryTypeHandlerMap.handleDisplayMessage[_this.entryType]](result.payload, deferred);
                        } else {
                            //Handle Display Error When Store Response Code is 4XX or 5XX
                        }
                    }
                );
            };

            this.handleInStoreDisplayMessage = function(data, deferred) {
                BasketService.updateSuppressedMessageListDispostion(data.suppressedEntries)
                if (!data.endOfEntriesReached) {
                    var currentMessageIndexTemp = data.indexToBeProcessed;
                    MessageFactory.setMasterMessageList(data.listOfListOfEntries);
                    MessageFactory.setCurrentMessageIndex(currentMessageIndexTemp);
                    var patientMessageListTemp = MessageFactory.getMasterMessageList()[currentMessageIndexTemp];
                    if (patientMessageListTemp && patientMessageListTemp.length) {
                        MessageFactory.setPatientMessageList(patientMessageListTemp);
                        _this.renderInStoreMessage(patientMessageListTemp);
                    } else {
                        _this.displayMessage();
                    }
                } else {
                    EsignService.invokeEsign();
                    deferred && deferred.resolve();
                }
            };

            this.renderInStoreMessage = function(patientMessageList) {
                var templateKey = null;
                var messageType = null;
                messageType = patientMessageList[0].messageType;
                templateKey = messageType + '-' + patientMessageList[0].progType;
                if (!TEMPLATE_MAP.messages[templateKey] && patientMessageList.length > 1) {
                    messageType = patientMessageList[1].messageType;
                    // Only in case of TCPA we get Alert message and Patient demographic
                    templateKey = messageType + '-' + patientMessageList[1].progType;
                    MessageFactory.setHasTcpaMessage(true);
                    MessageFactory.setPatDemoMessage(patientMessageList[1]);
                }
                _this.templateData = TEMPLATE_MAP.messages[templateKey];
                //Skip RFL
                if (_this.templateData) {
                    if (_this.prevTemplateData && _this.templateData === _this.prevTemplateData) {
                        (messageType == '2') && BasketFactory.setBasketPageMsgAlert(true);
                        $route.reload();
                        return;
                    } else {
                        _this.prevTemplateData = _this.templateData;
                    }
                    if (messageType != '2') {
                        $location.url('/messages/' + _this.templateData);
                    } else {
                        BasketFactory.setBasketPageMsgAlert(true);
                        $location.url('/basket');
                    }
                } else {
                    _this.displayMessage();
                }
            };

            this.handleRxScanDisplayMessage = function(data, deferred) {
                if (!data.endOfEntriesReached) {
                    var currentMessageIndexTemp = data.indexToBeProcessed;
                    MessageFactory.setMasterMessageList(data.listOfListOfEntries);
                    BasketService.updateSuppressedMessageListDispostion(data.suppressedEntries);
                    MessageFactory.setCurrentMessageIndex(currentMessageIndexTemp);
                    var patientMessageListTemp = MessageFactory.getMasterMessageList()[currentMessageIndexTemp];
                    if (patientMessageListTemp && patientMessageListTemp.length) {
                        MessageFactory.setPatientMessageList(patientMessageListTemp);
                        _this.renderRxScanMessage(patientMessageListTemp, deferred);
                    } else {
                        _this.displayMessage(deferred);
                    }
                } else {
                    _this.processRxScanQueue();
                    if (_this.canRejectPromise) {
                        //Could happen when compile is failure and all alert messages are displayed
                        deferred.reject();
                    } else {
                        deferred.resolve({
                            patientId: _this.compileMessageResponse.patientId,
                            fillInfo: _this.compileMessageResponse.patientFillInfo
                        });
                    }
                }
            };

            this.renderRxScanMessage = function(patientMessageList, deferred) {
                var templateKey = null;
                var messageType = null;
                messageType = patientMessageList[0].messageType;
                //Message Type '1' Action Notes
                templateKey = (messageType == '1') ? '1-*' : (messageType + '-' + patientMessageList[0].progType);
                _this.templateData = TEMPLATE_MAP.rxScanMessages[templateKey];
                if (_this.templateData) {
                    var templateUrl = _this.templateData.templateUrl;
                    var modalCtrl = _this.templateData.modalCtrl;
                    var modalOptions = {
                        templateUrl: templateUrl,
                        windowClass: _this.templateData.windowClass || 'modal-dialog-full',
                        controller: modalCtrl
                    };
                    var customOptions = {
                        promise: true
                    };
                    var rxScanMsgModalPromise = ModalService.showModal(modalOptions, customOptions);
                    rxScanMsgModalPromise.then(function(rxScanPatientMessageList) {
                            BasketService.updatePatientMessageDispostion(rxScanPatientMessageList);
                            _this.displayMessage(deferred);
                            _this.processRxScanQueue();
                        },
                        function(rxScanPatientMessageList, data) {
                            BasketService.updatePatientMessageDispostion(rxScanPatientMessageList);
                            deferred.reject({
                                patientId: _this.compileMessageResponse.patientId,
                                fillInfo: _this.compileMessageResponse.patientFillInfo,
                                fillDisposition: data
                            });
                            _this.processRxScanQueue();
                        });
                } else {
                    _this.displayMessage(deferred);
                }
            };

            this.handleRxSelectDisplayMessage = function(data, deferred) {
                if (!data.endOfEntriesReached) {
                    var currentMessageIndexTemp = data.indexToBeProcessed;
                    MessageFactory.setMasterMessageList(data.listOfListOfEntries);
                    // BasketService.updateSuppressedMessageListDispostion(data.suppressedEntries);
                    MessageFactory.setCurrentMessageIndex(currentMessageIndexTemp);
                    var patientMessageListTemp = MessageFactory.getMasterMessageList()[currentMessageIndexTemp];
                    if (patientMessageListTemp && patientMessageListTemp.length) {
                        MessageFactory.setPatientMessageList(patientMessageListTemp);
                        _this.renderRxSelectMessage(patientMessageListTemp, deferred);
                    }
                } else {
                    if (!isCompileSuccess) {
                        //Could happen when compile is failure and all alert messages are displayed
                        deferred.reject();
                    } else {
                        deferred.resolve({
                            patientId: _this.compileMessageResponse.patientId,
                            fillInfo: _this.compileMessageResponse.patientFillInfo
                        });
                    }
                }
            };

            this.renderRxSelectMessage = function(patientMessageList, deferred) {
                var templateKey = null;
                var messageType = null;
                messageType = patientMessageList[0].messageType;
                //Message Type '1' Action Notes
                templateKey = (messageType == '1') ? '1-*' : '0-*';
                _this.templateData = TEMPLATE_MAP.rxSelectMessages[templateKey];
                if (_this.templateData) {
                    var templateUrl = _this.templateData.templateUrl;
                    var modalCtrl = _this.templateData.modalCtrl;
                    var modalOptions = {
                        templateUrl: templateUrl,
                        windowClass: _this.templateData.windowClass || 'modal-dialog-full',
                        controller: modalCtrl
                    };
                    var customOptions = {
                        promise: true
                    };
                    var rxSelectMsgModalPromise = ModalService.showModal(modalOptions, customOptions);
                    rxSelectMsgModalPromise.then(function(rxScanPatientMessageList, data) {
                        BasketService.updatePatientMessageDispostion(rxScanPatientMessageList)
                            //_this.displayMessage(deferred);
                    });
                }
                /*else {
                                   _this.displayMessage(deferred);
                               }*/
            };

            this.handleCompleteOrderDisplayMessage = function(data, deferred) {
                if (!data.endOfEntriesReached) {
                    var currentMessageIndexTemp = data.indexToBeProcessed;
                    MessageFactory.setMasterMessageList(data.listOfListOfEntries);
                    BasketService.updateSuppressedMessageListDispostion(data.suppressedEntries);
                    MessageFactory.setCurrentMessageIndex(currentMessageIndexTemp);
                    var patientMessageListTemp = MessageFactory.getMasterMessageList()[currentMessageIndexTemp];
                    if (patientMessageListTemp && patientMessageListTemp.length) {
                        MessageFactory.setPatientMessageList(patientMessageListTemp);
                        _this.renderCompleteOrderMessage(patientMessageListTemp, deferred);
                    } else {
                        _this.displayMessage(deferred);
                    }
                } else {
                    //_this.processRxScanQueue();
                    if (!isCompileSuccess) {
                        //Could happen when compile is failure and all alert messages are displayed
                        deferred.reject();
                    } else {
                        deferred.resolve({
                            patientId: _this.compileMessageResponse.patientId,
                            fillInfo: _this.compileMessageResponse.patientFillInfo
                        });
                    }
                }
            };

            this.renderCompleteOrderMessage = function(patientMessageList, deferred) {
                var templateKey = null;
                var messageType = null;
                messageType = patientMessageList[0].messageType;
                //Message Type '1' Action Notes
                templateKey = (messageType == '1') ? '1-*' : (messageType + '-' + patientMessageList[0].progType);
                _this.templateData = TEMPLATE_MAP.completeOrderMessages[templateKey];
                if (_this.templateData) {
                    var templateUrl = _this.templateData.templateUrl;
                    var modalCtrl = _this.templateData.modalCtrl;
                    var modalOptions = {
                        templateUrl: templateUrl,
                        windowClass: _this.templateData.windowClass || 'modal-dialog-full',
                        controller: modalCtrl
                    };
                    var customOptions = {
                        promise: true
                    };
                    var rxSelectMsgModalPromise = ModalService.showModal(modalOptions, customOptions);
                    rxSelectMsgModalPromise.then(function(rxScanPatientMessageList) {
                        BasketService.updatePatientMessageDispostion(rxScanPatientMessageList)
                        _this.displayMessage(deferred);
                    });
                } else {
                    _this.displayMessage(deferred);
                }
            };

            this.buildPatientIdRxInfoPatMsgListMap = function(patientMessageList) {
                var patientIdRxListMap = {};
                var partialBarcodeRxInfoMap = BasketFactory.getPartialBarcodeRxInfoMap();
                angular.forEach(patientMessageList, function(patientMessage) {
                    var rxInfoPatMsgList = patientIdRxListMap[patientMessage.rxPatientId];
                    var partialBarcode = BasketService.buildPartialBarcode(patientMessage);
                    var rxInfo = partialBarcodeRxInfoMap[partialBarcode];
                    if (rxInfo) {
                        var rxInfoPatMsg = {
                            patientMessage: patientMessage,
                            rxInfo: rxInfo,
                            partialBarcode: partialBarcode
                        };
                        if (rxInfoPatMsgList) {
                            rxInfoPatMsgList.push(rxInfoPatMsg);
                        } else {
                            patientIdRxListMap[patientMessage.rxPatientId] = [rxInfoPatMsg];
                        }
                    }
                });
                return patientIdRxListMap;
            };

            //Utility for Ready Fill 2.0, AutoFill Confirmation, All other Messages Which has SOLD and UNSOLD to display - PHANI
            this.buildPatientIdToSoldUnSoldToRxInfoPatMsgListMap = function(patientMessageList) {
                var patientIdToSoldUnSoldToRxInfoPatMsgListMap = {};
                var partialBarcodeRxInfoMap = BasketFactory.getPartialBarcodeRxInfoMap();
                angular.forEach(patientMessageList, function(patientMessage) {
                    patientIdToSoldUnSoldToRxInfoPatMsgListMap[patientMessage.rxPatientId] = patientIdToSoldUnSoldToRxInfoPatMsgListMap[patientMessage.rxPatientId] || {};
                    var partialBarcode = BasketService.buildPartialBarcode(patientMessage);
                    var rxInfo = partialBarcodeRxInfoMap[partialBarcode];
                    if (rxInfo) {
                        var rxInfoPatMsg = {
                            patientMessage: patientMessage,
                            rxInfo: rxInfo,
                            partialBarcode: partialBarcode
                        };
                        var rxItemStatus = 'UNSOLD';
                        if (rxInfo.fillDisposition.dispositionKey === 'SLD') {
                            rxItemStatus = 'SOLD';
                        }
                        if (patientIdToSoldUnSoldToRxInfoPatMsgListMap[patientMessage.rxPatientId][rxItemStatus]) {
                            patientIdToSoldUnSoldToRxInfoPatMsgListMap[patientMessage.rxPatientId][rxItemStatus].push(rxInfoPatMsg);
                        } else {
                            patientIdToSoldUnSoldToRxInfoPatMsgListMap[patientMessage.rxPatientId][rxItemStatus] = [rxInfoPatMsg];
                        }
                    }
                });
                return patientIdToSoldUnSoldToRxInfoPatMsgListMap;
            };

            //Not used - PHANI
            this.buildPartialRxInfoListFromMessageList = function(patientMessageList) {
                var partialRxInfoList = [];
                angular.forEach(patientMessageList, function(patientMessage) {
                    var partialRxInfo = {
                        rxNum: patientMessage.rxNum,
                        refillNum: patientMessage.refillNum,
                        partialFillSeqNum: patientMessage.partialFillSeqNum,
                        editVersionNum: patientMessage.editVersionNum
                    };
                    partialRxInfoList.push(partialRxInfo);
                });
            };

            //When Tcpa Message is Already Displayed and Clicking Next in Patient Demographic uses this Function - PHANI
            this.showTcpaMessage = function() {
                var patientMessageList = [];
                patientMessageList.push(MessageFactory.getTcpaMessage());
                MessageFactory.setPatientMessageList(patientMessageList);
                $location.url('/messages/tcpa');
            };

            //When Tcpa Message is Already Displayed and Clicking Back in TCPA uses this Function - PHANI
            this.showPatientDemographicMessage = function() {
                var patientMessageList = [];
                patientMessageList.push(MessageFactory.getPatDemoMessage());
                MessageFactory.setPatientMessageList(patientMessageList);
                $location.url('/messages/patient-demographic');
            };



        }
    ]);
