'use strict';

angular.module('weCarePlusApp')
    .service('BasketService', ['CONFIG', 'BasketFactory',
        function(CONFIG, BasketFactory) {
            var _this = this;
            var basketData = BasketFactory.getBasketData();

            this.updateBasketData = function(key, data) {
                basketData = BasketFactory.getBasketData();
                // Start time should be RESET every time we add a new patient - PHANI
                CONFIG.messages.txnStartTimestamp = appUtils.getCurrentTimestamp();
                basketData[key] = data;
                _this.buildPartialBarcodeRxInfoMap();
                _this.buildMsgSeqMsgItemMap();
            };

            this.buildPartialBarcodeRxInfoMap = function() {
                basketData = BasketFactory.getBasketData();
                var partialBarcodeRxInfoMapTemp = {};
                angular.forEach(basketData, function(patientProfile, patientId) {
                    angular.forEach(patientProfile.patientFillInfoList, function(fillInfo) {
                        var rxInfoPartialBarcode = _this.buildPartialBarcode(fillInfo);
                        partialBarcodeRxInfoMapTemp[rxInfoPartialBarcode] = fillInfo;
                    });
                });
                BasketFactory.setPartialBarcodeRxInfoMap(partialBarcodeRxInfoMapTemp);
            };

            this.buildPartialBarcodeRxScanMsgMap = function() {
                basketData = BasketFactory.getBasketData();
                //Action Notes, TP Compliance, MedB - Method Not Used Yet
                var rxScanMessages = {
                    eanMsg: ['ALL'],
                    tpComplianceMsg: ['ALL'],
                    rxCentrMsg: ['10', '11']
                };
                var partialBarcodeRxInfoMapTemp = {};
                angular.forEach(basketData, function(patientProfile, patientId) {
                    angular.forEach(rxScanMessages, function(progTypeArr, messageListKey) {
                        angular.forEach(patientProfile.patientMessageInfo[messageListKey], function(messageItem) {
                            if (progTypeArr[0] === 'ALL' || progTypeArr.indexOf(messageItem.progType) > -1) {
                                var msgItemPartialBarcode = _this.buildPartialBarcode(messageItem);
                                partialBarcodeRxInfoMapTemp[msgItemPartialBarcode] = messageItem;
                            }
                        });
                    });
                });
            };

            this.buildMsgSeqMsgItemMap = function() {
                basketData = BasketFactory.getBasketData();
                var msgSeqMsgItemMapTemp = {};
                angular.forEach(basketData, function(patientProfile, patientId) {
                    angular.forEach(patientProfile.patientMessageInfo, function(messageList, patientMessageInfoKey) {
                        angular.forEach(messageList, function(messageItem) {
                            msgSeqMsgItemMapTemp[messageItem.msgSeq] = messageItem;
                        });
                    });
                });
                BasketFactory.setMsgSeqMsgItemMap(msgSeqMsgItemMapTemp);
            };

            this.buildPartialBarcodeMessageListMap = function() {
                var partialBarcodeMessageListMap = {};
                basketData = BasketFactory.getBasketData();
                angular.forEach(basketData, function(patientProfile, patientId) {
                    angular.forEach(patientProfile.patientMessageInfo, function(messageList, messageListKey) {
                        angular.forEach(messageList, function(messageItem) {
                            var partialBarcode = _this.buildPartialBarcode(messageItem);
                            if (messageItem.rxNum) {
                                if (partialBarcodeMessageListMap[partialBarcode]) {
                                    partialBarcodeMessageListMap[partialBarcode].push(messageItem);
                                } else {
                                    partialBarcodeMessageListMap[partialBarcode] = [messageItem];
                                }
                            }
                        });
                    });
                });
            };

            this.getFillInfoByMessageItem = function(messageItem) {
                var partialBarcodeRxInfoMap = BasketFactory.getPartialBarcodeRxInfoMap();
                var msgItemPartialBarcode = _this.buildPartialBarcode(messageItem);
                return partialBarcodeRxInfoMap[msgItemPartialBarcode];
            };

            //Update Message Disposition will be invoked when we click continue - Not Used (PHANI)
            this.updateMessageDispostion = function(obj) {
                basketData = BasketFactory.getBasketData();
                if (obj && obj.messageDispositionMap) {
                    angular.forEach(obj.messageDispositionMap, function(messageDispostionObj, patientId) {
                        var patientProfile = basketData[patientId];
                        if (patientProfile) {
                            angular.forEach(messageDispostionObj, function(msgSeqMsgDispostionMap, messageType) {
                                var msgInfoKey = CONFIG.messages.patientMessageInfoKeyMap[messageType];
                                var messageList = patientProfile.patientMessageInfo[msgInfoKey];
                                if (messageList && messageList.length) {
                                    angular.forEach(messageList, function(messageItem) {
                                        var messageDispostionObjByMsgSeq = msgSeqMsgDispostionMap[messageItem.msgSeq];
                                        if (messageDispostionObjByMsgSeq && messageDispostionObjByMsgSeq.actualDispostion) {
                                            angular.merge(messageItem, messageDispostionObjByMsgSeq.actualDispostion);
                                        }
                                    });
                                }
                            });
                        }
                    });
                }
            };

            //
            this.updatePatientMessageDispostion = function(patientMsgList) {
                var msgSeqMsgItemMapTemp = BasketFactory.getMsgSeqMsgItemMap();
                if (patientMsgList && patientMsgList.length) {
                    angular.forEach(patientMsgList, function(patientMsgItem) {
                        //For Custom build message we update common attributes
                        patientMsgItem.disposition = '1'; //Messaged dispayed dispostion
                        patientMsgItem.timestamp = appUtils.getCurrentTimestamp(CONFIG.timestampFormat)
                        patientMsgItem.markDisplayed = true;
                        var messageItem = msgSeqMsgItemMapTemp[patientMsgItem.msgSeq];
                        if (messageItem) {
                            patientMsgItem.mandatory = patientMsgItem.messageConfig.msgInd;
                            var patientMsgDisposition = angular.copy(patientMsgItem);
                            delete patientMsgDisposition.messageConfig;
                            angular.merge(messageItem, patientMsgDisposition);
                        }
                    });
                }
            };

            //
            this.updateSuppressedMessageListDispostion = function(suppressedMsgList) {
                var msgSeqMsgItemMapTemp = BasketFactory.getMsgSeqMsgItemMap();
                if (suppressedMsgList && suppressedMsgList.length) {
                    angular.forEach(suppressedMsgList, function(suppressedMsgItem) {
                        var messageItem = msgSeqMsgItemMapTemp[suppressedMsgItem.msgSeq];
                        if (messageItem) {
                            messageItem.markDisplayed = false;
                            messageItem.disposition = '0';
                            messageItem.notDisplayedReason = suppressedMsgItem.notDisplayedReason;
                        }
                    });
                }
            };
            //RxInfo or Message Item - Input
            this.buildPartialBarcode = function(data) {
                var rxnum = appUtils.prepandZeros(data.rxNum, 7);
                var reFillNum = appUtils.prepandZeros((data.refillNum || 0), 3);
                /*  Not including edit version number,
                    Since to determine a unique barcode we will always have only one edit version number in patient profile data
                */
                // var editVerNum = appUtils.prepandZeros((data.editVersionNum || 0), 3);
                var parFillSeqNum = appUtils.prepandZeros((data.partialFillSeqNum || 0), 2);
                return (rxnum + reFillNum + parFillSeqNum);
            };
        }
    ]);
