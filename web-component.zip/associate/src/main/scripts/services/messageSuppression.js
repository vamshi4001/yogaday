'use strict';

angular.module('weCarePlusApp')
    .service('MessageSuppressionService', ['$q', 'BasketFactory', 'PatientPresentService', function($q, BasketFactory, PatientPresentService) {

        this.suppressMessage = function (options) {
            var deferred = $q.defer();

            if (options.messageType === '5' && options.progType === '16') {
                
                var basketData = BasketFactory.getBasketData();
                var patientAge = appUtils.getPatientAge(basketData[options.rxPatientId].patientDetails.birthday);
    
                PatientPresentService.showPatientDialog([{patientId: options.rxPatientId}]).then(function (result){

                    var ageMismatch = (result[options.rxPatientId].patient === 'Y' && patientAge < 18) || (result[options.rxPatientId].parent === 'Y' && patientAge > 18);
                    var patientOrParentAbsent = (result[options.rxPatientId].patient === 'N' && patientPresentIndicator) || (result[options.rxPatientId].parent === 'N' && parentPresentIndicator);

                    if (ageMismatch || patientParentAbsent) {
                        deferred.resolve(true);
                    } else {
                        deferred.resolve(false);
                    }
                });
            } else {
                deferred.resolve(false);
            }
            return deferred.promise;
        }
    }]);
