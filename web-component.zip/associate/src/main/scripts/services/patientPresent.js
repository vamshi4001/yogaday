'use strict';

angular.module('weCarePlusApp')
    .service('PatientPresentService', ['$modal', 'PatientFactory','BasketFactory', function($modal, PatientFactory, BasketFactory) {
        var modalDefaults = {
            modalFade: true,
            windowClass: 'major-popup',
            templateUrl: 'views/modals/patientPresentMulti.html'
        };
        var modalInstance = {};
        var modalOptions = {
            headerText: 'Is patient present',
            bodyText: 'Is patient present ?',
            bodyText_ped: 'Is the parent present ?',
            instructionText: 'Please indicate wether the patient is present in the store',
            shouldCalcualteAdult: false,
            adultAge: 18, 
            showDOB: false, 
            showAddress: false,
            askParentDirect: false
        };
        this.showPatientDialogSingle = function(patientValueObj, customModalOptions, customModalDefaults){
            var patientValueObjList =[];
            patientValueObjList.push(patientValueObj);
            this.showPatientDialog(patientValueObjList, customModalDefaults, customModalOptions);
        };
        this.showPatientDialog = function(patientValueObjList, customModalOptions, customModalDefaults) {
            var patientPresentValueList = [];
            var patientValueObj;
            var basketData = BasketFactory.getBasketData();
            for(var i in patientValueObjList){
                patientValueObj = patientValueObjList[i];
                if(!PatientFactory.isPatientPresent(patientValueObj)){
                    var patientDetails = basketData[patientValueObj.patientId].patientDetails;
                    patientValueObj.lastName = patientDetails.lastName;
                    patientValueObj.firstName = patientDetails.firstName;
                    patientValueObj.birthday = patientDetails.birthday;
                    patientValueObj.address = patientDetails.address;
                    patientValueObj.pediatricIndicator = patientDetails.pediatricIndicator;
                    patientPresentValueList.push(patientValueObj);
                }
            }
            if(patientPresentValueList.length > 0){
                customModalDefaults = customModalDefaults || {};
                customModalDefaults.backdrop = 'static';
                return this.show(patientPresentValueList, customModalDefaults, customModalOptions); 
            }  
        };
        this.closeDialog = function() {
            if (modalInstance) {
                modalInstance.close();
            }
        };

        this.show = function(patientList, customModalDefaults, customModalOptions) {
            //Create temp objects to work with since we're in a singleton service
            var tempModalDefaults = {};
            var tempModalOptions = {};
            var patientList = patientList;

            //Map angular-ui modal custom defaults to modal defaults defined in service
            angular.extend(tempModalDefaults, modalDefaults, customModalDefaults);

            //Map modal.html $scope custom properties to defaults defined in service
            angular.extend(tempModalOptions, modalOptions, customModalOptions);

            if (!tempModalDefaults.controller) {
                tempModalDefaults.controller = function($scope, $modalInstance, DialogService) {

                    $scope.modalOptions = tempModalOptions;
                    $scope.patientList = patientList;
                    modalInstance = $modalInstance;
                    $scope.patientPresentMap = {};
                    $scope.patientPresentObj = {};
                    $scope.doAction = function(patientObj, result){
                        if(result === 'Y'){
                            if(patientObj.pediatric === true){
                                $scope.patientPresentMap[patientObj.patientId] = {parent:'Y'};
                            }
                            else{
                                $scope.patientPresentMap[patientObj.patientId] = {patient:'Y'};
                            }
                        }
                        else if(result === 'N'){
                            if(patientObj.pediatric === true){
                                $scope.patientPresentMap[patientObj.patientId] = {parent:'N'};
                            }
                            else{
                                $scope.patientPresentMap[patientObj.patientId] = {patient:'N'};
                            }
                        }
                    };

                    $scope.isActionBtnActive_yes = function (patientObj){
                        if(patientObj.pediatric === true){
                            if($scope.patientPresentMap[patientObj.patientId]){
                                return $scope.patientPresentMap[patientObj.patientId].parent === 'Y';
                            }
                        }else{
                            if($scope.patientPresentMap[patientObj.patientId]){
                                return $scope.patientPresentMap[patientObj.patientId].patient === 'Y';
                            }
                        }
                    };

                      $scope.isActionBtnActive_no = function (patientObj){
                        if(patientObj.pediatric === true){
                            if($scope.patientPresentMap[patientObj.patientId]){
                                return $scope.patientPresentMap[patientObj.patientId].parent === 'N';
                            }
                        }else{
                            if($scope.patientPresentMap[patientObj.patientId]){
                                return $scope.patientPresentMap[patientObj.patientId].patient === 'N';
                            }
                        }
                    };
                    $scope.isContinueActive = function() {
                        $scope.continueActive = false;           
                        if (Object.keys($scope.patientPresentMap).length === patientList.length) {
                            $scope.continueActive = true;
                        } else {
                            $scope.continueActive = false;
                        }
                        return $scope.continueActive;
                    };
                    $scope.sendValue = function(inputValue) {
                        if($scope.isContinueActive()){
                            if (inputValue) {
                                 angular.forEach(inputValue, function(status, patientId) {
                                    PatientFactory.updatePatientPresent(patientId, status);
                                });
                                $modalInstance.close(inputValue);
                            } else {
                                var modalOptions = {
                                    buttons: ['OK'],
                                    headerText: 'Warning',
                                    bodyText: 'Data is required for this field'
                                };
                                DialogService.showDialog({}, modalOptions).then(function(result) {});
                            }
                        }
                    };
                    $scope.closeDialog = function() {
                        $modalInstance.dismiss();
                    };
            };
            return $modal.open(tempModalDefaults).result;
        }
    }
}]);
