'use strict';

angular.module('weCarePlusApp')
    .service('DialogService', ['$modal', function($modal) {
        var modalDefaults = {
            backdrop: 'static',
            keyboard: true,
            modalFade: true,
            windowClass: 'minor-popup',
            templateUrl: 'views/dialogs/block-ui.html'
        };

        var modalInstance = {};
        var modalInstanceMap = {};

        var modalOptions = {
            // can have a maximum of six buttons in the UI.
            buttons: ['yes', 'no'],
            headerText: 'Processing',
            bodyText: 'WAITING FOR RESPONSE'
        };

        this.showDialog = function(customModalDefaults, customModalOptions) {
            customModalDefaults = customModalDefaults || {};
            customModalDefaults.backdrop = 'static';
            return this.show(customModalDefaults, customModalOptions);
        };

        this.closeDialog = function() {
            modalInstance && modalInstance.close();
        };

        this.closeDialogByKey = function(key) {
            if (key) {
                if (key === 'all') {
                    angular.forEach(modalInstanceMap, function(modalInstanceItem, modalKey) {
                        modalInstanceMap[modalKey] && modalInstanceMap[modalKey].close();    
                    });
                    modalInstanceMap = {};
                } else {
                    modalInstanceMap[key] && modalInstanceMap[key].close();
                    delete modalInstanceMap[key];
                }
            }
        };

        this.show = function(customModalDefaults, customModalOptions) {
            //Create temp objects to work with since we're in a singleton service
            var tempModalDefaults = {};
            var tempModalOptions = {};

            //Map angular-ui modal custom defaults to modal defaults defined in service
            angular.extend(tempModalDefaults, modalDefaults, customModalDefaults);

            //Map modal.html $scope custom properties to defaults defined in service
            angular.extend(tempModalOptions, modalOptions, customModalOptions);

            if (!tempModalDefaults.controller) {
                tempModalDefaults.controller = function($scope, $modalInstance) {
                    $scope.modalOptions = tempModalOptions;
                    modalInstance = $modalInstance;
                    if (tempModalOptions.modalKey) {
                        modalInstanceMap[tempModalOptions.modalKey] = modalInstance;
                    }
                    $scope.modalOptions.selectOption = function(event, buttonName) {
                        $modalInstance.close(buttonName);
                    };
                };
            }
            return $modal.open(tempModalDefaults).result;
        };

    }]);
