'use strict';

angular.module('weCarePlusApp')
    .service('ManagerOverrideService', ['NumberEntryService', 'Request', 'DialogService', '$q', '$timeout', 'CONFIG', function(NumberEntryService, Request, DialogService, $q, $timeout, CONFIG) {
        var isManager = CONFIG.loggedInUser.roles == 'P' ? true : false;
        var mangerOverrideInProgress = false;
        var verifyAssociateInProgress = false;
        var timer;

        var service = {
            doManagerOverride: function(opts) {
                opts = opts ? opts : {};
                if(opts.bypassIfManager && isManager) {
                    return;
                }
                timer && $timeout.cancel(timer);
                mangerOverrideInProgress = true;
                var username = '';
                var password = '';
                var modalOptions = {
                    usernameHeaderText: 'Manager Override',
                    usernameInputTextHelp: 'Enter Manager ID Number',
                    passwordHeaderText: 'Manager Override',
                    passwordInputTextHelp: 'Password',
                    invalidRoleMessage: 'Invalid Manager Login',
                    usernameCancelConfirm: true,
                    passwordCancelConfirm: true
                };
                angular.merge(modalOptions, opts);
                var deferred = $q.defer();
                NumberEntryService.showDialog({}, {
                    inputText: modalOptions.usernameInputTextHelp,
                    headerText: modalOptions.usernameHeaderText,
                    cancelConfirm: modalOptions.usernameCancelConfirm
                }).then(function(resUN) {
                    if (resUN) {
                        username = resUN;
                        NumberEntryService.showDialog({}, {
                            inputText: modalOptions.passwordInputTextHelp,
                            headerText: modalOptions.passwordHeaderText,
                            cancelConfirm: modalOptions.passwordCancelConfirm,
                            inputType: 'password'
                        }).then(function(resPW) {
                            if (resPW) {
                                password = resPW;
                                Request.invoke({
                                    url: appConfig.store.services.API.employees + '?emp_id=' + username + '&pin=' + password,
                                    method: 'GET'
                                }).then(function(result) {
                                    if (result[0].roles !== "P") {
                                        appUtils.log("ID with wrong role used for " + modalOptions.usernameHeaderText + ".");
                                        appUtils.log("ID/Role used : " + username + "/" + result[0].roles);
                                        DialogService.showDialog({}, {
                                            buttons: ['OK'],
                                            headerText: 'Error',
                                            bodyText: modalOptions.invalidRoleMessage
                                        }).then(function(type) {
                                            if (mangerOverrideInProgress) {
                                                mangerOverrideInProgress = false;
                                                deferred.reject();
                                            }
                                        });
                                    } else {
                                        if (mangerOverrideInProgress) {
                                            mangerOverrideInProgress = false;
                                            deferred.resolve(username);
                                        }
                                    }
                                }, function(result, statusCode) {
                                    DialogService.showDialog({}, {
                                        buttons: ['OK'],
                                        headerText: 'Error',
                                        bodyText: 'Employee not on file'
                                    }).then(function(type) {
                                        if (mangerOverrideInProgress) {
                                            mangerOverrideInProgress = false;
                                            deferred.reject(true);
                                        }
                                    });
                                });
                            }
                        });
                    }
                });
                timer = $timeout(function() {
                    if (mangerOverrideInProgress) {
                        mangerOverrideInProgress = false;
                        deferred.reject();
                    }
                }, 30000);
                return deferred.promise;
            },
            verifyAssociate: function(opts) {
                opts = opts ? opts : {};
                timer && $timeout.cancel(timer);
                verifyAssociateInProgress = true;
                var username = '';
                var password = '';
                var modalOptions = {
                    usernameHeaderText: 'Verify Associate',
                    usernameInputTextHelp: 'Enter Associate ID Number',
                    passwordHeaderText: 'Verify Associate',
                    passwordInputTextHelp: 'Password',
                    usernameCancelConfirm: true,
                    passwordCancelConfirm: true
                };
                angular.merge(modalOptions, opts);
                var deferred = $q.defer();
                NumberEntryService.showDialog({}, {
                    inputText: modalOptions.usernameInputTextHelp,
                    headerText: modalOptions.usernameHeaderText,
                    cancelConfirm: modalOptions.usernameCancelConfirm
                }).then(function(resUN) {
                    if (resUN) {
                        username = resUN;
                        NumberEntryService.showDialog({}, {
                            inputText: modalOptions.passwordInputTextHelp,
                            headerText: modalOptions.passwordHeaderText,
                            cancelConfirm: modalOptions.passwordCancelConfirm,
                            inputType: 'password'
                        }).then(function(resPW) {
                            if (resPW) {
                                password = resPW;
                                Request.invoke({
                                    url: appConfig.store.services.API.employees + '?emp_id=' + username + '&pin=' + password,
                                    method: 'GET'
                                }).then(function(result) {
                                    if (verifyAssociateInProgress) {
                                        verifyAssociateInProgress = false;
                                        deferred.resolve(username);
                                    }
                                }, function(result, statusCode) {
                                    DialogService.showDialog({}, {
                                        buttons: ['OK'],
                                        headerText: 'Error',
                                        bodyText: 'Employee not on file'
                                    }).then(function(type) {
                                        if (verifyAssociateInProgress) {
                                            verifyAssociateInProgress = false;
                                            deferred.reject(true);
                                        }
                                    });
                                });
                            }
                        });
                    }
                });
                timer = $timeout(function() {
                    if (verifyAssociateInProgress) {
                        verifyAssociateInProgress = false;
                        deferred.reject();
                    }
                }, 30000);
                return deferred.promise;
            }
        };

        return service;
    }]);
