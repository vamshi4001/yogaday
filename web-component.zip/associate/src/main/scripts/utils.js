'use strict';

var appUtils = {
    socketRef: null,
    isBlank: function(str) {
        return (!str || /^\s*$/.test(str));
    },
    dateFormat: function(date, mask) {

    },
    getRandomNumber: function(length) {
        return Math.floor(Math.pow(10, length - 1) + Math.random() * 9 * Math.pow(10, length - 1));
    },
    getCurrentDate: function() {
        return '07/14/2015';
    },
    getCurrentTime: function() {
        return '04:57 PM';
    },
    log: function(obj) {
        console.log(obj);
        if (!this.socketRef) {
            this.socketRef = angular.element(document.body).injector().get('$socket');
        }
        this.socketRef.send(JSON.stringify({
            type: 'LOG',
            options: {
                message: obj
            }
        }), false);
    },
    getCurrentTimestamp: function(format) {
        if (format) {
            var now = new Date();
            return now.format(format);
        } else {
            return (new Date().getTime());
        }
    },
    prepandZeros: function(num, places) {
        num = num || "";
        var zero = places - num.toString().length + 1;
        return Array(+(zero > 0 && zero)).join("0") + num;
    },
    noConsecutiveChars: function(str, limit) {
        limit = limit || 3;
        var lastDigit = str.charCodeAt(0),
            num = 1,
            val, delta;
        for (var i = 1; i < str.length; i++) {
            val = str.charCodeAt(i);
            ++num;
            if (num === 2) {
                // calc delta and remember it
                delta = val - lastDigit;
                // see if we have a two char sequence now
                if (delta !== 1) {
                    // not sequential, start over
                    num = 1;
                }
            } else {
                // see if consecutive sequence continues and exceeds limit
                if (val === (lastDigit + delta)) {
                    if (num >= limit) {
                        return (false);
                    }
                } else {
                    // sequence stopped
                    num = 1;
                }
            }
            lastDigit = val;
        }
        return (true);
    },
    noRepeatedValues: function(val) {
        if (val) {
            val = val + "";
            if (val.charAt(0) === val.charAt(1) && val.charAt(1) === val.charAt(2)) {
                return false;
            }
            return true;
        }
    },
    phoneValidation: function(val) {
        if (val) {
            var firstSet = val.substr(0, 3);
            var secondSet = val.substr(3, 3);
            var lastSet = val.substr(6, 4);
            if ((parseInt(firstSet.charAt(1)) - parseInt(firstSet.charAt(0))) === 1 && (parseInt(firstSet.charAt(2)) - parseInt(firstSet.charAt(1))) === 1) {
                return "Invalid area code.";
            }
            if (secondSet === '555') {
                return "Repeating characters not allowed. Please re-enter.";
            }
            if ((secondSet + lastSet.charAt(0)) === lastSet) {
                return "Repeating characters not allowed. Please re-enter.";
            }
            return "VALID";
        }
    },
    sortArray: function(arr, prop, reverse, numeric) {

        // Ensure there's a property
        if (!prop || !arr) {
            return arr;
        }

        // Set up sort function
        var sort_by = function(field, rev, primer) {

            // Return the required a,b function
            return function(a, b) {

                // Reset a, b to the field
                a = primer(a[field]), b = primer(b[field]);

                // Do actual sorting, reverse as needed
                return ((a < b) ? -1 : ((a > b) ? 1 : 0)) * (rev ? -1 : 1);
            };

        }

        // Distinguish between numeric and string to prevent 100's from coming before smaller
        // e.g.
        // 1
        // 20
        // 3
        // 4000
        // 50

        if (numeric) {

            // Do sort "in place" with sort_by function
            arr.sort(sort_by(prop, reverse, function(a) {

                // - Force value to a string.
                // - Replace any non numeric characters.
                // - Parse as float to allow 0.02 values.
                return parseFloat(String(a).replace(/[^0-9.-]+/g, ''));

            }));
        } else {

            // Do sort "in place" with sort_by function
            arr.sort(sort_by(prop, reverse, function(a) {

                // - Force value to string.
                return String(a).toUpperCase();

            }));
        }
    },
    isValidDate: function(str) {
        var matches = str.match(/(\d{1,2})[- \/](\d{1,2})[- \/](\d{4})/);
        if (!matches) return;
        // convert pieces to numbers
        // make a date object out of it
        var month = parseInt(matches[1], 10);
        var day = parseInt(matches[2], 10);
        var year = parseInt(matches[3], 10);
        var date = new Date(year, month - 1, day);
        if (!date || !date.getTime()) return;

        // make sure we didn't have any illegal 
        // month or day values that the date constructor
        // coerced into valid values
        if (date.getMonth() + 1 != month ||
            date.getFullYear() != year ||
            date.getDate() != day) {
            return;
        }
        return (date);
    },
    formatTel: function(s) {
        var s2 = ("" + s).replace(/\D/g, '');
        var m = s2.match(/^(\d{3})(\d{3})(\d{4})$/);
        return (!m) ? null : "(" + m[1] + ") " + m[2] + "-" + m[3];
    }
};
var dateFormat = function() {
    var token = /d{1,4}|m{1,4}|yy(?:yy)?|([HhMsTt])\1?|[LloSZ]|"[^"]*"|'[^']*'/g,
        timezone = /\b(?:[PMCEA][SDP]T|(?:Pacific|Mountain|Central|Eastern|Atlantic) (?:Standard|Daylight|Prevailing) Time|(?:GMT|UTC)(?:[-+]\d{4})?)\b/g,
        timezoneClip = /[^-+\dA-Z]/g,
        pad = function(val, len) {
            val = String(val);
            len = len || 2;
            while (val.length < len) val = "0" + val;
            return val;
        };

    // Regexes and supporting functions are cached through closure
    return function(date, mask, utc) {
        var dF = dateFormat;

        // You can't provide utc if you skip other args (use the "UTC:" mask prefix)
        if (arguments.length == 1 && Object.prototype.toString.call(date) == "[object String]" && !/\d/.test(date)) {
            mask = date;
            date = undefined;
        }

        // Passing date through Date applies Date.parse, if necessary
        date = date ? new Date(date) : new Date;
        if (isNaN(date)) throw SyntaxError("invalid date");

        mask = String(dF.masks[mask] || mask || dF.masks["default"]);

        // Allow setting the utc argument via the mask
        if (mask.slice(0, 4) == "UTC:") {
            mask = mask.slice(4);
            utc = true;
        }

        var _ = utc ? "getUTC" : "get",
            d = date[_ + "Date"](),
            D = date[_ + "Day"](),
            m = date[_ + "Month"](),
            y = date[_ + "FullYear"](),
            H = date[_ + "Hours"](),
            M = date[_ + "Minutes"](),
            s = date[_ + "Seconds"](),
            L = date[_ + "Milliseconds"](),
            o = utc ? 0 : date.getTimezoneOffset(),
            flags = {
                d: d,
                dd: pad(d),
                ddd: dF.i18n.dayNames[D],
                dddd: dF.i18n.dayNames[D + 7],
                m: m + 1,
                mm: pad(m + 1),
                mmm: dF.i18n.monthNames[m],
                mmmm: dF.i18n.monthNames[m + 12],
                yy: String(y).slice(2),
                yyyy: y,
                h: H % 12 || 12,
                hh: pad(H % 12 || 12),
                H: H,
                HH: pad(H),
                M: M,
                MM: pad(M),
                s: s,
                ss: pad(s),
                l: pad(L, 3),
                L: pad(L > 99 ? Math.round(L / 10) : L),
                t: H < 12 ? "a" : "p",
                tt: H < 12 ? "am" : "pm",
                T: H < 12 ? "A" : "P",
                TT: H < 12 ? "AM" : "PM",
                Z: utc ? "UTC" : (String(date).match(timezone) || [""]).pop().replace(timezoneClip, ""),
                o: (o > 0 ? "-" : "+") + pad(Math.floor(Math.abs(o) / 60) * 100 + Math.abs(o) % 60, 4),
                S: ["th", "st", "nd", "rd"][d % 10 > 3 ? 0 : (d % 100 - d % 10 != 10) * d % 10]
            };

        return mask.replace(token, function($0) {
            return $0 in flags ? flags[$0] : $0.slice(1, $0.length - 1);
        });
    };
}();

// Some common format strings
dateFormat.masks = {
    "default": "ddd mmm dd yyyy HH:MM:ss",
    shortDate: "m/d/yy",
    mediumDate: "mmm d, yyyy",
    longDate: "mmmm d, yyyy",
    fullDate: "dddd, mmmm d, yyyy",
    shortTime: "h:MM TT",
    mediumTime: "h:MM:ss TT",
    longTime: "h:MM:ss TT Z",
    isoDate: "yyyy-mm-dd",
    isoTime: "HH:MM:ss",
    isoDateTime: "yyyy-mm-dd'T'HH:MM:ss",
    isoUtcDateTime: "UTC:yyyy-mm-dd'T'HH:MM:ss'Z'"
};

// Internationalization strings
dateFormat.i18n = {
    dayNames: [
        "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat",
        "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
    ],
    monthNames: [
        "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
        "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"
    ]
};

// For convenience...
Date.prototype.format = function(mask, utc) {
    return dateFormat(this, mask, utc);
};

/**
 * To send the Javascript exception inlucding the syntax errors and unhandled exceptions 
 * to the log file through the web-socket
 */
$(function() {

    window.onerror = function(errMsg, url, lineNo, col, error) {
        var errObj = {
            message: errMsg,
            url: url,
            line: lineNo,
            column: col,
            error: errObj
        };
        appUtils.log("Javascript error occured: " + JSON.stringify(errObj));
    };

});

function validatePhoneNumber(phoneNumber) {
    var flag = false;
    var j = 0;
    var k = 0;
    for (var i = 0; i < phoneNumber.length; i++) {
        var firstDigit = phoneNumber.charAt(0);
        if (firstDigit == phoneNumber.charAt(i)) {
            j++;
            if (j == 10) {
                // alert("Invalid Phone Number.");
                flag = true;
            }
        }
    }
    if (j != 10) {
        var len = phoneNumber.length - 3;
        var sevenDigit = phoneNumber.charAt(len);
        var res = phoneNumber.substring(3, 10);
        for (var i = 0; i < len; i++) {
            if (sevenDigit == res.charAt(i)) {
                k++;
                if (k == 7) {
                    // alert("Invalid Phone Number");
                    flag = true;
                }
            }

        }
    }

    return flag;
}

//Returns the values in JSON as array
Object.values = function(object) {
    var values = [];
    for (var property in object) {
        values.push(object[property]);
    }
    return values;
}
