describe('ExtraCareMessageCtrl', function () {
    var scope, controller, MessageFactory;
    var displayMessageResponse = [[{"rxNum":null,"refilNum":null,"pFillSeqNum":null,"editVersionNum":null,"rxPatientId":"11214231892","msgSeq":"1025128","messageConfig":{"msgInd":"N","msgRank":8,"displayOrder":1,"promptIndicator":null,"dispTitle":"Extracare Healthy Rewards Programs","dispTitle2":null,"descTxt":"Ask patient to sign up to earn $5 ExtraBucks Rewards for every 10 scripts. If already enrolled, they must renew HIPAA Auth annually to continue to earn. Renewal follows same process as enrollment.","intrTxt":"The system has identified that this patient has not yet joined or needs to renew their membership in the ExtraCare Pharmacy & Health Rewards program.","intrTxt2":null,"usrEntryTool":{"tool1":null,"tool2":null,"tool3":null,"tool4":null},"scrButton":{"button1":{"id":11,"value":"Continue"},"button2":null,"button3":null,"button4":null},"lnItmButton":{"button1":{"id":1,"value":"Defer"},"button2":{"id":3,"value":"Decline"},"button3":{"id":5,"value":"Accept"},"button4":null},"descTxt2":null,"msgType":"6","progType":"1"},"markDisplayed":true,"progType":"1","messageType":6,"pfillSeqNum":null}]]
    beforeEach(function () {
        module('weCarePlusApp');
    });
    beforeEach(inject(function ($rootScope, $controller) {
        scope = $rootScope.$new();
        scope = {
            patientMessageConfig: {
                pageTitle: 'Display title'
            },
            CONFIG: {},
            patientMessageList: displayMessageResponse[0]
        }
        controller = $controller('ExtraCareMessageCtrl', {
            '$scope': scope
        });
    }));
    
    it('will invoke doActionLineBtn when clicked on button', function () {
        scope.doActionLineBtn(scope.patientMessageList[0],1);
        expect(scope.patientMessageList[0].outcome).toBe(1);

        scope.doActionLineBtn(scope.patientMessageList[0],3);
        expect(scope.patientMessageList[0].outcome).toBe(3);
        
        scope.doActionLineBtn(scope.patientMessageList[0],5);
        expect(scope.patientMessageList[0].outcome).toBe(5);
    });

    it('will check isContinueActive', function () {
        scope.doActionLineBtn(scope.patientMessageList[0],1);
        expect(scope.isContinueActive()).toBe(true);
    });
});