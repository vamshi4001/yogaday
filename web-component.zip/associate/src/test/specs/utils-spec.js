describe("appUtils prepandZeros", function () {
  it("returns number with specified number of zeroes prepended", function () {
    var result = appUtils.prepandZeros(2, 3);
    expect(result).toBe('002');
  });
});