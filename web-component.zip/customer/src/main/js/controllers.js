'use strict';

var cntrl = angular.module('sibCControllers', ['ngSanitize', 'ngScrollbar']);

var homeCntrl = cntrl.controller('homeCtl', ['$scope', '$interval','MessageBrokerFactory', function($scope, $interval, MessageBrokerFactory) {
    var factoryStateCode = MessageBrokerFactory.getStateCode();
    if (factoryStateCode) {
        $scope.backgroundImage = appConfig.imageMap.cvs1;
    }
    $interval(function() {
        if ($scope.backgroundImage === appConfig.imageMap.cvs1) {
            $scope.backgroundImage = appConfig.imageMap.cvs2;
        } else {
            $scope.backgroundImage = appConfig.imageMap.cvs1;
        }
    }, 5000);
    $scope.$on('DISPLAY_IMAGES', function(evt) {
        $scope.backgroundImage = appConfig.imageMap.cvs1;
    });
}]);


cntrl.controller('rootController', ['$scope', 'remoteService', 'MessageBrokerFactory', function($scope, remoteService,
    MessageBrokerFactory) {

}]);

cntrl.controller('phrCtrl', ['$scope', 'remoteService', '$location', 'MessageBrokerFactory', '$rootScope', function($scope,
    remoteService, $location, MessageBrokerFactory, $rootScope) {
    $rootScope.$broadcast('rebuildScrollBar');
    $scope.showEsig = false;
    $scope.payload = MessageBrokerFactory.getPayload() || {};
    $scope.patientName = $scope.payload.patientName;

    $scope.agree = function(event) {
        event && event.preventDefault();
        $scope.showEsig = true;
        // event && event.preventDefault();
        // var payload = MessageBrokerFactory.getPayload();
        // payload.displayText =
        //     "Unless I cancel it before then, this authorization <br>will expire one (1) year from today.<br>"+payload.patientInfo.firstName+","+payload.patientInfo.lastName;

        // $location.url('/esig');   
    };

    $scope.eSignCaptured = function(event) {
        event && event.preventDefault();
        var messageToSend = {
            type: "ESIG",
            options: {
                disagree: false,
                noSignature: signaturePad.isEmpty(),
                esignData: signaturePad.toDataURL()
            }
        };
        remoteService.sendMessage(messageToSend, null);
        if (MessageBrokerFactory.getPriceTable().length === 0)
            $location.url("/home");
        else
            $location.url("/priceTable");
    };

    $scope.disagree = function(event) {
        event && event.preventDefault();

        var messageToSend = {
            type: "ESIG",
            options: {
                disagree: true
            }
        };
        remoteService.sendMessage(messageToSend, null);
        if (MessageBrokerFactory.getPriceTable().length === 0)
            $location.url("/home");
        else
            $location.url("/priceTable");
    };
    var canvas = $("#sigPad").get(0);
    var signaturePad = new SignaturePad(canvas, {
        minWidth: 1.5,
        maxWidth: 2,
        backgroundColor: "#eee",
        penColor: "rgb(0,0,0)"
    });

    $scope.clearSig = function(event) {
        event.preventDefault();
        signaturePad.clear();
    };
}]);

cntrl.controller('CurrentOrderCtrl', ['$scope', 'MessageBrokerFactory', '$location', 'remoteService', function($scope,
    MessageBrokerFactory, $location) {

    $scope.cvs3Image = appConfig.imageMap.cvs3;

    var getOrderTotal = function() {
        var orderTotal = 0;
        angular.forEach($scope.currentOrder, function(val, key) {
            orderTotal += parseFloat(val.price);
        });
        return orderTotal;
    };
    $scope.currentOrder = MessageBrokerFactory.getPriceTable();
    $scope.orderTotal = getOrderTotal();
    var updateThings = function() {
        $scope.currentOrder = MessageBrokerFactory.getPriceTable();
        $scope.orderTotal = getOrderTotal();
        if ($scope.currentOrder.length === 0)
            $location.url("/home");
    };
    // updateThings();
    $scope.$on('PRICE_TABLE_MESSAGE', function(evt) {
        updateThings();
        $scope.$apply();
    });
}]);

cntrl.controller('CancelConfirmCtrl', ['$scope', 'MessageBrokerFactory', '$location', 'remoteService', function($scope,
    MessageBrokerFactory, $location, remoteService) {
    $scope.sourceRoute = MessageBrokerFactory.getSourceRoute();
    $scope.phone = MessageBrokerFactory.getNewPhone();

    $scope.cancelConfirm = function(action) {
        if ($scope.sourceRoute == 'smsEnrollConfirm') {
            var accepted = true;
            if (action) {
                accepted = false;
            }
            var messageToSend = {
                type: "DISPLAY_QUESTION",
                options: {
                    accepted: accepted
                }
            };
            remoteService.sendMessage(messageToSend);
            $location.url("/home");
        } else if ($scope.sourceRoute == 'smsPatEntryConfirm') {
            var accepted = true;
            if (action) {
                accepted = false;
            }
            var messageToSend = {
                type: "DISPLAY_QUESTION",
                options: {
                    accepted: accepted
                }
            };
            remoteService.sendMessage(messageToSend);
            $location.url("/home");
        } else if ($scope.sourceRoute == 'newPhone') {
            if (action) {
                $location.url('/newPhone');
            } else {
                var messageToSend = {
                    type: "DISPLAY_QUESTION",
                    options: {
                        phone: $scope.phone
                    }
                };
                remoteService.sendMessage(messageToSend);
                $location.url("/home");
            }
        }
    };
}]);

cntrl.controller('PhoneConfirmCtrl', ['$scope', 'MessageBrokerFactory', '$location', 'remoteService', function($scope,
    MessageBrokerFactory, $location, remoteService) {
    $scope.phone = MessageBrokerFactory.getNewPhone();

    $scope.phoneConfirm = function(action) {
        if (action == 'A') {
            var accepted = true;
            if (action) {
                accepted = false;
            }
            var messageToSend = {
                type: "DISPLAY_QUESTION",
                options: {
                    phone: $scope.phone
                }
            };
            remoteService.sendMessage(messageToSend);
            $location.url("/home");
        } else {
            $location.url('/cancelConfirm');
        }
    };
}]);


cntrl.controller('NewPhoneCtrl', ['$scope', 'MessageBrokerFactory', '$location', 'remoteService', function($scope,
    MessageBrokerFactory, $location, remoteService) {
    $scope.sourceRoute = MessageBrokerFactory.getSourceRoute();
    $scope.isValidPhone = false;
    $scope.payload = MessageBrokerFactory.getPayload() || {};

    $scope.onScreenKeyClick = function(keyType, keyVal) {
        var tempValue = $scope[$scope.currentFocus.model];
        if (keyType === 'normKey') {
            var maxInputLength = 10;
            if (tempValue && tempValue.length >= maxInputLength) {
                return;
            }
            tempValue = tempValue ? (tempValue + keyVal) : keyVal;
        } else if (keyType === 'splKey') {
            switch (keyVal) {
                case 'clear':
                    tempValue = '';
                    break;
                case 'back':
                    tempValue = tempValue ? (tempValue.length > 0 ? tempValue.substr(0, tempValue.length - 1) : '') : null;
                    break;
                default:
                    break;
            }
        } else {
            appUtils.log("Invalid type of key pressed.");
        }
        $scope[$scope.currentFocus.model] = tempValue;
        $scope.enterKeyActive = tempValue.length === 10;
    };

    $scope.doAction = function(action) {
        if (action === 'C') {
            var messageToSend = {
                type: "DISPLAY_QUESTION",
                options: {}
            };
            remoteService.sendMessage(messageToSend);
            $location.url("/home");
        } else {
            if ($scope.enterKeyActive) {
                // if ($scope.inputValue.charAt(0) == '0') {
                //     alert('Invalid area code.');
                //     return;
                // } else if (!appUtils.noConsecutiveChars($scope.inputValue)) {
                //     alert('Consecutive characters not allowed. Please re-enter.');
                //     return;
                // } else if (!appUtils.noRepeatedValues($scope.inputValue)) {
                //     alert('Repeating characters not allowed. Please re-enter.');
                //     return;
                // }
                if (!$scope.payload.fromTcpa) {
                    MessageBrokerFactory.setNewPhone($scope.inputValue);
                    MessageBrokerFactory.setSourceRoute('newPhone');
                    $location.url('/phoneConfirm');
                } else {
                    var messageToSend = {
                        type: "DISPLAY_QUESTION",
                        options: {
                            phone: $scope.inputValue
                        }
                    };
                    remoteService.sendMessage(messageToSend);
                    if (MessageBrokerFactory.getPriceTable().length === 0)
                        $location.url("/home");
                    else
                        $location.url("/priceTable");
                }
            }
        }
    };
}]);


cntrl.controller('esigCtrl', ['$scope', '$location', 'remoteService', 'MessageBrokerFactory', function($scope,
    $location, remoteService, MessageBrokerFactory) {
    var messageToSend = {
        type: "ESIG",
        options: {
            image: {}
        }
    };
    var payload = MessageBrokerFactory.getPayload();
    $scope.esigText = payload.displayText;
    $scope.esigRxList = payload.rxNumberList;
    var canvas = $("#sigPad").get(0);

    var signaturePad = new SignaturePad(canvas, {
        minWidth: 1.5,
        maxWidth: 2,
        backgroundColor: "#eee",
        penColor: "rgb(0,0,0)"
    });

    $scope.clearSig = function(event) {
        event.preventDefault();
        signaturePad.clear();
    };
    $scope.selectOption = function($event) {
        $event.preventDefault();
        if (payload.tpCompliancePatESign) {
            MessageBrokerFactory.setEsignData(signaturePad.toDataURL());
            if(signaturePad.isEmpty()){
                MessageBrokerFactory.setEsigCustomerSigned(false);
            }else{
                MessageBrokerFactory.setEsigCustomerSigned(true);
            }
            $location.url("/patNameSign");
        } else {
            messageToSend.options.image = null;
            messageToSend.options.image = signaturePad.toDataURL();
            messageToSend.options.customerSigned = !signaturePad.isEmpty();
            remoteService.sendMessage(messageToSend, null);
            if (MessageBrokerFactory.getPriceTable().length === 0)
                $location.url("/home");
            else
                $location.url("/priceTable");
        }

    };
    $scope.patNameSign = function($event) {
        $event.preventDefault();
        messageToSend.options.image = null;
        messageToSend.options.image = MessageBrokerFactory.getEsignData();
         messageToSend.options.customerSigned = MessageBrokerFactory.getEsigCustomerSigned();;
        remoteService.sendMessage(messageToSend, null);
        if (MessageBrokerFactory.getPriceTable().length === 0)
            $location.url("/home");
        else
            $location.url("/priceTable");
    };
}]);

cntrl.controller('SmsEnrollCtrl', ['$scope', 'MessageBrokerFactory', '$rootScope', '$location', 'remoteService', function($scope,
    MessageBrokerFactory, $rootScope, $location, remoteService) {
    $scope.currentFocus = {};
    $scope.payload = MessageBrokerFactory.getPayload() || {};
    $scope.inputValue = $scope.payload.mobile || '';

    $scope.onScreenKeyClick = function(keyType, keyVal) {
        var tempValue = $scope[$scope.currentFocus.model];
        if (keyType === 'normKey') {
            var maxInputLength = 10;
            if (tempValue && tempValue.length >= maxInputLength) {
                return;
            }
            tempValue = tempValue ? (tempValue + keyVal) : keyVal;
        } else if (keyType === 'splKey') {
            switch (keyVal) {
                case 'clear':
                    tempValue = '';
                    break;
                case 'back':
                    tempValue = tempValue ? (tempValue.length > 0 ? tempValue.substr(0, tempValue.length - 1) : '') : null;
                    break;
                case 'enter':
                    if ($scope.enterKeyActive) {
                        $scope.doAction();
                    }
                    return;
                default:
                    break;
            }
        } else {
            appUtils.log("Invalid type of key pressed.");
        }
        $scope[$scope.currentFocus.model] = tempValue;
        $scope.enterKeyActive = tempValue.length === 10;
    };

    $scope.doAction = function(action) {
        var messageToSend = {
            type: "DISPLAY_QUESTION",
            options: {
                phone: $scope.inputValue
            }
        };
        if (action === 'N') {
            messageToSend.options.phone = false;
        }
        remoteService.sendMessage(messageToSend);
        $location.url("/home");
    };

    $scope.smsEnrollConfirm = function(action) {
        MessageBrokerFactory.setSourceRoute('smsEnrollConfirm');
        if (action === 'A') {
            var messageToSend = {
                type: "DISPLAY_QUESTION",
                options: {
                    accepted: true
                }
            };
            remoteService.sendMessage(messageToSend);
            $location.url("/home");
        } else {
            $location.url('/cancelConfirm');
        }
    };

    $scope.smsPatEntryConfirm = function(action) {
        MessageBrokerFactory.setSourceRoute('smsPatEntryConfirm');
        if (action === 'A') {
            var messageToSend = {
                type: "DISPLAY_QUESTION",
                options: {
                    accepted: true
                }
            };
            remoteService.sendMessage(messageToSend);
            $location.url("/home");
        } else {
            $location.url('/cancelConfirm');
        }
    };

    $scope.textEnroll = function(action) {
        var messageToSend = {
            type: "DISPLAY_QUESTION",
            options: {}
        };
        if (action) {
            messageToSend.options.accepted = true;
        }
        remoteService.sendMessage(messageToSend);
        $location.url("/home");
    }
}]);

cntrl.controller('ReadyFillEnrollCtrl', ['$scope', 'MessageBrokerFactory', '$rootScope', '$location', 'remoteService', function($scope,
    MessageBrokerFactory, $rootScope, $location, remoteService) {
    var payload = MessageBrokerFactory.getPayload();
    $scope.firstName = payload.firstName;
    $scope.fillDesc = payload.fillDesc;

    $scope.doAction = function(action) {
        if (action) {
            var messageToSend = {
                type: "DISPLAY_QUESTION",
                options: {
                    action: action
                }
            };
            remoteService.sendMessage(messageToSend);
            $location.url("/home");
        }
    };
}]);

//READY FILL LITE ENROLL --
cntrl.controller('ReadyFillLiteEnrollCtrl', ['$scope', 'MessageBrokerFactory', '$rootScope', '$location', 'remoteService', function($scope,
    MessageBrokerFactory, $rootScope, $location, remoteService) {
    var payload = MessageBrokerFactory.getPayload();
    $scope.acceptedData = payload.acceptedData;
    $scope.currentIndex = 0;
    $scope.toContinue = false;
    $scope.displayNext = function(isLast){        
        $scope.currentIndex++;
        $scope.patientConfirmed = false;
        if(isLast){
            var messageToSend = {
                    type: "DISPLAY_QUESTION",
                    options: {
                        acceptedData: $scope.acceptedData                        
                    }
                };
            remoteService.sendMessage(messageToSend);
            $location.url("/priceTable");
        }
    };   
}]);

//DRIVE READY FILL ENROLL --
cntrl.controller('DriveReadyFillEnrollCtrl', ['$scope', 'MessageBrokerFactory', '$rootScope', '$location', 'remoteService', function($scope,
    MessageBrokerFactory, $rootScope, $location, remoteService) {
    var payload = MessageBrokerFactory.getPayload();
    $scope.selectedScripts = payload.selectedScripts;
    $scope.patientFirstName = payload.patientFirstName;
    console.log('selectedScripts');
    console.log(JSON.stringify($scope.selectedScripts));
    $scope.currentIndex = 0;
    $scope.toContinue = false;
    $scope.displayNext = function(isLast){        
        $scope.currentIndex++;
        $scope.patientConfirmed = false;
        if(isLast){
            var messageToSend = {
                    type: "DISPLAY_QUESTION",
                    options: {
                        selectedScripts: $scope.selectedScripts                        
                    }
                };                
            remoteService.sendMessage(messageToSend);
            console.log('messageToSend');console.log(messageToSend);
            $location.url("/priceTable");
        }
    };   
}]);


//Retail Auto file Controller
cntrl.controller('retailAutoCtrl', ['$scope', 'remoteService', '$location', 'MessageBrokerFactory', function($scope,
    remoteService, $location, MessageBrokerFactory) {
    $scope.payload = MessageBrokerFactory.getPayload() || {};
    $scope.tcpaDisp = MessageBrokerFactory.getTcpaDisp();
    $scope.landOrMob = ($scope.tcpaDisp == 'AM') ? 'Mobile' : 'Landline';

    $scope.doAction = function(actionType) {
        if (actionType == 'AM' || actionType == 'AL') {
            MessageBrokerFactory.setTcpaDisp(actionType);
            var messageToSend = {
                type: "DISPLAY_QUESTION",
                options: {
                    action: actionType
                }
            };
            remoteService.sendMessage(messageToSend);
            $location.url("/priceTable");
        } else if (actionType == 'N') {
            var messageToSend = {
                type: "DISPLAY_QUESTION",
                options: {
                    action: actionType
                }
            };
            remoteService.sendMessage(messageToSend);
            $location.url("/plsWaitForPharMem");
        }
    };

    $scope.doConfimAction = function(actionType) {
        var action;
        if (actionType == 'PI') {
            if ($scope.tcpaDisp == 'AM') {
                action = 'DM';
            } else if ($scope.tcpaDisp == 'AL') {
                action = 'DL';
            }
        } else if (actionType == 'Y') {
            action = $scope.tcpaDisp;
        }
        var messageToSend = {
            type: "DISPLAY_QUESTION",
            options: {
                actionType: action
            }
        };
        remoteService.sendMessage(messageToSend);
        $location.url("/priceTable");
    };

}]);


//PSE controller
cntrl.controller('pseCtrl', ['$scope', '$location', 'remoteService', 'MessageBrokerFactory', function($scope,
    $location, remoteService, MessageBrokerFactory) {
    var messageToSend = {
        type: "DISPLAY_QUESTION",
        options: {
            image: {},
            isAgreed: true
        }
    };
    $scope.payload = MessageBrokerFactory.getPayload();
    var canvas = $("#sigPad").get(0);

    var signaturePad = new SignaturePad(canvas, {
        minWidth: 1.5,
        maxWidth: 2,
        backgroundColor: "#eee",
        penColor: "rgb(0,0,0)"
    });

    $scope.clearSig = function(event) {
        event.preventDefault();
        signaturePad.clear();
    };


    $scope.selectOption = function(actionType) {
        if (actionType == 'A') {
            messageToSend.options.image = null;
            messageToSend.options.image = signaturePad.toDataURL();
            messageToSend.options.isAgreed = true;
            remoteService.sendMessage(messageToSend);
            if (MessageBrokerFactory.getPriceTable().length === 0)
                $location.url("/home");
            else
                $location.url("/priceTable");
        } else {
            messageToSend.options.image = null;
            messageToSend.options.isAgreed = false;
            remoteService.sendMessage(messageToSend, null);
            if (MessageBrokerFactory.getPriceTable().length === 0)
                $location.url("/home");
            else
                $location.url("/priceTable");
        }

    };
    $scope.patNameSign = function($event) {
        $event.preventDefault();
        messageToSend.options.image = null;
        messageToSend.options.image = MessageBrokerFactory.getEsignData();
        remoteService.sendMessage(messageToSend, null);
        if (MessageBrokerFactory.getPriceTable().length === 0)
            $location.url("/home");
        else
            $location.url("/priceTable");
    };
}]);

homeCntrl.loadImages = function($rootScope, $http, MessageBrokerFactory) {

    var checkIfImageExists = function (stateAbbr) {
        appConfig.stateList.map(function(state){
            if (state == stateAbbr) {
                appConfig.imageList.map(function(image){
                    appConfig.imageMap[image] = image+stateAbbr+'.jpg';
                });
            } else {
                appConfig.imageList.map(function(image){
                    appConfig.imageMap[image] = image+'.jpg';
                });
            }
        });
        $rootScope.$broadcast('DISPLAY_IMAGES');
    }

    var fetchStateCode = function() {
        var factoryStateCode = MessageBrokerFactory.getStateCode();
        if (!factoryStateCode) {
            var stateCodeUrl = '/service/stores/attributes/statecode';
            $http.get(stateCodeUrl).then(function (result) {
                checkIfImageExists(result.data.StoreResponse.payload);
                MessageBrokerFactory.setStateCode(result.data.StoreResponse.payload);
            }, function (error){
               //TODO: log the message
            });
        }
        else
        {
            $rootScope.$broadcast('DISPLAY_IMAGES');
        }
        
    }

    fetchStateCode();
}

//MedB Controller
cntrl.controller('MedBCtrl', ['$scope', 'remoteService', '$location', 'MessageBrokerFactory', function($scope,
    remoteService, $location, MessageBrokerFactory) {
    $scope.payload = MessageBrokerFactory.getPayload() || {};

    $scope.confirmABN = function(actionType) {
        var messageToSend = {
            type: "DISPLAY_QUESTION",
            options: {
                action: actionType
            }
        };
        remoteService.sendMessage(messageToSend);
        $location.url("/priceTable");

    };
}]);