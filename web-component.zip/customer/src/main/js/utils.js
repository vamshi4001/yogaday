var appUtils = {
    log: function(obj) {
        console.log(obj);
    },
    noConsecutiveChars: function(str, limit) {
        limit = limit || 3;
        var lastDigit = str.charCodeAt(0),
            num = 1,
            val, delta;
        for (var i = 1; i < str.length; i++) {
            val = str.charCodeAt(i);
            ++num;
            if (num === 2) {
                // calc delta and remember it
                delta = val - lastDigit;
                // see if we have a two char sequence now
                if (delta !== 1) {
                    // not sequential, start over
                    num = 1;
                }
            } else {
                // see if consecutive sequence continues and exceeds limit
                if (val === (lastDigit + delta)) {
                    if (num >= limit) {
                        return (false);
                    }
                } else {
                    // sequence stopped
                    num = 1;
                }
            }
            lastDigit = val;
        }
        return (true);
    },
    noRepeatedValues: function(val) {
        var regex = new RegExp("(\\d)\\1\\1", "g");
        return !(regex.test(val));
    }
}
