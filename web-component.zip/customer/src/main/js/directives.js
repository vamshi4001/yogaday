'use strict';

var directiveModule = angular.module('sibCDirective', []);

directiveModule.directive('numpad', function() {
    return {
        restrict: 'E',
        templateUrl: 'partials/directives/numpad.html',
        link: function(scope, elem, attrs) {
            scope.row1 = ['1', '2', '3'];
            scope.row2 = ['4', '5', '6'];
            scope.row3 = ['7', '8', '9'];
            scope.row4 = ['0', '00'];

            scope.onClick = function(keyType, keyValue, event) {
                event.preventDefault();
                /*
                 * The default action is prevented.
                 * Invoke the click function in the isolate scope with the key type and value.
                 */
                scope.performClick({
                    keyType: keyType,
                    keyValue: keyValue
                });
            };
        },
        scope: {
            performClick: "&onClick",
            enterEnabled: "=enableEnter",
            cancelEnabled: "=enableCancel",
            dotEnabled: "=enableDot",
            spaceEnabled: "=enableSpace",
            active: "=active"
        }
    };
});
directiveModule.directive('autoFocus', function($timeout) {
    return {
        restrict: 'A',
        link: function(_scope, _element) {
            $timeout(function() {
                _element[0].focus();
            }, 0);
        }
    };
});
