var appConfig = {
    websocketUrl: "wss://wecare.localhost.stores.cvs.com:9900/customer",
    imageMap: {
     	cvs1: 'cvs1.jpg',
     	cvs2: 'cvs2.jpg',
     	cvs3: 'cvs3.jpg'
    },
    stateList: ['HI'],
    imageList: ['cvs1','cvs2','cvs3']
}
