'use strict';


var app = angular.module('sibCustomerWeb', ['ngRoute', 'sibCControllers', 'sibCService', 'sibCDirective', 'sibCFilter']);
// config the app module;
app.config(['$routeProvider', function($routeProvider) {
    // Here we define all of the app routes we'll support.
    $routeProvider
        .when('/home', {
            templateUrl: 'partials/home.html',
            controller: 'homeCtl',
            resolve: {
                homedata: homeCntrl.loadImages
            }
        })
        // Home page
        .when('/', {
            templateUrl: 'partials/home.html',
            controller: 'homeCtl',
            resolve: {
                homedata: homeCntrl.loadImages
            }
        })
        .when('/priceTable', {
            templateUrl: 'partials/priceTable.html',
            controller: 'CurrentOrderCtrl'
        })
        .when('/esig', {
            templateUrl: 'partials/esig.html',
            controller: 'esigCtrl'
        })
        .when('/patNameSign', {
            templateUrl: 'partials/patNameSign.html',
            controller: 'esigCtrl'
        })
        .when('/phrEnroll', {
            templateUrl: 'partials/phrEnroll.html',
            controller: 'phrCtrl'
        })
        .when('/cancelConfirm', {
            templateUrl: 'partials/cancelConfirm.html',
            controller: 'CancelConfirmCtrl'
        })
        .when('/newPhone', {
            templateUrl: 'partials/newPhone.html',
            controller: 'NewPhoneCtrl'
        })
        .when('/phoneConfirm', {
            templateUrl: 'partials/phoneConfirm.html',
            controller: 'PhoneConfirmCtrl'
        })
        .when('/smsEnrollConfirm', {
            templateUrl: 'partials/smsEnrollConfirm.html',
            controller: 'SmsEnrollCtrl'
        })
        .when('/smsPatEntryConfirm', {
            templateUrl: 'partials/smsPatEntryConfirm.html',
            controller: 'SmsEnrollCtrl'
        })
        .when('/textEnroll', {
            templateUrl: 'partials/textEnroll.html',
            controller: 'SmsEnrollCtrl'
        })
        .when('/readyFillEnroll', {
            templateUrl: 'partials/readyFillEnroll.html',
            controller: 'ReadyFillEnrollCtrl'
        })
        .when('/readyFillLiteEnroll', {
            templateUrl: 'partials/readyFillLiteEnroll.html',
            controller: 'ReadyFillLiteEnrollCtrl'
        })
        .when('/retailAuto', {
            templateUrl: 'partials/retailAuto.html',
            controller: 'retailAutoCtrl'
        })
        .when('/plsWaitForPharMem', {
            templateUrl: 'partials/plsWaitForPharMem.html'
        })
        .when('/retialActionConf', {
            templateUrl: 'partials/retailAutoConfirm.html',
            controller: 'retailAutoCtrl'
        })
        .when('/pseConfirm',{
            templateUrl: 'partials/pseConfirm.html',
            controller: 'pseCtrl'
        })
        // Error page
        .otherwise({
            redirectTo: '/'
        });
}]);
