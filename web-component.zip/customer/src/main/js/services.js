'use strict';

var serviceModule = angular.module('sibCService', []);

serviceModule.factory('MessageBrokerFactory', function() {
    var messageBrokerData = {};
    var priceTable = [];
    var sourceRoute;
    var newPhone;
    var esignData;
    var tcpaDisp;
    var esigCustomerSigned;
    var stateCode;

    return {
        setMessageBrokerData: function(data) {
            messageBrokerData = data;
        },
        getPayload: function() {
            return messageBrokerData.options.payload;
        },
        getRoute: function() {
            return messageBrokerData.options.route;
        },
        getType: function() {
            return messageBrokerData.type;
        },
        getPriceTable: function() {
            return priceTable;
        },
        setPriceTable: function(pt) {
            priceTable = pt;
        },
        setSourceRoute: function(route) {
            sourceRoute = route;
        },
        getSourceRoute: function() {
            return sourceRoute;
        },
        setNewPhone: function(data) {
            newPhone = data;
        },
        getNewPhone: function() {
            return newPhone;
        },
        setEsignData: function(data) {
            esignData = data;
        },
        getEsignData: function() {
            return esignData;
        },
        setTcpaDisp: function(data) {
            tcpaDisp = data;
        },
        getTcpaDisp: function() {
            return tcpaDisp;
        },
        setEsigCustomerSigned: function(data){
            esigCustomerSigned = data;
        },
        getEsigCustomerSigned: function(){
            return esigCustomerSigned;
        },
        getStateCode: function(){
            return stateCode;
        },
        setStateCode: function(data){
            stateCode=data;
        }
    };
});

serviceModule.factory('remoteService', ['$rootScope', '$location', 'MessageBrokerFactory', function($rootScope,
    $location, MessageBrokerFactory) {
    var service = {
        priceItems: null
    };

    if ("WebSocket" in window) {} else {
        appUtils.log("WebSocket NOT supported by your Browser!");
        return;
    }

    /**
     * for local testing, connect to the localhost. 
     * display a pop-up so that people are aware of local connection
     */
    var url = $location.host().match("cvsstore.cvs.com") ? appConfig.websocketUrl : "wss://localhost:9900/customer";

    // var intervalID;

    service.init = function() {
        if (!service.ws) {

            service.ws = new WebSocket(url);

            service.ws.onopen = function() {
                appUtils.log("WebSocket Connection is open...");
                service.scannerEnabled = true;

                // intervalID = window.setInterval(function() {
                //     service.ws.send(JSON.stringify({
                //         type: 'STATUS'
                //     }));
                // }, 60000);
            };

            service.ws.onmessage = function(evt) {
                var received_msg = evt.data;
                var obj = JSON.parse(received_msg) || $.parseJSON(received_msg) || {};

                if (obj) {
                    obj.options = obj.options || {};
                    MessageBrokerFactory.setMessageBrokerData(obj);
                    if (obj.type === 'CLEAR_SCREEN') {
                        MessageBrokerFactory.setPriceTable([]);
                    }
                    var route = obj.options.route;
                    if (route) {
                        if (route === 'priceTable') {
                            MessageBrokerFactory.setPriceTable(obj.options.payload.items);
                            $rootScope.$broadcast('PRICE_TABLE_MESSAGE');
                        }
                        $location.url('/' + route);
                        $rootScope.$apply();
                    }
                    appUtils.log(obj);
                }
            };

            service.ws.onerror = function(event) {
                appUtils.log(event);
            };

            service.ws.onclose = function(event) {
                appUtils.log(Date() + " Connection is closed. Recreating socket connection...");
                appUtils.log("Close reason ...");
                appUtils.log(event);
                service.ws = null;
                // clearInterval(intervalID);
                setTimeout(function() {
                    service.init();
                }, 2000);
            };
        }
    };

    service.init();


    service.log = function(obj) {
        service.ws.send(JSON.stringify({
            type: 'LOG',
            options: {
                message: obj
            }
        }));
    };


    service.sendMessage = function(messageDetails, callback) {
        if (typeof service.ws == 'undefined')
            service.init();
        // contact the websocket and respond with options selected by users.
        service.messageCallback = callback;
        service.ws.send(JSON.stringify(messageDetails));

    };

    return service;
}]);
