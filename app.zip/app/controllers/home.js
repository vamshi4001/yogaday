angular.module("componentApp")
	.controller("homeController", function($scope, $http){
		var promise = $http.get("data/prices.json")
		promise.then(successCallback, errorCallback);
		function successCallback(response){
			renderComponent(response.data[0]);
		}
		function errorCallback(){
			console.log(error);
		}
		function renderComponent(data){
			$scope.actions = data.actions;
			$scope.price = data.data.price.historical;
			$scope.indicativePrice = data.data.price.indicative
			$scope.symbol = data.data.symbol;
		}
		$scope.doAction = function(val){
			console.log(val);
		}
		$scope.formatDate = function(date){
          	var dateOut = new Date(date);
          	return dateOut;
    	};
	})