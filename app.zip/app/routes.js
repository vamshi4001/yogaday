angular.module("componentApp")
	.config(function ($stateProvider, $urlRouterProvider) {
        $stateProvider
          .state('home', {
            url: '/',
            templateUrl: "views/home.html",
            controller: 'homeController'
          })
        $urlRouterProvider.otherwise('/');   
    })