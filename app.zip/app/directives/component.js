angular.module("componentApp")
	.directive("priceComponent", function(){
		return {
			restrict: "E",
			link: function($scope, elem, attrs){

			},
			controller: 'homeController',
			templateUrl: "views/component.html"
		}
	})